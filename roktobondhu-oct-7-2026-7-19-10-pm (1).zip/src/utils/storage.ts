import { BloodRequest, Donor, AppNotification, DonationStory, BloodBooking, RecipientProfile, Complaint } from '../types';
import {
  INITIAL_DONORS,
  INITIAL_REQUESTS,
  INITIAL_NOTIFICATIONS,
  INITIAL_STORIES,
  INITIAL_BOOKINGS,
  INITIAL_RECIPIENTS,
  INITIAL_COMPLAINTS,
} from '../data/initialData';
import { calculateEligibility, canDonate, playNotificationChime } from './bloodLogic';

const STORAGE_KEYS = {
  DONORS: 'faridpur_blood_donors_v3',
  REQUESTS: 'faridpur_blood_requests_v3',
  NOTIFICATIONS: 'faridpur_blood_notifications_v3',
  STORIES: 'faridpur_blood_stories_v3',
  BOOKINGS: 'faridpur_blood_bookings_v3',
  RECIPIENTS: 'faridpur_blood_recipients_v3',
  COMPLAINTS: 'faridpur_blood_complaints_v3',
};

export function loadDonors(): Donor[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DONORS);
    if (!raw) {
      saveDonors(INITIAL_DONORS);
      return INITIAL_DONORS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_DONORS;
  }
}

export function saveDonors(donors: Donor[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.DONORS, JSON.stringify(donors));
  } catch (e) {
    console.error('Failed to save donors', e);
  }
}

export function loadRequests(): BloodRequest[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.REQUESTS);
    if (!raw) {
      saveRequests(INITIAL_REQUESTS);
      return INITIAL_REQUESTS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_REQUESTS;
  }
}

export function saveRequests(requests: BloodRequest[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.REQUESTS, JSON.stringify(requests));
  } catch (e) {
    console.error('Failed to save requests', e);
  }
}

export function loadNotifications(): AppNotification[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    if (!raw) {
      saveNotifications(INITIAL_NOTIFICATIONS);
      return INITIAL_NOTIFICATIONS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_NOTIFICATIONS;
  }
}

export function saveNotifications(notifications: AppNotification[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  } catch (e) {
    console.error('Failed to save notifications', e);
  }
}

export function loadStories(): DonationStory[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.STORIES);
    if (!raw) {
      saveStories(INITIAL_STORIES);
      return INITIAL_STORIES;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_STORIES;
  }
}

export function saveStories(stories: DonationStory[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.STORIES, JSON.stringify(stories));
  } catch (e) {
    console.error('Failed to save stories', e);
  }
}

export function loadBookings(): BloodBooking[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.BOOKINGS);
    if (!raw) {
      saveBookings(INITIAL_BOOKINGS);
      return INITIAL_BOOKINGS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_BOOKINGS;
  }
}

export function saveBookings(bookings: BloodBooking[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));
  } catch (e) {
    console.error('Failed to save bookings', e);
  }
}

export function loadRecipients(): RecipientProfile[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.RECIPIENTS);
    if (!raw) {
      saveRecipients(INITIAL_RECIPIENTS);
      return INITIAL_RECIPIENTS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_RECIPIENTS;
  }
}

export function saveRecipients(recipients: RecipientProfile[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.RECIPIENTS, JSON.stringify(recipients));
  } catch (e) {
    console.error('Failed to save recipients', e);
  }
}

export function loadComplaints(): Complaint[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.COMPLAINTS);
    if (!raw) {
      saveComplaints(INITIAL_COMPLAINTS);
      return INITIAL_COMPLAINTS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_COMPLAINTS;
  }
}

export function saveComplaints(complaints: Complaint[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.COMPLAINTS, JSON.stringify(complaints));
  } catch (e) {
    console.error('Failed to save complaints', e);
  }
}

/**
 * Checks current user donor eligibility and creates a notification if 4 months (120 days) passed
 */
export function checkEligibilityNotification(
  currentUser: Donor,
  notifications: AppNotification[]
): { updatedNotifications: AppNotification[]; newlyTriggered: boolean } {
  const result = calculateEligibility(currentUser.lastDonationDate);
  
  if (result.isEligible) {
    const existingNotif = notifications.find(
      (n) => n.type === 'eligibility_ready' && n.title.includes('৪ মাস পূর্ণ হয়েছে')
    );
    
    if (!existingNotif) {
      const newNotif: AppNotification = {
        id: `notif-elig-${Date.now()}`,
        type: 'eligibility_ready',
        title: '🎉 ৪ মাস পূর্ণ হয়েছে! রক্তদানে প্রস্তুত',
        message: `আপনার শেষ রক্তদানের পর ১২০ দিন (৪ মাস) পূর্ণ হয়েছে। ফরিদপুর ব্লাড ব্যাংকে আপনার রক্তের গ্রুপ (${currentUser.bloodGroup}) এখন যেকোনো জীবন বাঁচাতে প্রস্তুত।`,
        timestamp: 'এখনই',
        read: false,
        relatedBloodGroup: currentUser.bloodGroup,
      };
      
      playNotificationChime();
      const updated = [newNotif, ...notifications];
      saveNotifications(updated);
      return { updatedNotifications: updated, newlyTriggered: true };
    }
  }

  return { updatedNotifications: notifications, newlyTriggered: false };
}

/**
 * Generates an emergency request notification and plays sound chime
 */
export function createBloodRequestNotification(
  request: BloodRequest,
  currentUser: Donor,
  existingNotifications: AppNotification[]
): AppNotification[] {
  const isMatch = canDonate(currentUser.bloodGroup, request.bloodGroup);
  
  const newNotif: AppNotification = {
    id: `notif-req-${Date.now()}`,
    type: 'blood_request',
    title: isMatch
      ? `🚨 জরুরি আবেদন: আপনার গ্রুপের রক্তের প্রয়োজন (${request.bloodGroup})`
      : `🩸 নতুন রক্তের আবেদন: ${request.bloodGroup} (${request.hospitalName})`,
    message: `${request.hospitalName}, ${request.upazila}, ${request.district}-এ ${request.patientName}-এর জন্য জরুরি ${request.bagsNeeded} ব্যাগ ${request.bloodGroup} রক্ত প্রয়োজন। যোগাযোগ: ${request.contactPhone}`,
    timestamp: 'এখনই',
    read: false,
    relatedBloodGroup: request.bloodGroup,
    relatedRequestId: request.id,
  };

  playNotificationChime();
  const updated = [newNotif, ...existingNotifications];
  saveNotifications(updated);
  return updated;
}
