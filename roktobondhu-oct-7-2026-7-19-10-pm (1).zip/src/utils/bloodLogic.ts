import { BloodGroup } from '../types';

export const DONATION_CYCLE_DAYS = 120; // 4 months standard recovery window

export interface EligibilityResult {
  isEligible: boolean;
  daysPassed: number;
  daysRemaining: number;
  nextEligibleDateString: string;
  progressPercent: number;
  statusLabelBn: string;
  badgeColorClass: string;
}

/**
 * Calculates blood donation eligibility based on 4 months (120 days) window.
 */
export function calculateEligibility(lastDonationDate: string | null): EligibilityResult {
  if (!lastDonationDate) {
    return {
      isEligible: true,
      daysPassed: 999,
      daysRemaining: 0,
      nextEligibleDateString: 'যেকোনো সময়',
      progressPercent: 100,
      statusLabelBn: 'রক্তদানে প্রস্তুত (নতুন দাতা)',
      badgeColorClass: 'text-emerald-700 bg-emerald-50 border-emerald-200',
    };
  }

  const lastDate = new Date(lastDonationDate);
  const today = new Date();
  
  // Set both to midnight UTC for precise day calculation
  const diffTime = today.getTime() - lastDate.getTime();
  const daysPassed = Math.floor(diffTime / (1000 * 60 * 60 * 24));

  if (daysPassed >= DONATION_CYCLE_DAYS) {
    return {
      isEligible: true,
      daysPassed,
      daysRemaining: 0,
      nextEligibleDateString: 'ইতিমধ্যে প্রস্তুত',
      progressPercent: 100,
      statusLabelBn: 'রক্তদানে প্রস্তুত (৪ মাস পূর্ণ)',
      badgeColorClass: 'text-emerald-700 bg-emerald-50 border-emerald-200',
    };
  }

  const daysRemaining = Math.max(0, DONATION_CYCLE_DAYS - daysPassed);
  const nextDate = new Date(lastDate);
  nextDate.setDate(nextDate.getDate() + DONATION_CYCLE_DAYS);
  
  const progressPercent = Math.min(100, Math.max(0, Math.round((daysPassed / DONATION_CYCLE_DAYS) * 100)));

  return {
    isEligible: false,
    daysPassed: Math.max(0, daysPassed),
    daysRemaining,
    nextEligibleDateString: nextDate.toLocaleDateString('bn-BD', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }),
    progressPercent,
    statusLabelBn: `বিশ্রামে (আর ${toBengaliNumber(daysRemaining)} দিন বাকি)`,
    badgeColorClass: 'text-amber-800 bg-amber-50 border-amber-200',
  };
}

/**
 * Convert English number to Bengali digits
 */
export function toBengaliNumber(num: number | string): string {
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(num).replace(/[0-9]/g, (w) => bnDigits[+w]);
}

/**
 * Blood Compatibility Matrix
 */
export const BLOOD_COMPATIBILITY: Record<BloodGroup, { canDonateTo: BloodGroup[]; canReceiveFrom: BloodGroup[] }> = {
  'O-': {
    canDonateTo: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'], // Universal Donor
    canReceiveFrom: ['O-'],
  },
  'O+': {
    canDonateTo: ['O+', 'A+', 'B+', 'AB+'],
    canReceiveFrom: ['O+', 'O-'],
  },
  'A-': {
    canDonateTo: ['A+', 'A-', 'AB+', 'AB-'],
    canReceiveFrom: ['A-', 'O-'],
  },
  'A+': {
    canDonateTo: ['A+', 'AB+'],
    canReceiveFrom: ['A+', 'A-', 'O+', 'O-'],
  },
  'B-': {
    canDonateTo: ['B+', 'B-', 'AB+', 'AB-'],
    canReceiveFrom: ['B-', 'O-'],
  },
  'B+': {
    canDonateTo: ['B+', 'AB+'],
    canReceiveFrom: ['B+', 'B-', 'O+', 'O-'],
  },
  'AB-': {
    canDonateTo: ['AB+', 'AB-'],
    canReceiveFrom: ['AB-', 'A-', 'B-', 'O-'],
  },
  'AB+': {
    canDonateTo: ['AB+'],
    canReceiveFrom: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'], // Universal Recipient
  },
};

/**
 * Check if donor group can donate to recipient group
 */
export function canDonate(donor: BloodGroup, recipient: BloodGroup): boolean {
  return BLOOD_COMPATIBILITY[donor]?.canDonateTo.includes(recipient) ?? false;
}

/**
 * Plays a pleasant soft notification chime using Web Audio API
 */
export function playNotificationChime(): void {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    
    // Play warm dual-tone chime (F5 then C6)
    const now = ctx.currentTime;
    
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(698.46, now); // F5
    gain1.gain.setValueAtTime(0.15, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.35);

    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(1046.5, now + 0.12); // C6
    gain2.gain.setValueAtTime(0.18, now + 0.12);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.12);
    osc2.stop(now + 0.55);
  } catch (e) {
    // Ignore autoplay policy restriction if user has not interacted
  }
}

/**
 * Build WhatsApp share link with Bengali template
 */
export function buildWhatsAppLink(phone: string, text: string): string {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  const encodedText = encodeURIComponent(text);
  // If Bangladeshi number starts with 01, convert to 8801 for direct link
  const internationalPhone = cleanPhone.startsWith('0') ? `88${cleanPhone}` : cleanPhone;
  return `https://wa.me/${internationalPhone}?text=${encodedText}`;
}

/**
 * Format a rich, volunteer-ready Bengali message for blood request sharing
 */
export function formatBloodRequestShareText(req: {
  bloodGroup: string;
  bagsNeeded: number;
  patientName: string;
  patientCondition?: string;
  patientAge?: number;
  hospitalName: string;
  district: string;
  upazila: string;
  area?: string;
  urgency: string;
  neededDate: string;
  contactPerson?: string;
  contactPhone: string;
  additionalNotes?: string;
}): string {
  const urgentBadge = req.urgency.includes('সংকটাপন্ন') || req.urgency.includes('Critical')
    ? '🚨 [সংকটাপন্ন / জরুরি রক্তের আবেদন] 🚨'
    : '🩸 [জরুরি রক্তের আবেদন - ফরিদপুর ব্লাড ব্যাংক]';

  return `${urgentBadge}
────────────────────
🩸 রক্তের গ্রুপ: *${req.bloodGroup}* (${toBengaliNumber(req.bagsNeeded)} ব্যাগ)
⚡ গুরুত্ব / সময়: *${req.urgency}*
👤 রোগী: ${req.patientName}${req.patientAge ? ` (${toBengaliNumber(req.patientAge)} বছর)` : ''}
🩺 রোগীর অবস্থা: ${req.patientCondition || 'চিকিৎসাধীন'}
🏥 হাসপাতাল: ${req.hospitalName}
📍 স্থান: ${req.upazila}, ${req.district} ${req.area ? `(${req.area})` : ''}
📅 রক্ত লাগবে: ${req.neededDate}
📞 সরাসরি যোগাযোগ: *${req.contactPhone}*${req.contactPerson ? ` (${req.contactPerson})` : ''}
${req.additionalNotes ? `📝 বিশেষ দ্রষ্টব্য: ${req.additionalNotes}\n` : ''}────────────────────
🙏 ফরিদপুর, মাদারীপুর, গোপালগঞ্জ, রাজবাড়ী ও মাগুরা জেলার সহৃদয় রক্তদাতা ভাই ও বোনেরা এগিয়ে আসুন। পোস্টটি বিভিন্ন গ্রুপ ও হোয়াটসঅ্যাপে শেয়ার করুন।`;
}

/**
 * WhatsApp broadcast / share link (can be shared to any chat, group or status)
 */
export function buildWhatsAppBroadcastLink(text: string): string {
  return `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
}

/**
 * SMS URI for direct mobile SMS app sharing
 */
export function buildSmsShareLink(text: string, phone?: string): string {
  const clean = phone ? phone.replace(/[^0-9]/g, '') : '';
  const encoded = encodeURIComponent(text);
  return clean ? `sms:${clean}?body=${encoded}` : `sms:?body=${encoded}`;
}
