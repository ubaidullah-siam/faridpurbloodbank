import React from 'react';
import { Donor, BloodRequest } from '../types';
import { calculateEligibility, toBengaliNumber } from '../utils/bloodLogic';
import { Users, CheckCircle2, Clock, AlertTriangle } from 'lucide-react';

interface StatsBarProps {
  donors: Donor[];
  requests: BloodRequest[];
  onSelectReadyFilter: () => void;
  onSelectUrgentFilter: () => void;
}

export const StatsBar: React.FC<StatsBarProps> = ({
  donors,
  requests,
  onSelectReadyFilter,
  onSelectUrgentFilter,
}) => {
  const eligibleCount = donors.filter(
    (d) => d.isAvailable && calculateEligibility(d.lastDonationDate).isEligible
  ).length;

  const restingCount = donors.length - eligibleCount;
  const activeRequestsCount = requests.filter((r) => r.status === 'active').length;

  return (
    <section className="bg-white border-y border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 divide-y md:divide-y-0 md:divide-x divide-neutral-100">
          
          {/* Stat 1: Total Donors */}
          <div className="flex items-center gap-3.5 pr-4">
            <div className="w-10 h-10 rounded-lg bg-neutral-100 flex items-center justify-center text-neutral-700 shrink-0">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold tracking-tight text-neutral-900 font-mono tabular-nums">
                {toBengaliNumber(donors.length)}
              </p>
              <p className="text-xs text-neutral-500 font-medium">নিবন্ধিত রক্তদাতা</p>
            </div>
          </div>

          {/* Stat 2: Ready / Eligible Donors */}
          <button
            onClick={onSelectReadyFilter}
            className="flex items-center gap-3.5 md:px-4 pt-4 md:pt-0 text-left hover:bg-neutral-50 rounded-lg transition-colors cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 group-hover:bg-emerald-100">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold tracking-tight text-emerald-800 font-mono tabular-nums">
                {toBengaliNumber(eligibleCount)}
              </p>
              <p className="text-xs text-neutral-500 font-medium group-hover:text-neutral-800">
                রক্তদানে প্রস্তুত (৪ মাস অতিক্রান্ত)
              </p>
            </div>
          </button>

          {/* Stat 3: Resting Donors */}
          <div className="flex items-center gap-3.5 md:px-4 pt-4 md:pt-0">
            <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold tracking-tight text-amber-800 font-mono tabular-nums">
                {toBengaliNumber(restingCount)}
              </p>
              <p className="text-xs text-neutral-500 font-medium">অপেক্ষমান (বিশ্রামের সময়)</p>
            </div>
          </div>

          {/* Stat 4: Active Emergency Requests */}
          <button
            onClick={onSelectUrgentFilter}
            className="flex items-center gap-3.5 md:pl-4 pt-4 md:pt-0 text-left hover:bg-neutral-50 rounded-lg transition-colors cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-lg bg-red-50 text-red-600 flex items-center justify-center shrink-0 group-hover:bg-red-100">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold tracking-tight text-red-700 font-mono tabular-nums">
                {toBengaliNumber(activeRequestsCount)}
              </p>
              <p className="text-xs text-neutral-500 font-medium group-hover:text-neutral-800">
                জরুরি রক্তের আবেদন
              </p>
            </div>
          </button>

        </div>
      </div>
    </section>
  );
};
