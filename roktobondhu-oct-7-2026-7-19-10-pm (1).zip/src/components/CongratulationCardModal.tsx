import React, { useRef } from 'react';
import { Donor } from '../types';
import { toBengaliNumber } from '../utils/bloodLogic';
import { X, Award, Share2, Facebook, Download, Copy, Heart, CheckCircle2, Droplets, Printer } from 'lucide-react';

interface CongratulationCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  donor: Donor;
  donationDate?: string;
  hospitalName?: string;
  onShowToast: (msg: string) => void;
}

export const CongratulationCardModal: React.FC<CongratulationCardModalProps> = ({
  isOpen,
  onClose,
  donor,
  donationDate = new Date().toISOString().split('T')[0],
  hospitalName = 'ফরিদপুর মেডিকেল কলেজ হাসপাতাল',
  onShowToast,
}) => {
  const cardRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const shareText = `🎉 রক্তদান সম্পন্ন ও অভিনন্দন স্মারক!\n🩸 রক্তদাতা: ${donor.name} (${donor.bloodGroup})\n🏥 স্থান: ${hospitalName}\n📅 তারিখ: ${donationDate}\n❤️ মোট রক্তদান: ${toBengaliNumber(donor.totalDonations || 1)} বার\n"আপনার রক্তে বাঁচলো প্রাণ, আপনি সমাজের গর্ব।"\n- ফরিদপুর ব্লাড ব্যাংক (Faridpur Blood Bank)`;

  const handleFacebookShare = () => {
    const url = encodeURIComponent(window.location.href);
    const text = encodeURIComponent(shareText);
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}&quote=${text}`, '_blank');
  };

  const handleCopyCard = () => {
    navigator.clipboard.writeText(shareText);
    onShowToast('📋 শুভেচ্ছা কার্ডের তথ্য ও সনদ ক্লিপবোর্ডে কপি করা হয়েছে! ফেসবুকে পোস্ট করুন।');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-neutral-200 my-8 space-y-6">
        
        {/* Top Close Bar */}
        <div className="flex items-center justify-between pb-2 border-b border-neutral-100">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-red-100 text-red-600 flex items-center justify-center">
              <Award className="w-5 h-5" />
            </span>
            <span className="font-bold text-sm text-neutral-900">
              ডিজিটাল রক্তদাতা সম্মাননা ও শুভেচ্ছা কার্ড
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Certificate Card Printable / Shareable Area */}
        <div
          ref={cardRef}
          className="relative bg-gradient-to-br from-red-700 via-red-800 to-neutral-900 text-white rounded-2xl p-6 sm:p-7 shadow-xl border-4 border-amber-300/60 overflow-hidden text-center space-y-4"
        >
          {/* Decorative Corner Seals */}
          <div className="absolute top-2 left-2 text-amber-300/40 text-xs font-mono">✦ ✦ ✦</div>
          <div className="absolute top-2 right-2 text-amber-300/40 text-xs font-mono">✦ ✦ ✦</div>
          <div className="absolute bottom-2 left-2 text-amber-300/40 text-xs font-mono">✦ ✦ ✦</div>
          <div className="absolute bottom-2 right-2 text-amber-300/40 text-xs font-mono">✦ ✦ ✦</div>

          {/* Org Header */}
          <div className="space-y-1">
            <div className="flex items-center justify-center gap-1.5">
              <Droplets className="w-5 h-5 fill-red-400 text-red-400" />
              <span className="text-xs uppercase tracking-widest text-amber-300 font-bold font-mono">
                ফরিদপুর ব্লাড ব্যাংক
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight text-white drop-shadow-sm">
              অভিনন্দন ও কৃতজ্ঞতা স্মারক
            </h2>
            <p className="text-[11px] text-amber-200/90 font-medium">
              মানবতার সেবায় রক্তদান · এক ব্যাগ রক্তে একটি নতুন জীবন
            </p>
          </div>

          {/* Donor Avatar & Blood Group */}
          <div className="flex flex-col items-center justify-center gap-2 pt-2">
            <div className="relative">
              {donor.profilePicture ? (
                <img
                  src={donor.profilePicture}
                  alt={donor.name}
                  className="w-20 h-20 rounded-full object-cover border-4 border-amber-300 shadow-md"
                />
              ) : (
                <div className="w-20 h-20 rounded-full bg-red-600/90 border-4 border-amber-300 flex items-center justify-center text-white font-mono font-extrabold text-2xl shadow-md">
                  {donor.bloodGroup}
                </div>
              )}
              <span className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-amber-400 text-neutral-950 flex items-center justify-center font-bold text-xs shadow-xs font-mono">
                {donor.bloodGroup}
              </span>
            </div>

            <div>
              <h3 className="text-lg sm:text-xl font-bold text-white">
                {donor.name}
              </h3>
              <p className="text-xs text-neutral-200">
                {donor.upazila}, {donor.district} জেলা
              </p>
            </div>
          </div>

          {/* Citation Text */}
          <div className="bg-black/30 backdrop-blur-xs p-3.5 rounded-xl border border-white/10 text-xs sm:text-sm text-neutral-100 leading-relaxed italic">
            "আপনার মূল্যবান এক ব্যাগ রক্ত একজন মুমূর্ষু রোগীকে নবজীবন উপহার দিয়েছে।
            মানবতার সেবায় আপনার এই নিঃস্বার্থ ত্যাগ আমাদের অনুপ্রেরণা।"
          </div>

          {/* Footer Metadata */}
          <div className="grid grid-cols-3 gap-2 pt-1 border-t border-white/15 text-[11px] text-neutral-200">
            <div>
              <span className="text-amber-300/80 block">মোট রক্তদান</span>
              <strong className="text-white font-mono">{toBengaliNumber(donor.totalDonations || 1)} বার</strong>
            </div>
            <div>
              <span className="text-amber-300/80 block">রক্তদানের তারিখ</span>
              <strong className="text-white font-mono">{donationDate}</strong>
            </div>
            <div>
              <span className="text-amber-300/80 block">স্থান/হাসপাতাল</span>
              <strong className="text-white truncate block">{hospitalName}</strong>
            </div>
          </div>
        </div>

        {/* Share & Download Actions */}
        <div className="space-y-3 pt-2">
          <p className="text-xs text-neutral-500 text-center">
            এই অভিনন্দন স্মারকটি আপনার ফেসবুক টাইমলাইনে বা মেসেঞ্জারে শেয়ার করে অন্যদের রক্তদানে উৎসাহিত করুন:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <button
              type="button"
              onClick={handleFacebookShare}
              className="py-2.5 px-3 bg-[#1877F2] hover:bg-[#166fe5] text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Facebook className="w-4 h-4 fill-white shrink-0" />
              <span>ফেসবুকে শেয়ার</span>
            </button>

            <button
              type="button"
              onClick={handleCopyCard}
              className="py-2.5 px-3 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Copy className="w-4 h-4 shrink-0" />
              <span>টেক্সট কপি</span>
            </button>

            <button
              type="button"
              onClick={() => window.print()}
              className="py-2.5 px-3 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Printer className="w-4 h-4 shrink-0" />
              <span>কার্ড সেভ / প্রিন্ট</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
