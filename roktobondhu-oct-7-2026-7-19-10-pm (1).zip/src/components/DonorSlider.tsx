import React, { useState, useEffect } from 'react';
import { DonationStory } from '../types';
import { toBengaliNumber } from '../utils/bloodLogic';
import { ChevronLeft, ChevronRight, Camera, MapPin } from 'lucide-react';

interface DonorSliderProps {
  stories: DonationStory[];
  onOpenUploadModal: () => void;
}

export const DonorSlider: React.FC<DonorSliderProps> = ({
  stories,
  onOpenUploadModal,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Auto slide smoothly every 4 seconds
  useEffect(() => {
    if (stories.length <= 1 || isPaused) return;

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % stories.length);
    }, 4000);

    return () => clearInterval(timer);
  }, [stories.length, isPaused]);

  if (stories.length === 0) return null;

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev === 0 ? stories.length - 1 : prev - 1));
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev + 1) % stories.length);
  };

  return (
    <div
      className="relative rounded-2xl overflow-hidden shadow-md border border-neutral-200 bg-neutral-900 group select-none"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Smooth Horizontal Slide Container (এক পাশে আরেক পাশে স্মুথলি সরবে) */}
      <div className="relative aspect-[16/9] sm:aspect-[21/9] lg:aspect-[25/9] w-full min-h-[220px] max-h-[460px] overflow-hidden">
        <div
          className="flex h-full w-full transition-transform duration-700 ease-[cubic-bezier(0.25,1,0.5,1)]"
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          {stories.map((story) => (
            <div
              key={story.id}
              className="relative w-full h-full flex-shrink-0 flex-grow-0"
            >
              <img
                src={story.photoUrl}
                alt={story.donorName}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center"
              />

              {/* Minimalist, clean bottom gradient - ONLY clean name & location, NO comments (ইউজার স্পেসিফিক রিকোয়ারমেন্ট: "শুধু ছবি থাকবে কমেন্টগুলো এখানে শো করবে না") */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-4 sm:p-6 text-white">
                <div className="flex items-end justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className="w-10 h-10 rounded-xl bg-red-600 text-white font-extrabold text-base flex items-center justify-center font-mono shadow-md shrink-0">
                      {story.bloodGroup}
                    </span>
                    <div>
                      <h3 className="text-base sm:text-xl font-bold tracking-tight text-white drop-shadow-xs leading-tight">
                        {story.donorName}
                      </h3>
                      <p className="text-xs text-neutral-300 flex items-center gap-1.5 mt-0.5">
                        <MapPin className="w-3.5 h-3.5 text-red-400 shrink-0" />
                        <span>{story.upazila}, {story.district}</span>
                        <span aria-hidden="true" className="opacity-60">·</span>
                        <span>{story.hospitalName}</span>
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={onOpenUploadModal}
                    className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/20 hover:bg-white/30 backdrop-blur-md text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer border border-white/25 shadow-xs"
                  >
                    <Camera className="w-3.5 h-3.5 text-red-400" />
                    <span>ছবি আপলোড</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Prev / Next Navigation Arrows */}
      <button
        type="button"
        onClick={handlePrev}
        aria-label="পূর্ববর্তী ছবি"
        className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/40 hover:bg-black/75 backdrop-blur-sm text-white flex items-center justify-center transition-all opacity-80 group-hover:opacity-100 border border-white/10 cursor-pointer shadow-sm"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>

      <button
        type="button"
        onClick={handleNext}
        aria-label="পরবর্তী ছবি"
        className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/40 hover:bg-black/75 backdrop-blur-sm text-white flex items-center justify-center transition-all opacity-80 group-hover:opacity-100 border border-white/10 cursor-pointer shadow-sm"
      >
        <ChevronRight className="w-5 h-5" />
      </button>

      {/* Slide Indicators Dots (স্মুথ ডটস) */}
      <div className="absolute bottom-3 right-4 flex items-center gap-1.5 z-10">
        {stories.map((s, idx) => (
          <button
            key={s.id}
            type="button"
            onClick={() => setCurrentIndex(idx)}
            aria-label={`স্লাইড ${idx + 1}`}
            className={`h-1.5 rounded-full transition-all cursor-pointer ${
              idx === currentIndex
                ? 'w-6 bg-red-600 shadow-xs'
                : 'w-1.5 bg-white/50 hover:bg-white/80'
            }`}
          />
        ))}
      </div>
    </div>
  );
};
