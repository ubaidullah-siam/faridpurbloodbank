import React, { useState } from 'react';
import { BloodGroup, UrgencyLevel, BloodRequest } from '../types';
import { ALLOWED_DISTRICTS, getUpazilasForDistrict, BLOOD_GROUPS } from '../data/bangladeshDistricts';
import { X, AlertCircle } from 'lucide-react';

interface AddRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (requestData: Omit<BloodRequest, 'id' | 'createdAt' | 'status'>) => void;
}

export const AddRequestModal: React.FC<AddRequestModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
}) => {
  const [patientName, setPatientName] = useState('');
  const [patientAge, setPatientAge] = useState<number | ''>('');
  const [patientCondition, setPatientCondition] = useState('');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('O+');
  const [bagsNeeded, setBagsNeeded] = useState(1);
  const [hospitalName, setHospitalName] = useState('ফরিদপুর মেডিকেল কলেজ হাসপাতাল');
  const [district, setDistrict] = useState('ফরিদপুর');
  const [upazila, setUpazila] = useState('ফরিদপুর সদর');
  const [area, setArea] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [urgency, setUrgency] = useState<UrgencyLevel>('জরুরি (এখনই)');
  const [neededDate, setNeededDate] = useState(new Date().toISOString().split('T')[0]);
  const [additionalNotes, setAdditionalNotes] = useState('');

  if (!isOpen) return null;

  const currentUpazilas = getUpazilasForDistrict(district);

  const handleDistrictChange = (newDist: string) => {
    setDistrict(newDist);
    const upazilas = getUpazilasForDistrict(newDist);
    if (upazilas.length > 0) {
      setUpazila(upazilas[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim() || !hospitalName.trim() || !contactPhone.trim()) return;

    onSubmit({
      patientName: patientName.trim(),
      patientAge: patientAge ? Number(patientAge) : undefined,
      patientCondition: patientCondition.trim() || 'জরুরি প্রয়োজন',
      bloodGroup,
      bagsNeeded: Number(bagsNeeded) || 1,
      hospitalName: hospitalName.trim(),
      district,
      upazila,
      area: area.trim() || `${upazila}, ${district}`,
      contactPerson: contactPerson.trim() || patientName.trim(),
      contactPhone: contactPhone.trim(),
      urgency,
      neededDate,
      additionalNotes: additionalNotes.trim(),
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-neutral-200 my-8">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-red-100 text-red-600 flex items-center justify-center">
              <AlertCircle className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-neutral-900">জরুরি রক্তের আবেদন পোস্ট করুন</h2>
              <p className="text-xs text-neutral-500">
                ফরিদপুর, মাদারীপুর, গোপালগঞ্জ, রাজবাড়ী ও মাগুরা জেলার ডোনারদের কাছে নোটিফিকেশন যাবে
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-4 text-xs">
          
          {/* Patient Name & Age */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block font-semibold text-neutral-700 mb-1">
                রোগীর নাম *
              </label>
              <input
                type="text"
                required
                placeholder="যেমন: রাহেলা বেগম"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                বয়স (বছর)
              </label>
              <input
                type="number"
                min="1"
                max="120"
                placeholder="যেমন: ৩৫"
                value={patientAge}
                onChange={(e) => setPatientAge(e.target.value === '' ? '' : Number(e.target.value))}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none font-mono"
              />
            </div>
          </div>

          {/* Blood Group & Bags Needed */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                প্রয়োজনীয় রক্তের গ্রুপ *
              </label>
              <select
                value={bloodGroup}
                onChange={(e) => setBloodGroup(e.target.value as BloodGroup)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none font-mono font-bold text-red-600 bg-white"
              >
                {BLOOD_GROUPS.map((grp) => (
                  <option key={grp} value={grp}>
                    {grp}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                রক্তের পরিমাণ (ব্যাগ) *
              </label>
              <input
                type="number"
                min="1"
                max="10"
                required
                value={bagsNeeded}
                onChange={(e) => setBagsNeeded(Math.max(1, Number(e.target.value)))}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none font-mono font-semibold"
              />
            </div>
          </div>

          {/* Condition / Reason */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              রোগীর অবস্থা / রক্তদানের কারণ *
            </label>
            <input
              type="text"
              required
              placeholder="যেমন: সিজারিয়ান ডেলিভারি, হার্ট সার্জারি, থ্যালাসেমিয়া, সড়ক দুর্ঘটনা..."
              value={patientCondition}
              onChange={(e) => setPatientCondition(e.target.value)}
              className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
            />
          </div>

          {/* District & Upazila */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                জেলা *
              </label>
              <select
                value={district}
                onChange={(e) => handleDistrictChange(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none bg-white font-medium"
              >
                {ALLOWED_DISTRICTS.map((dist) => (
                  <option key={dist} value={dist}>
                    {dist}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                উপজেলা *
              </label>
              <select
                value={upazila}
                onChange={(e) => setUpazila(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none bg-white font-medium"
              >
                {currentUpazilas.map((u) => (
                  <option key={u} value={u}>
                    {u}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Hospital & Area */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                হাসপাতালের নাম ও ওয়ার্ড *
              </label>
              <input
                type="text"
                required
                placeholder="যেমন: ফরিদপুর মেডিকেল, ওয়ার্ড ৩"
                value={hospitalName}
                onChange={(e) => setHospitalName(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                এলাকা / ল্যান্ডমার্ক
              </label>
              <input
                type="text"
                placeholder="যেমন: সার্কিট হাউজ মোড়, ঝিলটুলী"
                value={area}
                onChange={(e) => setArea(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Urgency & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                জরুরিতার মাত্রা *
              </label>
              <select
                value={urgency}
                onChange={(e) => setUrgency(e.target.value as UrgencyLevel)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none bg-white font-bold text-red-600"
              >
                <option value="সংকটাপন্ন (Critical / এখনই)">🚨 সংকটাপন্ন (Critical / এখনই প্রয়োজন)</option>
                <option value="জরুরি (২৪ ঘণ্টার মধ্যে)">⚠️ জরুরি (২৪ ঘণ্টার মধ্যে)</option>
                <option value="পরিকল্পিত (২-৩ দিন)">📅 পরিকল্পিত (২-৩ দিন সময় আছে)</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                রক্তদানের নির্দিষ্ট তারিখ *
              </label>
              <input
                type="date"
                required
                value={neededDate}
                onChange={(e) => setNeededDate(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Contact Person & Phone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                যোগাযোগকারীর নাম ও সম্পর্ক *
              </label>
              <input
                type="text"
                required
                placeholder="যেমন: মোঃ রাশেদ (রোগীর ভাই)"
                value={contactPerson}
                onChange={(e) => setContactPerson(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                মোবাইল নম্বর *
              </label>
              <input
                type="tel"
                required
                placeholder="01XXXXXXXXX"
                value={contactPhone}
                onChange={(e) => setContactPhone(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none font-mono"
              />
            </div>
          </div>

          {/* Additional Notes */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              অতিরিক্ত তথ্য বা বিশেষ নির্দেশ (ঐচ্ছিক)
            </label>
            <textarea
              rows={2}
              placeholder="যেমন: রক্তদাতার যাতায়াত খরচ বহন করা হবে, দ্রুত রক্তের ব্যবস্থা দরকার..."
              value={additionalNotes}
              onChange={(e) => setAdditionalNotes(e.target.value)}
              className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none resize-none"
            />
          </div>

          {/* Footer buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 font-semibold text-neutral-600 hover:bg-neutral-100 rounded-lg cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              আবেদন প্রকাশ করুন
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
