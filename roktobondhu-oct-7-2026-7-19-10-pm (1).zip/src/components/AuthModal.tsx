import React, { useState } from 'react';
import { BloodGroup, Donor } from '../types';
import { ALLOWED_DISTRICTS, getUpazilasForDistrict, BLOOD_GROUPS } from '../data/bangladeshDistricts';
import {
  Lock,
  Phone,
  User,
  MapPin,
  ShieldCheck,
  Droplets,
  KeyRound,
  CheckCircle2,
  ArrowRight,
  Eye,
  EyeOff,
  Sparkles,
  AlertCircle,
  Clock,
  RotateCcw,
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onLoginSuccess: (donor: Donor) => void;
  existingDonors: Donor[];
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onLoginSuccess,
  existingDonors,
}) => {
  const [tab, setTab] = useState<'register' | 'login'>('register');
  const [step, setStep] = useState<'form' | 'otp'>('form');

  // Form states for Registration
  const [name, setName] = useState('');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('O+');
  const [phone, setPhone] = useState('');
  const [district, setDistrict] = useState('ফরিদপুর');
  const [upazila, setUpazila] = useState('ফরিদপুর সদর');
  const [union, setUnion] = useState('');
  const [village, setVillage] = useState('');
  const [age, setAge] = useState(24);
  const [gender, setGender] = useState<'পুরুষ' | 'মহিলা' | 'অন্যান্য'>('পুরুষ');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Form states for Login
  const [loginPhone, setLoginPhone] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // OTP state
  const [generatedOtp, setGeneratedOtp] = useState('4821');
  const [enteredOtp, setEnteredOtp] = useState('');
  const [otpError, setOtpError] = useState('');
  const [formError, setFormError] = useState('');

  if (!isOpen) return null;

  const currentUpazilas = getUpazilasForDistrict(district);

  const handleDistrictChange = (d: string) => {
    setDistrict(d);
    const upz = getUpazilasForDistrict(d);
    if (upz.length > 0) setUpazila(upz[0]);
  };

  // Submit registration form -> generate OTP
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!name.trim() || !phone.trim() || !union.trim() || !village.trim() || !password.trim()) {
      setFormError('অনুগ্রহ করে সকল আবশ্যকীয় তথ্য পূরণ করুন।');
      return;
    }

    if (phone.length < 11) {
      setFormError('সঠিক ১১ সংখ্যার মোবাইল নম্বর লিখুন (যেমন: 017XXXXXXXX)।');
      return;
    }

    if (password.length < 4) {
      setFormError('পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।');
      return;
    }

    if (password !== confirmPassword) {
      setFormError('পাসওয়ার্ড দুটি মিলছে না!');
      return;
    }

    // Generate random 4-digit OTP
    const code = String(Math.floor(1000 + Math.random() * 9000));
    setGeneratedOtp(code);
    setEnteredOtp('');
    setOtpError('');
    setStep('otp');
  };

  // Verify OTP and complete sign up
  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (enteredOtp.trim() !== generatedOtp) {
      setOtpError('ভুল ওটিপি কোড! অনুগ্রহ করে আবার চেষ্টা করুন।');
      return;
    }

    const newDonor: Donor = {
      id: `donor-${Date.now()}`,
      name: name.trim(),
      bloodGroup,
      phone: phone.trim(),
      district,
      upazila,
      union: union.trim(),
      village: village.trim(),
      area: `${village.trim()}, ${union.trim()}`,
      age: Number(age) || 24,
      gender,
      password,
      lastDonationDate: null,
      totalDonations: 0,
      isAvailable: true,
      isCurrentUser: true,
      history: [],
      createdAt: new Date().toISOString().split('T')[0],
    };

    onLoginSuccess(newDonor);
  };

  // Login handler
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!loginPhone.trim() || !loginPassword.trim()) {
      setFormError('মোবাইল নম্বর ও পাসওয়ার্ড লিখুন।');
      return;
    }

    // Search existing donor
    const match = existingDonors.find(
      (d) => d.phone.replace(/[^0-9]/g, '') === loginPhone.replace(/[^0-9]/g, '')
    );

    if (!match) {
      setFormError('এই মোবাইল নম্বরে কোনো অ্যাকাউন্ট পাওয়া যায়নি। অনুগ্রহ করে নতুন নিবন্ধন করুন।');
      return;
    }

    if (match.password && match.password !== loginPassword) {
      setFormError('ভুল পাসওয়ার্ড! সঠিক পাসওয়ার্ড দিন।');
      return;
    }

    // Login successful
    onLoginSuccess({
      ...match,
      isCurrentUser: true,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-neutral-200 my-6 space-y-6 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Brand Header */}
        <div className="text-center space-y-2 pb-2 border-b border-neutral-100">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-br from-red-600 to-rose-700 text-white flex items-center justify-center shadow-md">
            <Droplets className="w-8 h-8 fill-white" />
          </div>
          <h2 className="text-2xl font-black text-neutral-900 tracking-tight">
            ফরিদপুর ব্লাড ব্যাংক
          </h2>
          <p className="text-xs text-neutral-500 max-w-md mx-auto">
            রক্তদাতা ও গ্রহীতাদের সমন্বিত মানবিক প্ল্যাটফর্মে আপনাকে স্বাগতম। অ্যাপে প্রবেশের জন্য লগইন বা নিবন্ধন আবশ্যক।
          </p>
        </div>

        {/* Tab switcher: Register vs Login */}
        {step === 'form' && (
          <div className="flex items-center bg-neutral-100 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => {
                setTab('register');
                setFormError('');
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                tab === 'register'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              নতুন অ্যাকাউন্ট নিবন্ধন (Sign Up)
            </button>
            <button
              type="button"
              onClick={() => {
                setTab('login');
                setFormError('');
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                tab === 'login'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              পূর্ববর্তী অ্যাকাউন্টে লগইন
            </button>
          </div>
        )}

        {formError && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            <span>{formError}</span>
          </div>
        )}

        {/* ===================== TAB 1: REGISTRATION ===================== */}
        {tab === 'register' && step === 'form' && (
          <form onSubmit={handleRegisterSubmit} className="space-y-4 text-xs">
            
            {/* Name & Blood Group */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="block font-semibold text-neutral-700 mb-1">
                  আপনার পুরো নাম *
                </label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: মোঃ সাকিব হোসেন"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full text-sm border border-neutral-300 rounded-xl p-2.5 focus:border-red-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-700 mb-1">
                  রক্তের গ্রুপ *
                </label>
                <select
                  value={bloodGroup}
                  onChange={(e) => setBloodGroup(e.target.value as BloodGroup)}
                  className="w-full text-sm border border-neutral-300 rounded-xl p-2.5 focus:border-red-500 focus:outline-none font-bold text-red-600 bg-white"
                >
                  {BLOOD_GROUPS.map((grp) => (
                    <option key={grp} value={grp}>
                      {grp}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Phone Number */}
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                মোবাইল নম্বর (ওটিপি পাঠানো হবে) *
              </label>
              <div className="relative">
                <input
                  type="tel"
                  required
                  placeholder="017XXXXXXXX"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full text-sm border border-neutral-300 rounded-xl p-2.5 pl-9 focus:border-red-500 focus:outline-none font-mono font-medium"
                />
                <Phone className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
              </div>
            </div>

            {/* District & Upazila */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-neutral-700 mb-1">
                  জেলা *
                </label>
                <select
                  value={district}
                  onChange={(e) => handleDistrictChange(e.target.value)}
                  className="w-full text-sm border border-neutral-300 rounded-xl p-2.5 focus:border-red-500 focus:outline-none bg-white font-medium"
                >
                  {ALLOWED_DISTRICTS.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-neutral-700 mb-1">
                  উপজেলা *
                </label>
                <select
                  value={upazila}
                  onChange={(e) => setUpazila(e.target.value)}
                  className="w-full text-sm border border-neutral-300 rounded-xl p-2.5 focus:border-red-500 focus:outline-none bg-white font-medium"
                >
                  {currentUpazilas.map((u) => (
                    <option key={u} value={u}>
                      {u}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Union & Village (User explicit requirement) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-neutral-700 mb-1">
                  ইউনিয়ন / পৌরসভার নাম *
                </label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: মাচ্চর ইউনিয়ন / পৌরসভা"
                  value={union}
                  onChange={(e) => setUnion(e.target.value)}
                  className="w-full text-sm border border-neutral-300 rounded-xl p-2.5 focus:border-red-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-700 mb-1">
                  গ্রাম / মহল্লা ও ঠিকানা *
                </label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: শিবরামপুর গ্রাম / ঝিলটুলী"
                  value={village}
                  onChange={(e) => setVillage(e.target.value)}
                  className="w-full text-sm border border-neutral-300 rounded-xl p-2.5 focus:border-red-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Age & Gender */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-neutral-700 mb-1">
                  বয়স (১৮-৬০ বছর) *
                </label>
                <input
                  type="number"
                  min="18"
                  max="65"
                  required
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full text-sm border border-neutral-300 rounded-xl p-2.5 focus:border-red-500 focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-700 mb-1">
                  লিঙ্গ
                </label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as any)}
                  className="w-full text-sm border border-neutral-300 rounded-xl p-2.5 focus:border-red-500 focus:outline-none bg-white"
                >
                  <option value="পুরুষ">পুরুষ</option>
                  <option value="মহিলা">মহিলা</option>
                  <option value="অন্যান্য">অন্যান্য</option>
                </select>
              </div>
            </div>

            {/* Password & Confirm */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-neutral-700 mb-1">
                  পাসওয়ার্ড নির্ধারণ করুন *
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="পাসওয়ার্ড লিখুন"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full text-sm border border-neutral-300 rounded-xl p-2.5 pr-9 focus:border-red-500 focus:outline-none font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-neutral-400 hover:text-neutral-700 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-neutral-700 mb-1">
                  পাসওয়ার্ড নিশ্চিত করুন *
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="পুনরায় পাসওয়ার্ড লিখুন"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full text-sm border border-neutral-300 rounded-xl p-2.5 focus:border-red-500 focus:outline-none font-mono"
                />
              </div>
            </div>

            {/* Action */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm font-bold transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-xs"
              >
                <span>ওটিপি কোড পাঠান ও এগিয়ে যান</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </form>
        )}

        {/* ===================== STEP 2: OTP VERIFICATION ===================== */}
        {tab === 'register' && step === 'otp' && (
          <form onSubmit={handleVerifyOtp} className="space-y-5 text-center">
            
            <div className="w-16 h-16 mx-auto rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-200">
              <KeyRound className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h3 className="text-lg font-bold text-neutral-900">
                মোবাইল নম্বর ওটিপি যাচাইকরণ
              </h3>
              <p className="text-xs text-neutral-500">
                আপনার নম্বর <strong>{phone}</strong>-এ ৪ সংখ্যার ওটিপি পাঠানো হয়েছে।
              </p>
            </div>

            {/* OTP Simulator Box */}
            <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-center justify-between">
              <div className="text-left">
                <span className="font-bold block text-[11px] text-amber-700">সিমুলেটেড ওটিপি কোড:</span>
                <span className="font-mono text-base font-extrabold tracking-widest text-amber-950">
                  {generatedOtp}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setEnteredOtp(generatedOtp)}
                className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-2xs"
              >
                স্বয়ংক্রিয় বসান
              </button>
            </div>

            {/* OTP Input */}
            <div className="space-y-1">
              <label className="block text-xs font-semibold text-neutral-700">
                ৪ সংখ্যার ওটিপি লিখুন *
              </label>
              <input
                type="text"
                maxLength={4}
                required
                autoFocus
                placeholder="____"
                value={enteredOtp}
                onChange={(e) => setEnteredOtp(e.target.value.replace(/[^0-9]/g, ''))}
                className="w-44 mx-auto text-center text-2xl font-mono font-bold tracking-widest border-2 border-neutral-300 focus:border-red-500 rounded-xl p-2.5 outline-none bg-neutral-50"
              />
            </div>

            {otpError && (
              <p className="text-xs text-red-600 font-semibold">{otpError}</p>
            )}

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setStep('form')}
                className="px-4 py-2 text-xs font-semibold text-neutral-600 hover:bg-neutral-100 rounded-lg cursor-pointer"
              >
                তথ্য পরিবর্তন
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-xs flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>যাচাই ও নিবন্ধন সম্পন্ন করুন</span>
              </button>
            </div>

          </form>
        )}

        {/* ===================== TAB 2: EXISTING USER LOGIN ===================== */}
        {tab === 'login' && (
          <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
            
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                নিবন্ধিত মোবাইল নম্বর *
              </label>
              <div className="relative">
                <input
                  type="tel"
                  required
                  placeholder="017XXXXXXXX"
                  value={loginPhone}
                  onChange={(e) => setLoginPhone(e.target.value)}
                  className="w-full text-sm border border-neutral-300 rounded-xl p-2.5 pl-9 focus:border-red-500 focus:outline-none font-mono font-medium"
                />
                <Phone className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                পাসওয়ার্ড *
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="আপনার পাসওয়ার্ড লিখুন"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full text-sm border border-neutral-300 rounded-xl p-2.5 pl-9 pr-9 focus:border-red-500 focus:outline-none font-mono"
                />
                <Lock className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-neutral-400 hover:text-neutral-700 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm font-bold transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-xs"
              >
                <span>লগইন করুন</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="text-center pt-2">
              <p className="text-xs text-neutral-500">
                অ্যাকাউন্ট নেই?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setTab('register');
                    setStep('form');
                    setFormError('');
                  }}
                  className="text-red-600 font-bold hover:underline cursor-pointer"
                >
                  নতুন অ্যাকাউন্ট খুলুন
                </button>
              </p>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
