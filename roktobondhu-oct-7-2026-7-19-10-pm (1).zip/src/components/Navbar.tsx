import React, { useState, useRef, useEffect } from 'react';
import {
  Bell,
  Droplets,
  MoreHorizontal,
  Home,
  Users,
  AlertTriangle,
  Clock,
  Camera,
  BookOpen,
  UserPlus,
  PlusCircle,
  X,
  ShieldAlert,
  Smartphone,
  Globe,
  Lock,
  User,
  Phone,
} from 'lucide-react';
import { toBengaliNumber } from '../utils/bloodLogic';

export type NavTab = 'home' | 'directory' | 'requests' | 'tracker' | 'stories' | 'guidelines' | 'admin' | 'profile';

interface NavbarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  unreadCount: number;
  viewMode: 'web' | 'mobile_app';
  setViewMode: (mode: 'web' | 'mobile_app') => void;
  onOpenNotifications: () => void;
  onOpenAddRequest: () => void;
  onOpenRegisterDonor: () => void;
  onOpenUploadStory: () => void;
  onOpenComplaintBox: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  unreadCount,
  viewMode,
  setViewMode,
  onOpenNotifications,
  onOpenAddRequest,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-neutral-200 shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Brand Zone with Unique Logo */}
        <div className="flex items-center gap-3">
          <img
            src="/src/assets/images/faridpur_blood_bank_logo_1791373672363.jpg"
            alt="Faridpur Blood Bank Logo"
            className="w-11 h-11 rounded-2xl object-cover shadow-xs border border-red-200"
          />
          <div className="leading-tight">
            <span className="text-xl font-black tracking-tight text-neutral-900 block">
              ফরিদপুর ব্লাড ব্যাংক
            </span>
            <span className="text-[11px] text-red-700 font-semibold tracking-tight hidden sm:block">
              Faridpur Blood Bank · ৫ জেলা সমন্বিত প্ল্যাটফর্ম
            </span>
          </div>
        </div>

        {/* Right Actions: Post Request, Notification Bell, Hotline */}
        <div className="flex items-center gap-2.5">
          
          {/* Quick Call Emergency Helpline */}
          <a
            href="tel:063162272"
            className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-xl text-xs font-semibold transition-colors"
            title="ফরিদপুর মেডিকেল হেল্পলাইন"
          >
            <Phone className="w-3.5 h-3.5 text-red-600" />
            <span>হেল্পলাইন: ০৬৩১-৬২২৭২</span>
          </a>

          {/* Web / Mobile Mode Toggle */}
          <div className="hidden sm:flex items-center bg-neutral-100 p-0.5 rounded-lg border border-neutral-200 text-xs">
            <button
              type="button"
              onClick={() => setViewMode('web')}
              className={`px-2 py-1 rounded-md transition-colors font-medium flex items-center gap-1 cursor-pointer ${
                viewMode === 'web'
                  ? 'bg-white text-neutral-900 shadow-2xs font-semibold'
                  : 'text-neutral-500 hover:text-neutral-900'
              }`}
              title="ওয়েব ভার্সন"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>ওয়েব</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('mobile_app')}
              className={`px-2 py-1 rounded-md transition-colors font-medium flex items-center gap-1 cursor-pointer ${
                viewMode === 'mobile_app'
                  ? 'bg-red-600 text-white shadow-2xs font-semibold'
                  : 'text-neutral-500 hover:text-neutral-900'
              }`}
              title="অ্যাপ ভার্সন"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>অ্যাপ</span>
            </button>
          </div>

          {/* Emergency Blood Request CTA */}
          <button
            type="button"
            onClick={onOpenAddRequest}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span className="hidden sm:inline">রক্তের আবেদন পোস্ট করুন</span>
            <span className="sm:hidden">আবেদন</span>
          </button>

          {/* Notification Bell */}
          <button
            type="button"
            onClick={onOpenNotifications}
            aria-label="বিজ্ঞপ্তি দেখুন"
            className="relative p-2 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-xl transition-colors cursor-pointer"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-red-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center font-mono ring-2 ring-white">
                {toBengaliNumber(unreadCount)}
              </span>
            )}
          </button>

        </div>

      </div>
    </header>
  );
};

