import React from 'react';
import { AppNotification } from '../types';
import { playNotificationChime } from '../utils/bloodLogic';
import { X, Bell, CheckCheck, Trash2, Volume2, Sparkles, AlertCircle, CheckCircle2 } from 'lucide-react';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: AppNotification[];
  onMarkAllAsRead: () => void;
  onClearAll: () => void;
  onNotificationClick: (notif: AppNotification) => void;
  onTriggerTestNotif: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAllAsRead,
  onClearAll,
  onNotificationClick,
  onTriggerTestNotif,
}) => {
  if (!isOpen) return null;

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/35 backdrop-blur-xs">
      <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col justify-between border-l border-neutral-200 animate-in slide-in-from-right duration-200">
        
        {/* Top Header */}
        <div className="p-5 border-b border-neutral-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-red-100 text-red-700 flex items-center justify-center">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-neutral-900">নোটিফিকেশন সেন্টার</h2>
              <p className="text-xs text-neutral-500">
                {unreadCount > 0 ? `${unreadCount}টি অপঠিত বার্তা আছে` : 'সকল বার্তা পড়া হয়েছে'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => playNotificationChime()}
              className="p-2 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg cursor-pointer"
              title="সাউন্ড পরীক্ষা করুন"
            >
              <Volume2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 rounded-lg cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Action Toolbar */}
        <div className="px-5 py-2.5 bg-neutral-50 border-b border-neutral-100 flex items-center justify-between text-xs">
          <button
            onClick={onTriggerTestNotif}
            className="flex items-center gap-1 text-red-700 hover:text-red-800 font-semibold cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>টেস্ট এলার্ট পাঠান</span>
          </button>

          <div className="flex items-center gap-3">
            {unreadCount > 0 && (
              <button
                onClick={onMarkAllAsRead}
                className="flex items-center gap-1 text-neutral-600 hover:text-neutral-900 cursor-pointer"
              >
                <CheckCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>সব পঠিত</span>
              </button>
            )}

            {notifications.length > 0 && (
              <button
                onClick={onClearAll}
                className="flex items-center gap-1 text-neutral-500 hover:text-red-600 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>মুছুন</span>
              </button>
            )}
          </div>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {notifications.length > 0 ? (
            notifications.map((notif) => {
              const isReadyType = notif.type === 'eligibility_ready';
              const isReqType = notif.type === 'blood_request';

              return (
                <div
                  key={notif.id}
                  onClick={() => onNotificationClick(notif)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer relative ${
                    notif.read
                      ? 'bg-neutral-50/70 border-neutral-200 text-neutral-600'
                      : 'bg-white border-neutral-300 shadow-xs'
                  } ${
                    isReadyType && !notif.read ? 'border-emerald-300 bg-emerald-50/30' : ''
                  } ${
                    isReqType && !notif.read ? 'border-red-300 bg-red-50/30' : ''
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5 shrink-0">
                      {isReadyType ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      ) : isReqType ? (
                        <AlertCircle className="w-5 h-5 text-red-600" />
                      ) : (
                        <Bell className="w-5 h-5 text-neutral-500" />
                      )}
                    </div>

                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <h3 className={`text-xs font-bold leading-tight ${notif.read ? 'text-neutral-700' : 'text-neutral-900'}`}>
                          {notif.title}
                        </h3>
                        {!notif.read && (
                          <span className="w-2 h-2 rounded-full bg-red-600 shrink-0" />
                        )}
                      </div>

                      <p className="text-xs text-neutral-600 leading-relaxed">
                        {notif.message}
                      </p>

                      <div className="flex items-center justify-between pt-1 text-[11px] text-neutral-400">
                        <span>{notif.timestamp}</span>
                        {notif.relatedBloodGroup && (
                          <span className="font-mono font-bold text-red-600">
                            {notif.relatedBloodGroup}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 text-neutral-400">
              <Bell className="w-10 h-10 mb-2 opacity-30" />
              <p className="text-sm font-semibold text-neutral-700">কোনো নোটিফিকেশন নেই</p>
              <p className="text-xs text-neutral-400 mt-1">
                ৪ মাস পূর্ণ হলে অথবা রক্তের নতুন আবেদন আসলে এখানে নোটিফিকেশন দেখতে পাবেন।
              </p>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-4 border-t border-neutral-200 bg-neutral-50 text-center">
          <p className="text-xs text-neutral-500">
            রক্তবন্ধু রিয়েল-টাইম এলার্ট সিস্টেম সক্রিয় রয়েছে
          </p>
        </div>

      </div>
    </div>
  );
};
