import React, { useState } from 'react';
import { BloodGroup, Donor, UnavailabilityInfo } from '../types';
import { ALLOWED_DISTRICTS, getUpazilasForDistrict, BLOOD_GROUPS } from '../data/bangladeshDistricts';
import { X, UserCheck, Camera, User, PhoneOff, ShieldAlert } from 'lucide-react';

interface UpdateProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: Donor;
  onSave: (updatedUser: Donor) => void;
}

export const UpdateProfileModal: React.FC<UpdateProfileModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSave,
}) => {
  const [name, setName] = useState(currentUser.name);
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>(currentUser.bloodGroup);
  const [phone, setPhone] = useState(currentUser.phone);
  const [altPhone, setAltPhone] = useState(currentUser.altPhone || '');
  const [email, setEmail] = useState(currentUser.email || '');
  const [profilePicture, setProfilePicture] = useState<string | null>(currentUser.profilePicture || null);
  const [district, setDistrict] = useState(currentUser.district || 'ফরিদপুর');
  const [upazila, setUpazila] = useState(currentUser.upazila || 'ফরিদপুর সদর');
  const [union, setUnion] = useState(currentUser.union || '');
  const [village, setVillage] = useState(currentUser.village || '');
  const [area, setArea] = useState(currentUser.area);
  const [age, setAge] = useState(currentUser.age);
  const [lastDonationDate, setLastDonationDate] = useState(currentUser.lastDonationDate || '');
  const [unavailType, setUnavailType] = useState<'available' | 'illness' | 'out_of_district' | 'other'>(
    currentUser.unavailability?.type || (currentUser.isAvailable ? 'available' : 'other')
  );
  const [customDetails, setCustomDetails] = useState(currentUser.unavailability?.customDetails || '');

  if (!isOpen) return null;

  const handleProfileImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setProfilePicture(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const currentUpazilas = getUpazilasForDistrict(district);

  const handleDistrictChange = (newDistrict: string) => {
    setDistrict(newDistrict);
    const upazilas = getUpazilasForDistrict(newDistrict);
    if (upazilas.length > 0) {
      setUpazila(upazilas[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) return;

    const isAvailableNow = unavailType === 'available';
    let unavailabilityData = null;
    if (unavailType === 'illness') {
      unavailabilityData = {
        type: 'illness' as const,
        label: 'অসুস্থ / শারীরিক অসুস্থতা',
      };
    } else if (unavailType === 'out_of_district') {
      unavailabilityData = {
        type: 'out_of_district' as const,
        label: 'জেলার বাইরে অবস্থান করছেন',
      };
    } else if (unavailType === 'other') {
      unavailabilityData = {
        type: 'other' as const,
        label: 'অন্যান্য কারণে রক্তদানে অপারগ',
        customDetails: customDetails.trim() || undefined,
      };
    }

    const updated: Donor = {
      ...currentUser,
      name: name.trim(),
      bloodGroup,
      phone: phone.trim(),
      altPhone: altPhone.trim() || undefined,
      email: email.trim() || undefined,
      profilePicture: profilePicture || undefined,
      district,
      upazila,
      union: union.trim(),
      village: village.trim(),
      area: village.trim() ? `${village.trim()}, ${union.trim() || upazila}` : area.trim(),
      age: Number(age) || 25,
      lastDonationDate: lastDonationDate || null,
      isAvailable: isAvailableNow,
      unavailability: unavailabilityData,
    };

    onSave(updated);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-neutral-200 my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <UserCheck className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-neutral-900">প্রোফাইল ও তথ্য আপডেট করুন</h2>
              <p className="text-xs text-neutral-500">
                ব্লাড গ্রুপ, মোবাইল নম্বর, উপজেলা ও শেষ রক্তদানের তথ্য পরিবর্তন করুন
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-4 text-xs">
          
          {/* Profile Picture Upload & Preview */}
          <div className="flex items-center gap-4 p-3 bg-neutral-50 rounded-xl border border-neutral-200">
            <div className="relative shrink-0">
              {profilePicture ? (
                <img
                  src={profilePicture}
                  alt={name}
                  className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-500 shadow-xs"
                />
              ) : (
                <div className="w-16 h-16 rounded-2xl bg-neutral-200 text-neutral-500 flex flex-col items-center justify-center border border-dashed border-neutral-300">
                  <User className="w-6 h-6 text-neutral-400" />
                  <span className="text-[9px] mt-0.5">ছবি নেই</span>
                </div>
              )}
            </div>

            <div className="space-y-1 flex-1">
              <label className="block font-semibold text-neutral-800">
                প্রোফাইল ছবি পরিবর্তন
              </label>
              <div className="flex items-center gap-2">
                <label className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-lg text-xs font-semibold text-neutral-700 cursor-pointer shadow-2xs">
                  <Camera className="w-3.5 h-3.5 text-red-600" />
                  <span>নতুন ছবি সিলেক্ট করুন</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleProfileImageChange}
                    className="sr-only"
                  />
                </label>
                {profilePicture && (
                  <button
                    type="button"
                    onClick={() => setProfilePicture(null)}
                    className="text-xs text-red-600 hover:underline cursor-pointer"
                  >
                    ছবি সরান
                  </button>
                )}
              </div>
              <p className="text-[10px] text-neutral-400">আপনার ছবি রক্তদাতা কার্ড ও ডিরেক্টরিতে প্রদর্শিত হবে</p>
            </div>
          </div>

          {/* Name & Blood Group */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block font-semibold text-neutral-700 mb-1">
                আপনার নাম *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                রক্তের গ্রুপ *
              </label>
              <select
                value={bloodGroup}
                onChange={(e) => setBloodGroup(e.target.value as BloodGroup)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none font-mono font-bold text-red-600 bg-white"
              >
                {BLOOD_GROUPS.map((grp) => (
                  <option key={grp} value={grp}>
                    {grp}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Phone Numbers & Email */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                মোবাইল নম্বর *
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                বিকল্প নম্বর
              </label>
              <input
                type="tel"
                value={altPhone}
                onChange={(e) => setAltPhone(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                ইমেইল এড্রেস
              </label>
              <input
                type="email"
                placeholder="name@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>
          </div>

          {/* District & Upazila */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                জেলা *
              </label>
              <select
                value={district}
                onChange={(e) => handleDistrictChange(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none bg-white font-medium"
              >
                {ALLOWED_DISTRICTS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                উপজেলা *
              </label>
              <select
                value={upazila}
                onChange={(e) => setUpazila(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none bg-white font-medium"
              >
                {currentUpazilas.map((u) => (
                  <option key={u} value={u}>
                    {u}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Area */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              বর্তমান এলাকা বা ঠিকানা *
            </label>
            <input
              type="text"
              required
              value={area}
              onChange={(e) => setArea(e.target.value)}
              className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
            />
          </div>

          {/* Last Donation Date */}
          <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200">
            <label className="block font-semibold text-neutral-800 mb-1">
              শেষ রক্তদানের তারিখ (৪-মাস চক্রের ভিত্তি)
            </label>
            <input
              type="date"
              value={lastDonationDate}
              onChange={(e) => setLastDonationDate(e.target.value)}
              className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none bg-white"
            />
            <p className="text-[11px] text-neutral-500 mt-1">
              তারিখ খালি রাখলে আপনি যেকোনো সময় প্রস্তুত বলে গণ্য হবেন।
            </p>
          </div>

          {/* UNAVAILABILITY & CALL CONTROL OPTIONS (User requirement: অসুস্থ, ৫ জেলার বাইরে, অন্যান্য) */}
          <div className="p-4 bg-amber-50/60 rounded-xl border border-amber-200 space-y-3">
            <div className="flex items-start gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-700 mt-0.5 shrink-0" />
              <div>
                <label className="font-bold text-neutral-900 block text-xs">
                  রক্তদানের উপস্থিতি ও কল গ্রহণ নিয়ন্ত্রণ *
                </label>
                <p className="text-[11px] text-neutral-600 mt-0.5">
                  আপনি যদি রক্ত দিতে না চান, অসুস্থ থাকেন বা জেলার বাইরে থাকেন তবে নিচের অপশনে টিক দিন। এতে আপনার প্রোফাইলে <strong>কল করার অপশন বন্ধ হয়ে যাবে</strong>:
                </p>
              </div>
            </div>

            <div className="space-y-2 pt-1">
              <label className={`flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                unavailType === 'available'
                  ? 'bg-emerald-50 border-emerald-400 text-emerald-950 font-semibold'
                  : 'bg-white border-neutral-200 text-neutral-700 hover:bg-neutral-50'
              }`}>
                <input
                  type="radio"
                  name="modalUnavail"
                  checked={unavailType === 'available'}
                  onChange={() => setUnavailType('available')}
                  className="mt-0.5 text-emerald-600"
                />
                <span className="text-xs">
                  ✅ আমি বর্তমানে প্রস্তুত এবং সুস্থ (কল রিসিভ করতে পারব)
                </span>
              </label>

              <label className={`flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                unavailType === 'illness'
                  ? 'bg-amber-100/80 border-amber-400 text-amber-950 font-semibold'
                  : 'bg-white border-neutral-200 text-neutral-700 hover:bg-neutral-50'
              }`}>
                <input
                  type="radio"
                  name="modalUnavail"
                  checked={unavailType === 'illness'}
                  onChange={() => setUnavailType('illness')}
                  className="mt-0.5 text-amber-600"
                />
                <span className="text-xs">
                  🤒 অসুস্থ / শারীরিক দুর্বলতা (কল গ্রহণ বন্ধ থাকবে)
                </span>
              </label>

              <label className={`flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                unavailType === 'out_of_district'
                  ? 'bg-amber-100/80 border-amber-400 text-amber-950 font-semibold'
                  : 'bg-white border-neutral-200 text-neutral-700 hover:bg-neutral-50'
              }`}>
                <input
                  type="radio"
                  name="modalUnavail"
                  checked={unavailType === 'out_of_district'}
                  onChange={() => setUnavailType('out_of_district')}
                  className="mt-0.5 text-amber-600"
                />
                <span className="text-xs">
                  🚗 এই জেলাগুলোর বাইরে অবস্থান করছি (কল গ্রহণ বন্ধ থাকবে)
                </span>
              </label>

              <label className={`flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                unavailType === 'other'
                  ? 'bg-amber-100/80 border-amber-400 text-amber-950 font-semibold'
                  : 'bg-white border-neutral-200 text-neutral-700 hover:bg-neutral-50'
              }`}>
                <input
                  type="radio"
                  name="modalUnavail"
                  checked={unavailType === 'other'}
                  onChange={() => setUnavailType('other')}
                  className="mt-0.5 text-amber-600"
                />
                <span className="text-xs">
                  📝 অন্যান্য কারণ (নিচে বিস্তারিত লিখুন, কল গ্রহণ বন্ধ থাকবে)
                </span>
              </label>
            </div>

            {unavailType === 'other' && (
              <div className="pt-1">
                <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                  অন্যান্য কারণটির বিস্তারিত বিবরণ লিখুন:
                </label>
                <input
                  type="text"
                  placeholder="যেমন: পরীক্ষার প্রস্তুতি, পারিবারিক ব্যস্ততা..."
                  value={customDetails}
                  onChange={(e) => setCustomDetails(e.target.value)}
                  className="w-full text-xs bg-white border border-neutral-300 rounded-lg p-2 focus:border-red-500 focus:outline-none"
                />
              </div>
            )}
          </div>

          {/* Submit buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 font-semibold text-neutral-600 hover:bg-neutral-100 rounded-lg cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              আপডেট সংরক্ষণ করুন
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
