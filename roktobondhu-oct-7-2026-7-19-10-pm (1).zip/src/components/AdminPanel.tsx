import React, { useState } from 'react';
import { Donor, RecipientProfile, BloodBooking, Complaint } from '../types';
import { toBengaliNumber } from '../utils/bloodLogic';
import {
  ShieldAlert,
  Trash2,
  Ban,
  CheckCircle2,
  Calendar,
  UserCheck,
  UserX,
  Plus,
  AlertTriangle,
  MessageSquare,
  Search,
} from 'lucide-react';

interface AdminPanelProps {
  donors: Donor[];
  recipients: RecipientProfile[];
  bookings: BloodBooking[];
  complaints: Complaint[];
  onDeleteDonor: (donorId: string, reason: string) => void;
  onBlockDonor: (donorId: string, reason: string) => void;
  onDeleteRecipient: (recipientId: string, reason: string) => void;
  onConfirmDonationDone: (bookingId: string) => void;
  onResolveComplaint: (complaintId: string, adminNotes: string) => void;
  onOpenAddDonor: () => void;
  onOpenAddRequest: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  donors,
  recipients,
  bookings,
  complaints,
  onDeleteDonor,
  onBlockDonor,
  onDeleteRecipient,
  onConfirmDonationDone,
  onResolveComplaint,
  onOpenAddDonor,
  onOpenAddRequest,
}) => {
  const [activeAdminTab, setActiveAdminTab] = useState<'donors' | 'recipients' | 'bookings' | 'complaints'>('donors');
  const [searchTerm, setSearchTerm] = useState('');
  
  // State for delete/block action modal with reason
  const [targetAction, setTargetAction] = useState<{
    type: 'delete_donor' | 'block_donor' | 'delete_recipient';
    id: string;
    name: string;
  } | null>(null);
  const [actionReason, setActionReason] = useState('');

  const handleConfirmAction = () => {
    if (!targetAction || !actionReason.trim()) return;

    if (targetAction.type === 'delete_donor') {
      onDeleteDonor(targetAction.id, actionReason.trim());
    } else if (targetAction.type === 'block_donor') {
      onBlockDonor(targetAction.id, actionReason.trim());
    } else if (targetAction.type === 'delete_recipient') {
      onDeleteRecipient(targetAction.id, actionReason.trim());
    }

    setTargetAction(null);
    setActionReason('');
  };

  const pendingComplaintsCount = complaints.filter((c) => c.status === 'pending').length;
  const activeBookingsCount = bookings.filter((b) => b.status === 'booked').length;

  return (
    <div className="space-y-6">
      
      {/* Admin Title & Security Status */}
      <div className="bg-neutral-900 text-white rounded-2xl p-6 shadow-md border border-neutral-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 bg-red-600 text-white text-[10px] font-bold uppercase rounded-md tracking-wider">
              মালিক / অ্যাডমিন নিয়ন্ত্রণ কক্ষ
            </span>
            <span className="text-xs text-neutral-400">সর্বোচ্চ প্রশাসনিক ক্ষমতা</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold mt-1 tracking-tight">
            আইডি নিয়ন্ত্রণ, বুকিং পর্যবেক্ষণ ও অভিযোগ সেল
          </h2>
          <p className="text-xs text-neutral-300 mt-1">
            দাতা ও গ্রহীতাদের আইডি অনুমোদন, কারণ উল্লেখ করে ডিলিট/ব্লক এবং অভিযোগ নিষ্পত্তির নিয়ন্ত্রণ
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={onOpenAddDonor}
            className="px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
          >
            + নতুন ডোনার অ্যাড
          </button>
          <button
            type="button"
            onClick={onOpenAddRequest}
            className="px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            + জরুরি রিকোয়েস্ট অ্যাড
          </button>
        </div>
      </div>

      {/* Admin Tab Navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 bg-white p-2 rounded-xl border border-neutral-200">
        <button
          onClick={() => setActiveAdminTab('donors')}
          className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
            activeAdminTab === 'donors'
              ? 'bg-neutral-900 text-white shadow-xs'
              : 'text-neutral-600 hover:bg-neutral-100'
          }`}
        >
          রক্তদাতা আইডি ({toBengaliNumber(donors.length)})
        </button>

        <button
          onClick={() => setActiveAdminTab('recipients')}
          className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
            activeAdminTab === 'recipients'
              ? 'bg-neutral-900 text-white shadow-xs'
              : 'text-neutral-600 hover:bg-neutral-100'
          }`}
        >
          গ্রহীতা আইডি ({toBengaliNumber(recipients.length)})
        </button>

        <button
          onClick={() => setActiveAdminTab('bookings')}
          className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer relative ${
            activeAdminTab === 'bookings'
              ? 'bg-neutral-900 text-white shadow-xs'
              : 'text-neutral-600 hover:bg-neutral-100'
          }`}
        >
          <span>অগ্রিম বুকিং শিডিউল ({toBengaliNumber(activeBookingsCount)})</span>
          {activeBookingsCount > 0 && (
            <span className="w-2 h-2 rounded-full bg-red-500 inline-block ml-1" />
          )}
        </button>

        <button
          onClick={() => setActiveAdminTab('complaints')}
          className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 ${
            activeAdminTab === 'complaints'
              ? 'bg-red-600 text-white shadow-xs'
              : 'text-red-700 hover:bg-red-50 font-bold'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>অভিযোগ সেল ({toBengaliNumber(pendingComplaintsCount)} অপঠিত)</span>
        </button>
      </div>

      {/* Search Input */}
      <div className="relative max-w-sm">
        <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="নাম, ফোন নম্বর বা উপজেলা দিয়ে খুঁজুন..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-8 pr-3 py-2 text-xs bg-white border border-neutral-200 rounded-lg focus:outline-none focus:border-red-500"
        />
      </div>

      {/* TAB 1: DONORS MANAGEMENT */}
      {activeAdminTab === 'donors' && (
        <div className="bg-white rounded-2xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-neutral-100 flex items-center justify-between">
            <h3 className="font-bold text-sm text-neutral-900">
              নিবন্ধিত রক্তদাতাদের নিয়ন্ত্রণ (ফরিদপুর, মাদারীপুর, গোপালগঞ্জ, রাজবাড়ী, মাগুরা)
            </h3>
            <span className="text-xs text-neutral-500 font-mono">
              মোট: {toBengaliNumber(donors.length)} জন
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-neutral-600">
              <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-800 font-semibold">
                <tr>
                  <th className="p-3">রক্তদাতা</th>
                  <th className="p-3">গ্রুপ</th>
                  <th className="p-3">মোবাইল</th>
                  <th className="p-3">উপজেলা ও জেলা</th>
                  <th className="p-3">বুকিং স্ট্যাটাস</th>
                  <th className="p-3 text-right">মালিকের অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {donors
                  .filter((d) => d.name.includes(searchTerm) || d.phone.includes(searchTerm) || d.upazila.includes(searchTerm))
                  .map((donor) => {
                    const booking = bookings.find((b) => b.donorId === donor.id && b.status === 'booked');

                    return (
                      <tr key={donor.id} className="hover:bg-neutral-50/60">
                        <td className="p-3">
                          <div className="font-bold text-neutral-900">{donor.name}</div>
                          <div className="text-[11px] text-neutral-400">রক্তদান: {toBengaliNumber(donor.totalDonations)} বার</div>
                        </td>
                        <td className="p-3 font-mono font-bold text-red-600 text-sm">
                          {donor.bloodGroup}
                        </td>
                        <td className="p-3 font-mono text-neutral-700">
                          {donor.phone}
                        </td>
                        <td className="p-3">
                          {donor.upazila}, {donor.district}
                        </td>
                        <td className="p-3">
                          {booking ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                              🔒 বুকড ({booking.patientName}-এর জন্য)
                            </span>
                          ) : (
                            <span className="text-[11px] text-emerald-700 font-medium">উপলব্ধ</span>
                          )}
                          {donor.isBlocked && (
                            <span className="ml-1 inline-block text-[10px] text-red-700 bg-red-100 px-1.5 py-0.5 rounded font-bold">
                              ব্লকড: {donor.blockReason}
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-right space-x-1.5">
                          {!donor.isBlocked ? (
                            <button
                              type="button"
                              onClick={() =>
                                setTargetAction({
                                  type: 'block_donor',
                                  id: donor.id,
                                  name: donor.name,
                                })
                              }
                              className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded font-medium cursor-pointer"
                              title="আইডি সাময়িক ব্লক করুন"
                            >
                              ব্লক
                            </button>
                          ) : null}

                          <button
                            type="button"
                            onClick={() =>
                              setTargetAction({
                                type: 'delete_donor',
                                id: donor.id,
                                name: donor.name,
                              })
                            }
                            className="px-2 py-1 bg-red-50 hover:bg-red-100 text-red-700 rounded font-medium cursor-pointer"
                            title="আইডি স্থায়ীভাবে ডিলিট করুন"
                          >
                            ডিলিট
                          </button>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: RECIPIENTS MANAGEMENT */}
      {activeAdminTab === 'recipients' && (
        <div className="bg-white rounded-2xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-neutral-100 flex items-center justify-between">
            <h3 className="font-bold text-sm text-neutral-900">
              রক্ত গ্রহীতা ও রোগীর আবেদনকারী আইডি তালিকা
            </h3>
            <span className="text-xs text-neutral-500 font-mono">
              মোট: {toBengaliNumber(recipients.length)} জন
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-neutral-600">
              <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-800 font-semibold">
                <tr>
                  <th className="p-3">গ্রহীতার নাম</th>
                  <th className="p-3">রোগীর নাম ও অবস্থা</th>
                  <th className="p-3">প্রয়োজনীয় গ্রুপ</th>
                  <th className="p-3">হাসপাতাল ও এলাকা</th>
                  <th className="p-3">মোবাইল নম্বর</th>
                  <th className="p-3 text-right">মালিকের অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {recipients
                  .filter((r) => r.name.includes(searchTerm) || r.phone.includes(searchTerm))
                  .map((rec) => (
                    <tr key={rec.id} className="hover:bg-neutral-50/60">
                      <td className="p-3 font-bold text-neutral-900">
                        {rec.name}
                      </td>
                      <td className="p-3">
                        <div className="font-medium text-neutral-800">{rec.patientName}</div>
                        <div className="text-[11px] text-neutral-400">{rec.patientCondition}</div>
                      </td>
                      <td className="p-3 font-mono font-bold text-red-600 text-sm">
                        {rec.bloodGroupNeeded} ({toBengaliNumber(rec.bagsNeeded)} ব্যাগ)
                      </td>
                      <td className="p-3">
                        {rec.hospitalName}, {rec.upazila}
                      </td>
                      <td className="p-3 font-mono text-neutral-700">
                        {rec.phone}
                      </td>
                      <td className="p-3 text-right">
                        <button
                          type="button"
                          onClick={() =>
                            setTargetAction({
                              type: 'delete_recipient',
                              id: rec.id,
                              name: rec.name,
                            })
                          }
                          className="px-2 py-1 bg-red-50 hover:bg-red-100 text-red-700 rounded font-medium cursor-pointer"
                        >
                          ডিলিট
                        </button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: BOOKINGS MANAGEMENT */}
      {activeAdminTab === 'bookings' && (
        <div className="bg-white rounded-2xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-neutral-100 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-neutral-900">
                অগ্রিম রক্তদান শিডিউল ও বুকিং ট্র্যাকার
              </h3>
              <p className="text-xs text-neutral-400">দাতা ও গ্রহীতার পারস্পরিক প্রতিশ্রুত রক্তদান</p>
            </div>
            <span className="text-xs text-neutral-500 font-mono">
              মোট: {toBengaliNumber(bookings.length)} টি
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-neutral-600">
              <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-800 font-semibold">
                <tr>
                  <th className="p-3">রক্তদাতা</th>
                  <th className="p-3">গ্রহীতা / রোগী</th>
                  <th className="p-3">রক্তদানের তারিখ</th>
                  <th className="p-3">হাসপাতাল ও এলাকা</th>
                  <th className="p-3">স্ট্যাটাস</th>
                  <th className="p-3 text-right">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {bookings.map((book) => {
                  const isDone = book.status === 'completed';

                  return (
                    <tr key={book.id} className="hover:bg-neutral-50/60">
                      <td className="p-3">
                        <div className="font-bold text-neutral-900">{book.donorName}</div>
                        <div className="text-[11px] font-mono text-neutral-500">{book.donorPhone} ({book.bloodGroup})</div>
                      </td>
                      <td className="p-3">
                        <div className="font-bold text-neutral-800">{book.recipientName}</div>
                        <div className="text-[11px] text-neutral-400">রোগী: {book.patientName} ({book.recipientPhone})</div>
                      </td>
                      <td className="p-3 font-mono font-medium text-neutral-900">
                        {book.scheduledDate}
                      </td>
                      <td className="p-3">
                        {book.hospitalName}, {book.upazila}
                      </td>
                      <td className="p-3">
                        {isDone ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            রক্তদান সম্পন্ন
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                            🔒 রিজার্ভ বুকড ({book.daysRemainingForDonation} দিন বাকি)
                          </span>
                        )}
                      </td>
                      <td className="p-3 text-right">
                        {!isDone && (
                          <button
                            type="button"
                            onClick={() => onConfirmDonationDone(book.id)}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[11px] font-semibold cursor-pointer shadow-xs"
                          >
                            রক্তদান সম্পন্ন কনফার্ম করুন
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: COMPLAINTS MANAGEMENT */}
      {activeAdminTab === 'complaints' && (
        <div className="bg-white rounded-2xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-neutral-100 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-neutral-900">
                সরাসরি অ্যাপের মালিকের কাছে জমা পড়া অভিযোগ
              </h3>
              <p className="text-xs text-neutral-400">ব্যবহারকারীদের ভুয়া তথ্য, অনুপস্থিতি বা অসদাচরণের রিপোর্ট</p>
            </div>
            <span className="text-xs text-red-600 font-bold font-mono">
              অমীমাংসিত: {toBengaliNumber(pendingComplaintsCount)} টি
            </span>
          </div>

          <div className="divide-y divide-neutral-100 p-4 space-y-4">
            {complaints.map((comp) => (
              <div
                key={comp.id}
                className={`p-4 rounded-xl border transition-all ${
                  comp.status === 'resolved'
                    ? 'bg-neutral-50/50 border-neutral-200'
                    : 'bg-red-50/30 border-red-200'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 bg-red-100 text-red-800 font-bold text-xs rounded">
                      {comp.category}
                    </span>
                    <span className="text-xs text-neutral-500 font-mono">
                      তারিখ: {comp.createdAt}
                    </span>
                  </div>

                  <span className={`text-xs font-bold ${comp.status === 'resolved' ? 'text-emerald-700' : 'text-red-700'}`}>
                    {comp.status === 'resolved' ? '✅ নিষ্পত্তি হয়েছে' : '⏳ তদন্তাধীন'}
                  </span>
                </div>

                <div className="space-y-1.5 py-1 text-xs">
                  <div className="text-neutral-800">
                    অভিযোগকারী: <strong>{comp.senderName}</strong> ({comp.senderType}) · ফোন:{' '}
                    <span className="font-mono font-bold">{comp.senderPhone}</span>
                  </div>
                  <div className="text-neutral-800 font-medium">
                    অভিযোগের লক্ষ্য: <span className="text-red-700">{comp.targetEntityName}</span>
                  </div>
                  <p className="p-2.5 bg-white rounded-lg border border-neutral-200 text-neutral-700 leading-relaxed italic">
                    "{comp.details}"
                  </p>
                  {comp.adminNotes && (
                    <p className="text-[11px] text-emerald-800 bg-emerald-50 p-2 rounded border border-emerald-200">
                      মালিকের পদক্ষেপ: {comp.adminNotes}
                    </p>
                  )}
                </div>

                {comp.status !== 'resolved' && (
                  <div className="pt-2 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        onResolveComplaint(comp.id, 'অভিযোগের সত্যতা যাচাই করে প্রয়োজনীয় ব্যবস্থা গ্রহণ করা হয়েছে।')
                      }
                      className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-semibold cursor-pointer shadow-xs"
                    >
                      মীমাংসিত ঘোষণা করুন
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Delete / Block Reason Modal (কারণ উল্লেখ করে নিয়ন্ত্রণ) */}
      {targetAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-neutral-200 space-y-4">
            <div className="flex items-center gap-2 text-red-600 font-bold">
              <AlertTriangle className="w-5 h-5" />
              <span>আইডি নিয়ন্ত্রণের কারণ উল্লেখ করুন</span>
            </div>

            <p className="text-xs text-neutral-600 leading-relaxed">
              আপনি <strong>{targetAction.name}</strong>-এর আইডিটি{' '}
              {targetAction.type === 'block_donor' ? 'সাময়িক ব্লক' : 'স্থায়ীভাবে ডিলিট'}{' '}
              করতে চলেছেন। প্রশাসনিক রেকর্ডের জন্য কারণ লিখুন:
            </p>

            <textarea
              rows={3}
              required
              placeholder="যেমন: বারবার ফোন বন্ধ থাকা, ভুল রক্তের গ্রুপ প্রদান, অসৌজন্যমূলক আচরণ..."
              value={actionReason}
              onChange={(e) => setActionReason(e.target.value)}
              className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none resize-none"
            />

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setTargetAction(null)}
                className="px-4 py-2 text-xs font-semibold text-neutral-600 hover:bg-neutral-100 rounded-lg cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={!actionReason.trim()}
                onClick={handleConfirmAction}
                className="px-5 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 disabled:opacity-50 rounded-lg shadow-xs cursor-pointer"
              >
                নিশ্চিত করুন
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
