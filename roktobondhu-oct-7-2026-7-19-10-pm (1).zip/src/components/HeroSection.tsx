import React from 'react';
import { BloodGroup, DonationStory } from '../types';
import { BLOOD_GROUPS, ALLOWED_DISTRICTS, getUpazilasForDistrict } from '../data/bangladeshDistricts';
import { DonorSlider } from './DonorSlider';
import { Search, Heart, ShieldCheck, MapPin, Camera } from 'lucide-react';

interface HeroSectionProps {
  selectedGroup: BloodGroup | 'ALL';
  onSelectGroup: (group: BloodGroup | 'ALL') => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedDistrict: string;
  setSelectedDistrict: (district: string) => void;
  selectedUpazila: string;
  setSelectedUpazila: (upazila: string) => void;
  stories: DonationStory[];
  onOpenAddRequest: () => void;
  onOpenTracker: () => void;
  onOpenUploadStory: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  selectedGroup,
  onSelectGroup,
  searchQuery,
  setSearchQuery,
  selectedDistrict,
  setSelectedDistrict,
  selectedUpazila,
  setSelectedUpazila,
  stories,
  onOpenAddRequest,
  onOpenTracker,
  onOpenUploadStory,
}) => {
  const currentUpazilas = selectedDistrict === 'ALL' ? [] : getUpazilasForDistrict(selectedDistrict);

  return (
    <section className="relative bg-gradient-to-b from-red-50/40 via-white to-white pt-6 pb-8 border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-7">
        
        {/* Top Feature: Donor Photo & Feedback Slider (Requested by user: "ছবি তুলে আপলোড দিতে পারবে এবং তাদের ছবি তার পেজে স্লাইড আকারে উপরের দিকে থাকবে আর কি একটা সরবে আবার আর একটা আসবে") */}
        <div>
          <DonorSlider
            stories={stories}
            onOpenUploadModal={onOpenUploadStory}
          />
        </div>

        {/* Hero Title and Region Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center pt-2">
          
          <div className="lg:col-span-12 space-y-5">
            
            {/* 5 Districts Kicker text (NO pills) */}
            <div className="flex flex-wrap items-center gap-x-2 text-xs font-semibold text-red-700 tracking-wide">
              <span>ফরিদপুর</span>
              <span aria-hidden="true">·</span>
              <span>মাদারীপুর</span>
              <span aria-hidden="true">·</span>
              <span>গোপালগঞ্জ</span>
              <span aria-hidden="true">·</span>
              <span>রাজবাড়ী</span>
              <span aria-hidden="true">·</span>
              <span>মাগুরা</span>
              <span aria-hidden="true">·</span>
              <span className="text-neutral-500 font-normal">রক্তদানের জন্য উপজেলাভিত্তিক ডিরেক্টরি</span>
            </div>

            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-neutral-900 leading-[1.2]">
                  ফরিদপুর ব্লাড ব্যাংক — <span className="text-red-600">জরুরি রক্তের প্রয়োজনে</span> পাশে আছি
                </h1>
                <p className="text-neutral-600 text-sm sm:text-base mt-1.5 max-w-3xl">
                  ফরিদপুর, মাদারীপুর, গোপালগঞ্জ, রাজবাড়ী ও মাগুরা জেলার উপজেলাভিত্তিক রক্তদাতাদের খুঁজুন। রক্তদানের পর নিজের ছবি ও অভিজ্ঞতা আপলোড করুন। ৪ মাস পূর্ণ হলেই পাবেন রিয়েল-টাইম নোটিফিকেশন।
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={onOpenUploadStory}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                >
                  <Camera className="w-4 h-4 text-red-600" />
                  <span>রক্তদানের ছবি আপলোড</span>
                </button>

                <button
                  type="button"
                  onClick={onOpenAddRequest}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
                >
                  জরুরি আবেদন পোস্ট
                </button>
              </div>
            </div>

            {/* Quick Blood Group Filter Matrix */}
            <div className="space-y-2 pt-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-neutral-700">
                  রক্তের গ্রুপ দিয়ে ফিল্টার করুন:
                </span>
                {selectedGroup !== 'ALL' && (
                  <button
                    onClick={() => onSelectGroup('ALL')}
                    className="text-xs text-red-600 hover:text-red-700 font-medium cursor-pointer"
                  >
                    সকল রক্তের গ্রুপ দেখুন
                  </button>
                )}
              </div>

              <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                {BLOOD_GROUPS.map((group) => {
                  const isSelected = selectedGroup === group;
                  return (
                    <button
                      key={group}
                      type="button"
                      onClick={() => onSelectGroup(isSelected ? 'ALL' : group)}
                      className={`h-11 rounded-lg font-bold text-sm transition-all flex flex-col items-center justify-center cursor-pointer border ${
                        isSelected
                          ? 'bg-red-600 text-white border-red-600 shadow-sm'
                          : 'bg-white text-neutral-800 border-neutral-200 hover:border-red-300 hover:bg-red-50/40'
                      }`}
                    >
                      <span>{group}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Live Filter Bar: 5 Districts, Upazilas, and Search */}
            <div className="p-3 bg-neutral-100/90 rounded-xl border border-neutral-200 flex flex-col md:flex-row gap-2.5">
              
              {/* District Select */}
              <div className="relative md:w-56">
                <MapPin className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <select
                  value={selectedDistrict}
                  onChange={(e) => {
                    const newDist = e.target.value;
                    setSelectedDistrict(newDist);
                    setSelectedUpazila('ALL');
                  }}
                  className="w-full pl-8.5 pr-8 py-2 text-xs bg-white rounded-lg border border-neutral-200 focus:outline-none focus:border-red-500 transition-colors font-medium cursor-pointer"
                >
                  <option value="ALL">সকল জেলা (৫ জেলা)</option>
                  {ALLOWED_DISTRICTS.map((dist) => (
                    <option key={dist} value={dist}>
                      {dist} জেলা
                    </option>
                  ))}
                </select>
              </div>

              {/* Upazila Select */}
              <div className="relative md:w-56">
                <select
                  disabled={selectedDistrict === 'ALL'}
                  value={selectedUpazila}
                  onChange={(e) => setSelectedUpazila(e.target.value)}
                  className={`w-full px-3 py-2 text-xs bg-white rounded-lg border border-neutral-200 focus:outline-none focus:border-red-500 transition-colors cursor-pointer ${
                    selectedDistrict === 'ALL' ? 'opacity-60 bg-neutral-100 cursor-not-allowed' : ''
                  }`}
                >
                  <option value="ALL">
                    {selectedDistrict === 'ALL' ? 'আগে জেলা নির্বাচন করুন' : 'সকল উপজেলা'}
                  </option>
                  {currentUpazilas.map((up) => (
                    <option key={up} value={up}>
                      {up} উপজেলা
                    </option>
                  ))}
                </select>
              </div>

              {/* Text Search */}
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="নাম, মোবাইল নম্বর, হাসপাতাল বা এলাকা দিয়ে খুঁজুন..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-white rounded-lg border border-neutral-200 focus:outline-none focus:border-red-500 transition-colors"
                />
              </div>

            </div>

            {/* Micro assurances */}
            <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-neutral-500">
              <span className="flex items-center gap-1.5 text-neutral-700">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                ফরিদপুর, মাদারীপুর, গোপালগঞ্জ, রাজবাড়ী ও মাগুরা জেলার সক্রিয় রক্তদাতা
              </span>
              <span aria-hidden="true" className="text-neutral-300">·</span>
              <button
                onClick={onOpenTracker}
                className="text-red-700 font-semibold hover:underline cursor-pointer"
              >
                আমার ৪-মাস রক্তদান চক্র ট্র্যাক করুন
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
