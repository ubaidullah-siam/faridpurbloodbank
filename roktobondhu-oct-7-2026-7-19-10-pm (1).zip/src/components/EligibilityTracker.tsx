import React, { useState } from 'react';
import { Donor, DonationRecord, BloodBooking } from '../types';
import { calculateEligibility, toBengaliNumber } from '../utils/bloodLogic';
import { VisualCalendar } from './VisualCalendar';
import {
  Calendar,
  CheckCircle2,
  Clock,
  Edit3,
  Plus,
  BellRing,
  Sparkles,
  MapPin,
  Phone,
  Award,
  Camera,
  CalendarCheck,
  AlertCircle,
  Share2,
} from 'lucide-react';

interface EligibilityTrackerProps {
  currentUser: Donor;
  activeBooking?: BloodBooking | null;
  onUpdateDonor: (donor: Donor) => void;
  onTriggerNotification: (title: string, message: string) => void;
  onOpenEditProfile: () => void;
  onOpenUploadStory: () => void;
  onOpenCongratulationCard: () => void;
  onConfirmDonationCompleted: (bookingId: string) => void;
}

export const EligibilityTracker: React.FC<EligibilityTrackerProps> = ({
  currentUser,
  activeBooking,
  onUpdateDonor,
  onTriggerNotification,
  onOpenEditProfile,
  onOpenUploadStory,
  onOpenCongratulationCard,
  onConfirmDonationCompleted,
}) => {
  const [showAddDonationModal, setShowAddDonationModal] = useState(false);
  const [newDonationDate, setNewDonationDate] = useState(new Date().toISOString().split('T')[0]);
  const [newDonationHospital, setNewDonationHospital] = useState('ফরিদপুর মেডিকেল কলেজ হাসপাতাল');
  const [newDonationNote, setNewDonationNote] = useState('');

  const eligibility = calculateEligibility(currentUser.lastDonationDate);

  // Fast quick-update for last donation date
  const handleQuickDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const dateVal = e.target.value;
    const updated: Donor = {
      ...currentUser,
      lastDonationDate: dateVal,
    };
    onUpdateDonor(updated);
  };

  // Simulate 120+ days ago (4 months completed)
  const handleSimulateFourMonths = () => {
    const simulatedDate = new Date(Date.now() - 125 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const updated: Donor = {
      ...currentUser,
      lastDonationDate: simulatedDate,
    };
    onUpdateDonor(updated);
    onTriggerNotification(
      '🎉 ৪ মাস পূর্ণ হয়েছে! রক্তদানে প্রস্তুত',
      `অভিনন্দন ${currentUser.name}! আপনার শেষ রক্তদানের পর ১২০ দিন পূর্ণ হয়েছে। আপনি এখন ফরিদপুর ব্লাড ব্যাংকে প্রস্তুত রক্তদাতা।`
    );
  };

  // Simulate recent donation today (rest period begins)
  const handleSimulateDonatedToday = () => {
    const todayStr = new Date().toISOString().split('T')[0];
    const newRecord: DonationRecord = {
      id: `donation-${Date.now()}`,
      date: todayStr,
      hospitalOrPlace: 'ফরিদপুর মেডিকেল কলেজ হাসপাতাল',
      patientNote: 'জরুরি রোগীর প্রয়োজনে রক্তদান',
      bagsCount: 1,
    };

    const updated: Donor = {
      ...currentUser,
      lastDonationDate: todayStr,
      totalDonations: currentUser.totalDonations + 1,
      history: [newRecord, ...(currentUser.history || [])],
    };
    onUpdateDonor(updated);
    onTriggerNotification(
      '🩸 রক্তদান সফল হয়েছে!',
      `ধন্যবাদ! আপনার রক্তদান রেকর্ড সংরক্ষণ করা হয়েছে। আপনার শরীর সুস্থ হতে ১২০ দিন (৪ মাস) সময় লাগবে। ৪ মাস পূর্ণ হলেই আমরা পুনরায় মনে করিয়ে দেব।`
    );
  };

  // Submit manual donation log
  const handleAddDonationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDonationDate) return;

    const newRecord: DonationRecord = {
      id: `donation-${Date.now()}`,
      date: newDonationDate,
      hospitalOrPlace: newDonationHospital.trim() || 'ফরিদপুর মেডিকেল কলেজ হাসপাতাল',
      patientNote: newDonationNote.trim(),
      bagsCount: 1,
    };

    const updated: Donor = {
      ...currentUser,
      lastDonationDate: newDonationDate,
      totalDonations: currentUser.totalDonations + 1,
      history: [newRecord, ...(currentUser.history || [])],
    };

    onUpdateDonor(updated);
    setShowAddDonationModal(false);
    setNewDonationHospital('ফরিদপুর মেডিকেল কলেজ হাসপাতাল');
    setNewDonationNote('');

    const newElig = calculateEligibility(newDonationDate);
    if (newElig.isEligible) {
      onTriggerNotification(
        '🎉 ৪ মাস পূর্ণ হয়েছে! রক্তদানে প্রস্তুত',
        `আপনার তথ্য আপডেট অনুযায়ী ১২০ দিন সম্পন্ন হয়েছে। আপনি এখন প্রস্তুত!`
      );
    }
  };

  return (
    <div className="space-y-8">
      
      {/* 1. UPCOMING BOOKING ALERT (Pre-donation and completion confirmation) */}
      {activeBooking && activeBooking.status === 'booked' && (
        <div className="bg-amber-50 border-2 border-amber-400 rounded-2xl p-6 shadow-md space-y-3 animate-in fade-in duration-200">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="w-12 h-12 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold text-xl shadow-xs shrink-0">
                <CalendarCheck className="w-6 h-6" />
              </span>
              <div>
                <span className="text-[11px] font-bold text-amber-800 bg-amber-200/80 px-2 py-0.5 rounded uppercase">
                  আসন্ন রক্তদান শিডিউল (বুকড)
                </span>
                <h3 className="text-lg font-bold text-neutral-900 mt-1">
                  আগামী {activeBooking.scheduledDate} তারিখে আপনার রক্তদান নির্ধারিত আছে!
                </h3>
                <p className="text-xs text-neutral-600 mt-0.5">
                  হাসপাতাল: <strong>{activeBooking.hospitalName}</strong> · রোগী:{' '}
                  <strong>{activeBooking.patientName}</strong> · গ্রহীতার ফোন:{' '}
                  <strong>{activeBooking.recipientPhone}</strong>
                </p>
              </div>
            </div>

            {/* Confirmation CTA button */}
            <button
              type="button"
              onClick={() => onConfirmDonationCompleted(activeBooking.id)}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-sm transition-colors cursor-pointer shrink-0 flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>রক্তদান সম্পন্ন হয়েছে কনফার্ম করুন</span>
            </button>
          </div>

          <div className="text-xs text-amber-900 bg-white/80 p-3 rounded-lg border border-amber-200 flex items-center justify-between">
            <span>
              💡 রক্তদান শেষে কনফার্ম করলেই আপনার আইডিতে ১২০ দিনের (৪ মাস) বিশ্রাম গণনা শুরু হবে এবং স্বয়ংক্রিয় নোটিফিকেশন যাবে।
            </span>
          </div>
        </div>
      )}

      {/* 2. User Overview Banner */}
      <div className="bg-white border border-neutral-200 rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-2xl bg-red-600 text-white font-extrabold text-2xl flex items-center justify-center shadow-xs shrink-0 font-mono">
              {currentUser.bloodGroup}
            </div>
            
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-neutral-900">{currentUser.name}</h2>
                <span className="text-xs bg-red-50 text-red-700 px-2 py-0.5 rounded font-medium border border-red-200">
                  সক্রিয় রক্তদাতা আইডি
                </span>
                {activeBooking && activeBooking.status === 'booked' && (
                  <span className="text-xs bg-amber-100 text-amber-900 px-2 py-0.5 rounded font-bold border border-amber-300">
                    🔒 শিডিউলে বুকড
                  </span>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-neutral-500">
                <span className="flex items-center gap-1 text-neutral-700">
                  <Phone className="w-3.5 h-3.5 text-neutral-400" />
                  {currentUser.phone}
                </span>
                <span aria-hidden="true">·</span>
                <span className="flex items-center gap-1 text-neutral-700">
                  <MapPin className="w-3.5 h-3.5 text-red-500" />
                  {currentUser.upazila}, {currentUser.district} ({currentUser.area})
                </span>
                <span aria-hidden="true">·</span>
                <span className="flex items-center gap-1 text-neutral-700">
                  <Award className="w-3.5 h-3.5 text-amber-500" />
                  মোট {toBengaliNumber(currentUser.totalDonations)} বার রক্তদান
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Congratulation Card Button */}
            <button
              type="button"
              onClick={onOpenCongratulationCard}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-300 rounded-lg transition-colors cursor-pointer shadow-2xs"
            >
              <Award className="w-4 h-4 text-amber-600" />
              <span>অভিনন্দন কার্ড দেখুন</span>
            </button>

            <button
              type="button"
              onClick={onOpenUploadStory}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-neutral-800 bg-red-50 hover:bg-red-100 border border-red-200 rounded-lg transition-colors cursor-pointer"
            >
              <Camera className="w-3.5 h-3.5 text-red-600" />
              <span>ছবি ও মন্তব্য পোস্ট</span>
            </button>

            <button
              type="button"
              onClick={onOpenEditProfile}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              তথ্য এডিট
            </button>

            <button
              type="button"
              onClick={() => setShowAddDonationModal(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              রক্তদান যোগ
            </button>
          </div>

        </div>
      </div>

      {/* 3. VISUAL CALENDAR VIEW - USER REQUEST (বিগত রক্তদান ও আগামী রক্তদানের ক্যালেন্ডার) */}
      <VisualCalendar
        lastDonationDate={currentUser.lastDonationDate}
        activeBooking={activeBooking}
      />

      {/* 4. 4-Month Eligibility Engine Card */}
      <div className={`border rounded-2xl p-6 sm:p-8 transition-all ${
        eligibility.isEligible
          ? 'bg-gradient-to-br from-emerald-50/70 via-white to-emerald-50/30 border-emerald-300 shadow-sm'
          : 'bg-gradient-to-br from-amber-50/70 via-white to-amber-50/30 border-amber-300 shadow-sm'
      }`}>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          <div className="lg:col-span-8 space-y-4">
            
            <div className="flex items-center gap-2">
              {eligibility.isEligible ? (
                <span className="inline-flex items-center gap-1.5 text-emerald-800 font-bold text-sm bg-emerald-100/90 px-3 py-1 rounded-md">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  ৪ মাস (১২০ দিন) সম্পূর্ণ — আপনি এখন রক্তদানে প্রস্তুত!
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-amber-900 font-bold text-sm bg-amber-100/90 px-3 py-1 rounded-md">
                  <Clock className="w-4 h-4 text-amber-600" />
                  বিশ্রামের সময়কাল চলমান (রিকভারি পিরিয়ড)
                </span>
              )}
            </div>

            <h3 className="text-2xl sm:text-3xl font-bold text-neutral-900 leading-tight">
              {eligibility.isEligible ? (
                <span>
                  অভিনন্দন! আপনার শরীর সম্পূর্ণ সুস্থ ও রক্তদানের উপযোগী
                </span>
              ) : (
                <span>
                  রক্তদানের এখনও সময় হয়নি, আর মাত্র{' '}
                  <span className="text-amber-700 font-mono tabular-nums">{toBengaliNumber(eligibility.daysRemaining)}</span> দিন বাকি আছে
                </span>
              )}
            </h3>

            <p className="text-sm sm:text-base text-neutral-600 leading-relaxed">
              {eligibility.isEligible ? (
                'মেডিকেল সায়েন্স অনুযায়ী রক্তদানের পর শরীর সম্পূর্ণ রক্ত কণিকা পুনর্গঠন করতে ৪ মাস (১২০ দিন) সময় নেয়। এই সময় পার হয়েছে বিধায় আপনার আইডিতে আপনি রক্তদানে প্রস্তুত।'
              ) : (
                `আপনার শেষ রক্তদানের পর ${toBengaliNumber(eligibility.daysPassed)} দিন পার হয়েছে। আগামী ${eligibility.nextEligibleDateString} তারিখে ৪ মাস পূর্ণ হলে আমাদের সিস্টেম আপনাকে অটোমেটিক এলার্ট নোটিফিকেশন পাঠাবে।`
              )}
            </p>

            {/* Cycle Progress Bar */}
            <div className="space-y-1.5 pt-2">
              <div className="flex items-center justify-between text-xs font-semibold text-neutral-700">
                <span>১২০ দিনের রিকভারি অগ্রগতি</span>
                <span className="font-mono tabular-nums">
                  {toBengaliNumber(eligibility.progressPercent)}%
                </span>
              </div>
              <div className="w-full h-3 bg-neutral-200 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-700 rounded-full ${
                    eligibility.isEligible ? 'bg-emerald-600' : 'bg-amber-500'
                  }`}
                  style={{ width: `${eligibility.progressPercent}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] text-neutral-500">
                <span>শেষ রক্তদান: {currentUser.lastDonationDate || 'কখনও দেননি'}</span>
                <span>পরবর্তী চক্র: ১২০ দিন</span>
              </div>
            </div>

            {/* Quick date editor input */}
            <div className="pt-3 flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <label htmlFor="lastDateInput" className="text-xs font-medium text-neutral-700">
                  শেষ রক্তদানের তারিখ পরিবর্তন করুন:
                </label>
                <input
                  id="lastDateInput"
                  type="date"
                  value={currentUser.lastDonationDate || ''}
                  onChange={handleQuickDateChange}
                  className="text-xs bg-white border border-neutral-300 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

          </div>

          {/* Interactive Simulation & Test Panel */}
          <div className="lg:col-span-4 bg-white/90 border border-neutral-200/90 rounded-xl p-5 space-y-3.5 shadow-xs">
            <div className="flex items-center gap-2 text-xs font-bold text-neutral-900 border-b border-neutral-100 pb-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>৪-মাস ও বুকিং নোটিফিকেশন টেস্ট</span>
            </div>

            <p className="text-xs text-neutral-500 leading-normal">
              ৪ মাস পূর্ণ হওয়ার নোটিফিকেশন অথবা রক্তদানের অ্যালার্ট পরীক্ষা করুন:
            </p>

            <button
              type="button"
              onClick={handleSimulateFourMonths}
              className="w-full text-left p-3 rounded-lg border border-emerald-200 bg-emerald-50/70 hover:bg-emerald-100 text-xs font-semibold text-emerald-900 transition-colors flex items-center justify-between cursor-pointer group"
            >
              <span>১. সিমুলেট: ৪ মাস পূর্ণ করুন (প্রস্তুত এলার্ট)</span>
              <BellRing className="w-4 h-4 text-emerald-600 group-hover:scale-110 transition-transform" />
            </button>

            <button
              type="button"
              onClick={handleSimulateDonatedToday}
              className="w-full text-left p-3 rounded-lg border border-red-200 bg-red-50/70 hover:bg-red-100 text-xs font-semibold text-red-900 transition-colors flex items-center justify-between cursor-pointer group"
            >
              <span>২. সিমুলেট: আজ রক্তদান করলাম (১২০ দিন গণনা)</span>
              <Calendar className="w-4 h-4 text-red-600 group-hover:scale-110 transition-transform" />
            </button>

            <button
              type="button"
              onClick={() => {
                onTriggerNotification(
                  '📅 আগামীকালের রক্তদান রিমাইন্ডার',
                  'স্মরণ করিয়ে দেওয়া হচ্ছে: আগামীকাল সকালে হাসপাতালে রক্তদানের কথা রয়েছে। সুস্থ থাকুন ও পর্যাপ্ত পানি পান করুন।'
                );
              }}
              className="w-full text-left p-3 rounded-lg border border-amber-200 bg-amber-50/70 hover:bg-amber-100 text-xs font-semibold text-amber-900 transition-colors flex items-center justify-between cursor-pointer group"
            >
              <span>৩. সিমুলেট: রক্তদানের আগের দিনের নোটিফিকেশন</span>
              <CalendarCheck className="w-4 h-4 text-amber-600 group-hover:scale-110 transition-transform" />
            </button>
          </div>

        </div>
      </div>

      {/* 5. Donation History Table */}
      <div className="bg-white border border-neutral-200 rounded-2xl p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-neutral-900">আমার রক্তদানের ইতিহাস ও লগ</h3>
            <p className="text-xs text-neutral-500">পূর্ববর্তী রক্তদানের স্থান ও রোগীর তথ্য</p>
          </div>
          <button
            onClick={() => setShowAddDonationModal(true)}
            className="text-xs font-semibold text-red-600 hover:text-red-700 cursor-pointer"
          >
            + নতুন রেকর্ড যোগ
          </button>
        </div>

        {currentUser.history && currentUser.history.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-neutral-600">
              <thead className="bg-neutral-50 border-b border-neutral-200 font-semibold text-neutral-800">
                <tr>
                  <th className="py-2.5 px-3">তারিখ</th>
                  <th className="py-2.5 px-3">হাসপাতাল / স্থান</th>
                  <th className="py-2.5 px-3">রোগীর বিবরণ</th>
                  <th className="py-2.5 px-3 text-right">পরিমাণ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {currentUser.history.map((record) => (
                  <tr key={record.id} className="hover:bg-neutral-50/50">
                    <td className="py-3 px-3 font-mono font-medium text-neutral-900">
                      {record.date}
                    </td>
                    <td className="py-3 px-3 font-medium text-neutral-800">
                      {record.hospitalOrPlace}
                    </td>
                    <td className="py-3 px-3 text-neutral-500">
                      {record.patientNote || 'সাধারণ রক্তদান'}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-medium text-red-600">
                      {toBengaliNumber(record.bagsCount || 1)} ব্যাগ
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-8 text-neutral-400 text-xs border border-dashed border-neutral-200 rounded-xl">
            এখনও কোনো রক্তদান রেকর্ড যুক্ত করা হয়নি।
          </div>
        )}
      </div>

      {/* Add Record Modal */}
      {showAddDonationModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-neutral-200">
            <h3 className="text-lg font-bold text-neutral-900 mb-1">নতুন রক্তদান রেকর্ড যুক্ত করুন</h3>
            <p className="text-xs text-neutral-500 mb-4">
              রক্তদানের তারিখ অনুযায়ী আপনার ৪-মাস চক্র হিসাব করা হবে।
            </p>

            <form onSubmit={handleAddDonationSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  রক্তদানের তারিখ *
                </label>
                <input
                  type="date"
                  required
                  value={newDonationDate}
                  onChange={(e) => setNewDonationDate(e.target.value)}
                  className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  হাসপাতাল / রক্তদান কেন্দ্রের নাম
                </label>
                <input
                  type="text"
                  placeholder="যেমন: ফরিদপুর মেডিকেল কলেজ হাসপাতাল..."
                  value={newDonationHospital}
                  onChange={(e) => setNewDonationHospital(e.target.value)}
                  className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  রোগী বা উপলক্ষের বিবরণ (ঐচ্ছিক)
                </label>
                <textarea
                  rows={2}
                  placeholder="যেমন: জরুরি অপারেশনের রোগী, থ্যালাসেমিয়া..."
                  value={newDonationNote}
                  onChange={(e) => setNewDonationNote(e.target.value)}
                  className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddDonationModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-neutral-600 hover:bg-neutral-100 rounded-lg cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs cursor-pointer"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
