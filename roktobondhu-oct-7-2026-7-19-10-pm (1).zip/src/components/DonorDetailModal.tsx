import React from 'react';
import { Donor } from '../types';
import { calculateEligibility, toBengaliNumber, buildWhatsAppLink } from '../utils/bloodLogic';
import { X, Phone, MessageSquare, MapPin, Calendar, CheckCircle2, Clock, PhoneOff, Lock } from 'lucide-react';

interface DonorDetailModalProps {
  donor: Donor | null;
  onClose: () => void;
  onShowToast: (msg: string) => void;
}

export const DonorDetailModal: React.FC<DonorDetailModalProps> = ({
  donor,
  onClose,
  onShowToast,
}) => {
  if (!donor) return null;

  const eligibility = calculateEligibility(donor.lastDonationDate);
  const waMsg = `আসসালামু আলাইকুম ${donor.name}, ফরিদপুর ব্লাড ব্যাংক প্ল্যাটফর্ম থেকে আপনার সাথে যোগাযোগ করছি। আপনার রক্তের গ্রুপের (${donor.bloodGroup}) রক্তের প্রয়োজন। আপনি কি রক্তদানে প্রস্তুত?`;
  const waLink = buildWhatsAppLink(donor.phone, waMsg);

  const handleCopyPhone = () => {
    navigator.clipboard.writeText(donor.phone);
    onShowToast(`📞 ফোন নম্বর (${donor.phone}) ক্লিপবোর্ডে কপি করা হয়েছে!`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-neutral-200 my-8">
        
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-neutral-100">
          <div className="flex items-center gap-3">
            <span className="w-14 h-14 rounded-xl bg-red-600 text-white font-extrabold text-2xl flex items-center justify-center font-mono shadow-xs shrink-0">
              {donor.bloodGroup}
            </span>
            <div>
              <h2 className="text-lg font-bold text-neutral-900">{donor.name}</h2>
              <p className="text-xs text-neutral-500 flex items-center gap-1 mt-0.5">
                <MapPin className="w-3.5 h-3.5 text-red-500" />
                <span>{donor.upazila}, {donor.district} ({donor.area})</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="space-y-4 pt-4 text-xs">
          
          {/* Eligibility highlight */}
          <div className={`p-4 rounded-xl border flex items-start gap-3 ${
            eligibility.isEligible
              ? 'bg-emerald-50/70 border-emerald-300 text-emerald-900'
              : 'bg-amber-50/70 border-amber-300 text-amber-900'
          }`}>
            {eligibility.isEligible ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <Clock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            )}
            <div>
              <p className="font-bold text-sm">
                {eligibility.isEligible ? 'রক্তদানে প্রস্তুত (৪ মাস অতিক্রান্ত)' : 'বিশ্রামের সময়কাল চলমান'}
              </p>
              <p className="text-xs mt-0.5 opacity-90">
                {eligibility.isEligible
                  ? 'এই রক্তদাতার শেষ রক্তদানের পর ৪ মাসের বেশি সময় পার হয়েছে। তিনি নিরাপদভাবে রক্ত দিতে পারেন।'
                  : `পরবর্তী রক্তদানের জন্য আর ${toBengaliNumber(eligibility.daysRemaining)} দিন বাকি। সম্ভাব্য তারিখ: ${eligibility.nextEligibleDateString}।`}
              </p>
            </div>
          </div>

          {/* Donor Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 py-2">
            <div className="bg-neutral-50 p-2.5 rounded-lg border border-neutral-100">
              <span className="text-[11px] text-neutral-400 block">বয়স</span>
              <strong className="text-sm text-neutral-900">{toBengaliNumber(donor.age)} বছর</strong>
            </div>

            <div className="bg-neutral-50 p-2.5 rounded-lg border border-neutral-100">
              <span className="text-[11px] text-neutral-400 block">লিঙ্গ</span>
              <strong className="text-sm text-neutral-900">{donor.gender}</strong>
            </div>

            <div className="bg-neutral-50 p-2.5 rounded-lg border border-neutral-100">
              <span className="text-[11px] text-neutral-400 block">মোট রক্তদান</span>
              <strong className="text-sm text-neutral-900 font-mono">{toBengaliNumber(donor.totalDonations)} বার</strong>
            </div>

            <div className="bg-neutral-50 p-2.5 rounded-lg border border-neutral-100">
              <span className="text-[11px] text-neutral-400 block">উপলব্ধতা</span>
              <strong className="text-sm text-emerald-700">সক্রিয়</strong>
            </div>
          </div>

          {/* Contact Details */}
          <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-neutral-500 font-medium">প্রধান মোবাইল নম্বর:</span>
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-sm text-neutral-900">{donor.phone}</span>
                <button
                  type="button"
                  onClick={handleCopyPhone}
                  className="text-[10px] bg-neutral-200 hover:bg-neutral-300 text-neutral-700 px-2 py-0.5 rounded cursor-pointer"
                >
                  কপি
                </button>
              </div>
            </div>

            {donor.altPhone && (
              <div className="flex items-center justify-between border-t border-neutral-100 pt-1.5">
                <span className="text-neutral-500 font-medium">বিকল্প নম্বর:</span>
                <span className="font-mono text-neutral-700">{donor.altPhone}</span>
              </div>
            )}

            <div className="flex items-center justify-between border-t border-neutral-100 pt-1.5">
              <span className="text-neutral-500 font-medium">শেষ রক্তদানের তারিখ:</span>
              <span className="font-medium text-neutral-900">
                {donor.lastDonationDate || 'কখনও দেননি'}
              </span>
            </div>
          </div>

          {/* Donation History List if any */}
          {donor.history && donor.history.length > 0 && (
            <div className="space-y-2 pt-1">
              <h4 className="font-bold text-neutral-900">পূর্ববর্তী রক্তদানের ইতিহাস ({toBengaliNumber(donor.history.length)})</h4>
              <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                {donor.history.map((h) => (
                  <div key={h.id} className="p-2 bg-neutral-50 rounded-lg text-xs flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-neutral-800">{h.hospitalOrPlace}</p>
                      <p className="text-[11px] text-neutral-400">{h.patientNote || 'স্বেচ্ছায় রক্তদান'}</p>
                    </div>
                    <span className="font-mono text-neutral-600">{h.date}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Action CTAs */}
          {(() => {
            const isBooked = !!donor.activeBookingId;
            const isCallDisabled = isBooked || !donor.isAvailable;
            const unavailReason = isBooked
              ? 'রক্তদান বুকড থাকায় কল বন্ধ'
              : !donor.isAvailable
              ? donor.unavailability?.label || 'অসুস্থ / ৫ জেলার বাইরে অবস্থান'
              : '';

            return (
              <div className="pt-3 space-y-2">
                {isCallDisabled && (
                  <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-300 text-amber-900 text-[11px] flex items-center gap-2">
                    <PhoneOff className="w-4 h-4 text-amber-700 shrink-0" />
                    <span>
                      <strong>কল অপশন বন্ধ:</strong> {unavailReason}
                    </span>
                  </div>
                )}

                <div className="flex items-center gap-2">
                  {isCallDisabled ? (
                    <div
                      className="flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 px-4 text-xs font-semibold text-neutral-400 bg-neutral-100 rounded-lg border border-neutral-200 cursor-not-allowed select-none"
                      title="এই রক্তদাতা বর্তমানে কল গ্রহণ করতে পারছেন না"
                    >
                      <PhoneOff className="w-4 h-4 text-neutral-400" />
                      <span>কল বন্ধ ({isBooked ? 'বুকড' : 'অপারগ'})</span>
                    </div>
                  ) : (
                    <a
                      href={`tel:${donor.phone}`}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 px-4 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                    >
                      <Phone className="w-4 h-4" />
                      <span>সরাসরি কল করুন</span>
                    </a>
                  )}

                  <a
                    href={waLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-1.5 py-2.5 px-4 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors cursor-pointer"
                  >
                    <MessageSquare className="w-4 h-4 text-emerald-600" />
                    <span>WhatsApp মেসেজ</span>
                  </a>
                </div>
              </div>
            );
          })()}

        </div>

      </div>
    </div>
  );
};
