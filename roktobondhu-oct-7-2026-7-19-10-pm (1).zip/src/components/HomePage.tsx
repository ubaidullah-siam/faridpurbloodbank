import React, { useState } from 'react';
import { BloodGroup, BloodRequest, Donor, DonationStory } from '../types';
import { ALLOWED_DISTRICTS, BLOOD_GROUPS, getUpazilasForDistrict } from '../data/bangladeshDistricts';
import { DonorSlider } from './DonorSlider';
import { toBengaliNumber, formatBloodRequestShareText, buildWhatsAppBroadcastLink } from '../utils/bloodLogic';
import {
  Users,
  AlertTriangle,
  Clock,
  Camera,
  MapPin,
  ChevronRight,
  ShieldCheck,
  PlusCircle,
  Heart,
  Phone,
  Share2,
  Copy,
  Check,
  MessageSquare,
} from 'lucide-react';

interface HomePageProps {
  stories: DonationStory[];
  donors: Donor[];
  requests: BloodRequest[];
  onSelectGroupAndGo: (group: BloodGroup) => void;
  onSelectDistrictAndGo: (district: string) => void;
  onNavigate: (tab: 'directory' | 'requests' | 'tracker' | 'stories' | 'guidelines') => void;
  onOpenUploadStory: () => void;
  onOpenAddRequest: () => void;
  onOpenRegisterDonor: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  stories,
  donors,
  requests,
  onSelectGroupAndGo,
  onSelectDistrictAndGo,
  onNavigate,
  onOpenUploadStory,
  onOpenAddRequest,
  onOpenRegisterDonor,
}) => {
  const [copiedReqId, setCopiedReqId] = useState<string | null>(null);
  const activeRequests = requests.filter((r) => r.status === 'active').slice(0, 2);

  return (
    <div className="space-y-10">
      
      {/* 1. Top Feature: Smooth Clean Horizontal Slider (ONLY pictures and clean labels, NO comments) */}
      <section className="space-y-3">
        <DonorSlider
          stories={stories}
          onOpenUploadModal={onOpenUploadStory}
        />
        <div className="flex items-center justify-between text-xs text-neutral-500 px-1">
          <span>ফরিদপুর, মাদারীপুর, গোপালগঞ্জ, রাজবাড়ী ও মাগুরা জেলার রক্তদাতাদের রক্তদানের মুহূর্ত</span>
          <button
            onClick={() => onNavigate('stories')}
            className="text-red-700 font-semibold hover:underline cursor-pointer flex items-center gap-1"
          >
            <span>সকল ছবি ও মন্তব্য দেখুন</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </section>

      {/* 2. Welcome Headline & 5 Districts Hub */}
      <section className="bg-white border border-neutral-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6">
        <div className="max-w-3xl space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-red-700 uppercase tracking-wide">
            <span>ফরিদপুর ব্লাড ব্যাংক</span>
            <span aria-hidden="true">·</span>
            <span>৫ জেলা রক্তদান নেটওয়ার্ক</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 leading-tight">
            রক্তের প্রয়োজনে সঠিক সময়ে রক্তদাতা খুঁজে নিন
          </h1>

          <p className="text-sm sm:text-base text-neutral-600 leading-relaxed">
            ফরিদপুর, মাদারীপুর, গোপালগঞ্জ, রাজবাড়ী ও মাগুরা জেলার উপজেলাভিত্তিক রক্তদাতাদের তালিকা। ৪ মাস পূর্ণ হলেই আমাদের প্ল্যাটফর্ম রক্তদাতাকে স্বয়ংক্রিয় নোটিফিকেশন পাঠায়।
          </p>
        </div>

        {/* Quick Blood Group Filter Grid */}
        <div className="space-y-2 pt-1">
          <span className="text-xs font-bold text-neutral-800 block">
            রক্তের গ্রুপ নির্বাচন করে সরাসরি ডোনার তালিকায় যান:
          </span>
          <div className="grid grid-cols-4 sm:grid-cols-8 gap-2.5">
            {BLOOD_GROUPS.map((group) => {
              const count = donors.filter((d) => d.bloodGroup === group).length;
              return (
                <button
                  key={group}
                  type="button"
                  onClick={() => onSelectGroupAndGo(group)}
                  className="h-14 rounded-xl border border-neutral-200 hover:border-red-500 bg-neutral-50 hover:bg-red-50/50 p-2 text-center transition-all cursor-pointer group flex flex-col justify-center items-center shadow-2xs"
                >
                  <span className="font-mono font-bold text-base text-neutral-900 group-hover:text-red-700">
                    {group}
                  </span>
                  <span className="text-[10px] text-neutral-500 group-hover:text-red-600 font-mono">
                    {toBengaliNumber(count)} জন
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* 5 Districts Grid */}
        <div className="space-y-3 pt-2 border-t border-neutral-100">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-neutral-800">
              ৫টি জেলার উপজেলাভিত্তিক ডিরেক্টরি:
            </span>
            <button
              onClick={() => onNavigate('directory')}
              className="text-xs text-red-600 hover:underline font-semibold cursor-pointer"
            >
              সকল জেলা একসাথে দেখুন →
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {ALLOWED_DISTRICTS.map((district) => {
              const count = donors.filter((d) => d.district === district).length;
              const upazilas = getUpazilasForDistrict(district);
              return (
                <button
                  key={district}
                  type="button"
                  onClick={() => onSelectDistrictAndGo(district)}
                  className="p-4 rounded-xl border border-neutral-200 hover:border-red-400 bg-white hover:bg-neutral-50/70 text-left transition-all cursor-pointer space-y-2 group shadow-2xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-neutral-900 group-hover:text-red-700">
                      {district} জেলা
                    </span>
                    <span className="text-[11px] font-mono text-neutral-500 bg-neutral-100 px-2 py-0.5 rounded">
                      {toBengaliNumber(count)} জন
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-500 line-clamp-2 leading-relaxed">
                    উপজেলা: {upazilas.slice(0, 3).join(', ')} ও অন্যান্য
                  </p>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* 3. Live Urgent Blood Requests Snippet */}
      {activeRequests.length > 0 && (
        <section className="bg-red-50/60 border border-red-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-pulse" />
              <h2 className="text-base sm:text-lg font-bold text-neutral-900">
                জরুরি রক্তের লাইভ আবেদন (ফরিদপুর ও পার্শ্ববর্তী জেলা)
              </h2>
            </div>
            <button
              onClick={() => onNavigate('requests')}
              className="text-xs text-red-700 font-bold hover:underline cursor-pointer flex items-center gap-1"
            >
              <span>সকল আবেদন দেখুন</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeRequests.map((req) => (
              <div
                key={req.id}
                className="bg-white rounded-xl p-4 border border-red-200 flex items-center justify-between gap-4 shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <span className="w-12 h-12 rounded-xl bg-red-600 text-white font-mono font-bold text-lg flex items-center justify-center shrink-0">
                    {req.bloodGroup}
                  </span>
                  <div className="space-y-0.5">
                    <h3 className="font-bold text-neutral-900 text-sm">{req.patientName}</h3>
                    <p className="text-xs text-neutral-500 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-red-500" />
                      <span>{req.hospitalName} ({req.upazila})</span>
                    </p>
                    <p className="text-[11px] text-red-700 font-semibold font-mono">
                      প্রয়োজন: {toBengaliNumber(req.bagsNeeded)} ব্যাগ · {req.urgency}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      const shareText = formatBloodRequestShareText(req);
                      navigator.clipboard.writeText(shareText);
                      setCopiedReqId(req.id);
                      setTimeout(() => setCopiedReqId(null), 2500);
                    }}
                    className="p-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 rounded-lg transition-colors cursor-pointer border border-neutral-200"
                    title="হোয়াটসঅ্যাপ/এসএমএস শেয়ারের জন্য কপি করুন"
                  >
                    {copiedReqId === req.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>

                  <a
                    href={buildWhatsAppBroadcastLink(formatBloodRequestShareText(req))}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg transition-colors cursor-pointer border border-emerald-200"
                    title="WhatsApp-এ শেয়ার করুন"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                  </a>

                  <a
                    href={`tel:${req.contactPhone}`}
                    className="px-3 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-semibold rounded-lg shrink-0 flex items-center gap-1 cursor-pointer shadow-xs"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>কল</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 4. Quick Action Navigation Cards (৩টি প্রধান সেকশন) */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Card 1: Donor Directory */}
        <div
          onClick={() => onNavigate('directory')}
          className="bg-white rounded-2xl border border-neutral-200 hover:border-red-300 p-6 space-y-3 cursor-pointer group transition-all shadow-xs"
        >
          <div className="w-11 h-11 rounded-xl bg-red-50 text-red-600 flex items-center justify-center group-hover:bg-red-600 group-hover:text-white transition-colors">
            <Users className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-neutral-900 group-hover:text-red-700 transition-colors">
            রক্তদাতা তালিকা (Directory)
          </h3>
          <p className="text-xs text-neutral-600 leading-relaxed">
            ফরিদপুর, মাদারীপুর, গোপালগঞ্জ, রাজবাড়ী ও মাগুরা জেলার ৬ শতাধিক সক্রিয় রক্তদাতার সাথে সরাসরি যোগাযোগ করুন।
          </p>
          <div className="text-xs font-semibold text-red-600 flex items-center gap-1 pt-1">
            <span>তালিকা খুলুন</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Card 2: 4-Month Cycle Tracker */}
        <div
          onClick={() => onNavigate('tracker')}
          className="bg-white rounded-2xl border border-neutral-200 hover:border-emerald-300 p-6 space-y-3 cursor-pointer group transition-all shadow-xs"
        >
          <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
            <Clock className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-neutral-900 group-hover:text-emerald-700 transition-colors">
            ৪-মাস রক্তদান চক্র ও নোটিফিকেশন
          </h3>
          <p className="text-xs text-neutral-600 leading-relaxed">
            আপনার শেষ রক্তদানের তারিখ দিয়ে রাখুন। ১২০ দিন (৪ মাস) পূর্ণ হলেই আপনি পাবেন সরাসরি নোটিফিকেশন এলার্ট।
          </p>
          <div className="text-xs font-semibold text-emerald-700 flex items-center gap-1 pt-1">
            <span>ট্র্যাকার দেখুন</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Card 3: Stories & Comments Wall */}
        <div
          onClick={() => onNavigate('stories')}
          className="bg-white rounded-2xl border border-neutral-200 hover:border-purple-300 p-6 space-y-3 cursor-pointer group transition-all shadow-xs"
        >
          <div className="w-11 h-11 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition-colors">
            <Camera className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-neutral-900 group-hover:text-purple-700 transition-colors">
            রক্তদানের ছবি ও মন্তব্য ওয়াল
          </h3>
          <p className="text-xs text-neutral-600 leading-relaxed">
            রক্তদাতাদের ছবি দেখুন, লাইক দিন এবং মন্তব্য করুন। রক্তদানের পর আপনার নিজের ছবি ও স্মৃতি আপলোড করুন।
          </p>
          <div className="text-xs font-semibold text-purple-700 flex items-center gap-1 pt-1">
            <span>গ্যালারি ও মন্তব্য দেখুন</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

      </section>

      {/* 5. Bottom Callout Banner */}
      <section className="bg-gradient-to-r from-red-600 to-red-700 rounded-2xl p-6 sm:p-8 text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-md">
        <div className="space-y-1.5 text-center md:text-left">
          <h3 className="text-xl sm:text-2xl font-bold">
            আপনি কি রক্তদাতা হিসেবে যুক্ত হতে চান?
          </h3>
          <p className="text-xs sm:text-sm text-red-100 max-w-xl">
            আপনার এক ব্যাগ রক্ত ফরিদপুর বা আশপাশের যেকোনো হাসপাতালের মুমূর্ষু রোগীর প্রাণ বাঁচাতে পারে।
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onOpenRegisterDonor}
            className="px-4 py-2.5 bg-white text-red-700 hover:bg-red-50 text-xs font-bold rounded-lg transition-colors cursor-pointer shadow-xs"
          >
            নতুন রক্তদাতা নিবন্ধন
          </button>
          <button
            type="button"
            onClick={onOpenUploadStory}
            className="px-4 py-2.5 bg-red-800/80 hover:bg-red-800 text-white text-xs font-semibold rounded-lg border border-red-400/40 transition-colors cursor-pointer"
          >
            ছবি ও মন্তব্য পোস্ট
          </button>
        </div>
      </section>

    </div>
  );
};
