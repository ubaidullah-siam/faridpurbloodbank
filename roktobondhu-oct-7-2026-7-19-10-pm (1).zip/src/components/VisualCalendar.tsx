import React, { useState } from 'react';
import { toBengaliNumber, DONATION_CYCLE_DAYS } from '../utils/bloodLogic';
import { ChevronLeft, ChevronRight, Droplets, CheckCircle2, Clock, Calendar as CalendarIcon, MapPin } from 'lucide-react';
import { BloodBooking } from '../types';

interface VisualCalendarProps {
  lastDonationDate: string | null; // YYYY-MM-DD
  activeBooking?: BloodBooking | null;
}

export const VisualCalendar: React.FC<VisualCalendarProps> = ({
  lastDonationDate,
  activeBooking,
}) => {
  // Target next eligible date calculation (120 days after last donation)
  const nextEligibleDate = React.useMemo(() => {
    if (!lastDonationDate) return null;
    const d = new Date(lastDonationDate);
    d.setDate(d.getDate() + DONATION_CYCLE_DAYS);
    return d;
  }, [lastDonationDate]);

  // Current view date (defaults to current month or next eligible date month)
  const [currentViewDate, setCurrentViewDate] = useState<Date>(() => {
    return new Date();
  });

  const year = currentViewDate.getFullYear();
  const month = currentViewDate.getMonth(); // 0-indexed

  // Month navigation
  const handlePrevMonth = () => {
    setCurrentViewDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentViewDate(new Date(year, month + 1, 1));
  };

  const handleJumpToLastDonation = () => {
    if (lastDonationDate) {
      const d = new Date(lastDonationDate);
      setCurrentViewDate(new Date(d.getFullYear(), d.getMonth(), 1));
    }
  };

  const handleJumpToNextEligible = () => {
    if (nextEligibleDate) {
      setCurrentViewDate(new Date(nextEligibleDate.getFullYear(), nextEligibleDate.getMonth(), 1));
    }
  };

  // Month names in Bengali
  const monthNamesBn = [
    'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
    'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
  ];

  const dayHeadersBn = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'];

  // Calculate days in month and starting day offset
  const firstDayOfWeek = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  // Helper date matching strings (YYYY-MM-DD)
  const formatDateString = (y: number, m: number, d: number) => {
    const mm = String(m + 1).padStart(2, '0');
    const dd = String(d).padStart(2, '0');
    return `${y}-${mm}-${dd}`;
  };

  const todayStr = new Date().toISOString().split('T')[0];
  const nextEligibleStr = nextEligibleDate ? nextEligibleDate.toISOString().split('T')[0] : null;

  // Determine recovery range
  const isWithinRecoveryPeriod = (dateStr: string) => {
    if (!lastDonationDate || !nextEligibleStr) return false;
    return dateStr > lastDonationDate && dateStr < nextEligibleStr;
  };

  return (
    <div className="bg-white border border-neutral-200 rounded-2xl p-5 sm:p-6 shadow-xs space-y-4">
      {/* Calendar Header with Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-100">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-red-100 text-red-700 flex items-center justify-center shrink-0">
            <CalendarIcon className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base text-neutral-900 flex items-center gap-2">
              <span>{monthNamesBn[month]}</span>
              <span className="font-mono">{toBengaliNumber(year)}</span>
            </h3>
            <p className="text-[11px] text-neutral-500">
              রক্তদানের বিগত ও আগামী চক্রের ভিজ্যুয়াল ক্যালেন্ডার
            </p>
          </div>
        </div>

        {/* Quick jump and navigation buttons */}
        <div className="flex items-center gap-1.5 self-end sm:self-auto">
          {lastDonationDate && (
            <button
              type="button"
              onClick={handleJumpToLastDonation}
              className="px-2.5 py-1 text-[11px] font-semibold text-red-700 bg-red-50 hover:bg-red-100 rounded-lg transition-colors cursor-pointer"
            >
              বিগত রক্তদান
            </button>
          )}

          {nextEligibleDate && (
            <button
              type="button"
              onClick={handleJumpToNextEligible}
              className="px-2.5 py-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors cursor-pointer"
            >
              পরবর্তী রক্তদান
            </button>
          )}

          <div className="flex items-center gap-1 border border-neutral-200 rounded-lg p-0.5 ml-1">
            <button
              type="button"
              onClick={handlePrevMonth}
              className="p-1 hover:bg-neutral-100 rounded text-neutral-600 cursor-pointer"
              title="পূর্ববর্তী মাস"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleNextMonth}
              className="p-1 hover:bg-neutral-100 rounded text-neutral-600 cursor-pointer"
              title="পরবর্তী মাস"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Week Day Headers */}
      <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-neutral-400 py-1">
        {dayHeadersBn.map((day) => (
          <div key={day} className="py-1">
            {day}
          </div>
        ))}
      </div>

      {/* Calendar Grid Cells */}
      <div className="grid grid-cols-7 gap-1 sm:gap-1.5">
        {/* Leading empty days */}
        {Array.from({ length: firstDayOfWeek }).map((_, i) => (
          <div key={`empty-${i}`} className="h-10 sm:h-12 rounded-lg bg-neutral-50/40" />
        ))}

        {/* Actual month days */}
        {Array.from({ length: daysInMonth }).map((_, i) => {
          const dayNumber = i + 1;
          const dateStr = formatDateString(year, month, dayNumber);
          const isToday = dateStr === todayStr;
          const isLastDonation = dateStr === lastDonationDate;
          const isNextEligible = dateStr === nextEligibleStr;
          const inRecovery = isWithinRecoveryPeriod(dateStr);
          const isScheduledBooking = activeBooking && activeBooking.scheduledDate === dateStr;

          return (
            <div
              key={`day-${dayNumber}`}
              className={`h-11 sm:h-13 rounded-xl p-1 relative flex flex-col justify-between border transition-all ${
                isLastDonation
                  ? 'bg-red-600 text-white border-red-600 shadow-sm font-bold'
                  : isNextEligible
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm font-bold ring-2 ring-emerald-300'
                  : isScheduledBooking
                  ? 'bg-amber-400 text-neutral-900 border-amber-500 font-bold'
                  : inRecovery
                  ? 'bg-amber-50/70 border-amber-200/80 text-amber-900'
                  : isToday
                  ? 'bg-neutral-100 border-neutral-400 text-neutral-900 font-bold'
                  : 'bg-white hover:bg-neutral-50 border-neutral-100 text-neutral-700'
              }`}
            >
              {/* Day Number */}
              <div className="flex items-center justify-between text-xs font-mono leading-none">
                <span>{toBengaliNumber(dayNumber)}</span>
                {isToday && (
                  <span className="text-[9px] uppercase px-1 rounded bg-neutral-800 text-white font-sans hidden sm:inline">
                    আজ
                  </span>
                )}
              </div>

              {/* Status Indicator Icon or Tag */}
              <div className="flex items-center justify-center">
                {isLastDonation ? (
                  <span className="flex items-center gap-0.5 text-[10px] leading-tight">
                    <Droplets className="w-3.5 h-3.5 fill-white" />
                    <span className="hidden sm:inline">রক্তদান</span>
                  </span>
                ) : isNextEligible ? (
                  <span className="flex items-center gap-0.5 text-[10px] leading-tight">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">প্রস্তুত</span>
                  </span>
                ) : isScheduledBooking ? (
                  <span className="text-[10px] text-amber-950 font-bold leading-tight">
                    🔒 বুকড
                  </span>
                ) : inRecovery ? (
                  <Clock className="w-2.5 h-2.5 text-amber-600/70 opacity-60" />
                ) : null}
              </div>
            </div>
          );
        })}
      </div>

      {/* Visual Legend */}
      <div className="pt-3 border-t border-neutral-100 flex flex-wrap items-center justify-between gap-y-2 text-xs text-neutral-600">
        <div className="flex flex-wrap items-center gap-3">
          <span className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-red-600 inline-block" />
            <span>বিগত রক্তদান ({lastDonationDate || 'তারিখ নেই'})</span>
          </span>

          <span className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-amber-200 border border-amber-300 inline-block" />
            <span>১২০ দিন বিশ্রামকাল</span>
          </span>

          <span className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-emerald-600 inline-block" />
            <span>পরবর্তী রক্তদানের সম্ভাব্য উপযুক্ত দিন ({nextEligibleStr || 'প্রস্তুত'})</span>
          </span>

          {activeBooking && (
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-amber-400 inline-block" />
              <span>নির্ধারিত বুকিং ({activeBooking.scheduledDate})</span>
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
