import React from 'react';
import { X, ShieldCheck, AlertTriangle, Heart, Scale, Lock, UserCheck, CheckCircle2 } from 'lucide-react';

interface PrivacyPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyPolicyModal: React.FC<PrivacyPolicyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-neutral-200 my-8 space-y-6 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center shadow-xs">
              <ShieldCheck className="w-6 h-6" />
            </span>
            <div>
              <h2 className="text-xl font-bold text-neutral-900">
                রক্তদান নীতিমালা ও প্রাইভেসি পলিসি
              </h2>
              <p className="text-xs text-neutral-500">
                ফরিদপুর ব্লাড ব্যাংকের ব্যবহারকারী ও রক্তদাতাদের আইনি ও স্বাস্থ্য নির্দেশিকা
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-neutral-700 rounded-xl hover:bg-neutral-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Policy Points */}
        <div className="space-y-4 max-h-[65vh] overflow-y-auto pr-1 text-xs sm:text-sm text-neutral-700 leading-relaxed">
          
          {/* Rule 1: Age restriction */}
          <div className="p-4 rounded-2xl bg-red-50/80 border border-red-200 space-y-2">
            <div className="flex items-center gap-2 text-red-800 font-bold text-sm">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              <span>১. ১৮ বছরের নিচে রক্তদান কঠোরভাবে নিষিদ্ধ</span>
            </div>
            <p className="text-xs text-red-900/90 leading-normal">
              বাংলাদেশ স্বাস্থ্য অধিদপ্তরের নির্দেশনা অনুযায়ী ১৮ বছরের কম বয়সী বা ৬০ বছরের বেশি বয়সী ব্যক্তিরা রক্তদান করতে পারবেন না। অপ্রাপ্তবয়স্ক কোনো ব্যক্তির তথ্য রক্তদাতা হিসেবে নিবন্ধন করা বেআইনি।
            </p>
          </div>

          {/* Rule 2: Physical Eligibility */}
          <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2">
            <div className="flex items-center gap-2 text-neutral-900 font-bold text-sm">
              <UserCheck className="w-4 h-4 text-emerald-600" />
              <span>২. ওজন ও শারীরিক সুস্থতার মানদণ্ড</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-xs text-neutral-600">
              <li>রক্তদাতার ওজন কমপক্ষে ৪৫ কেজি (মহিলা) এবং ৫০ কেজি (পুরুষ) হতে হবে।</li>
              <li>রক্তে হিমোগ্লোবিনের মাত্রা পুরুষের ক্ষেত্রে কমপক্ষে ১২.৫ g/dL এবং মহিলার ক্ষেত্রে ১২.০ g/dL থাকা আবশ্যক।</li>
              <li>রক্তচাপ ও নাড়ির স্পন্দন স্বাভাবিক থাকতে হবে। হেপাটাইটিস, এইডস বা সিফিলিসের মতো রক্তবাহিত রোগ থাকলে রক্ত দেওয়া যাবে না।</li>
            </ul>
          </div>

          {/* Rule 3: 4-Month Cycle */}
          <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2">
            <div className="flex items-center gap-2 text-neutral-900 font-bold text-sm">
              <Heart className="w-4 h-4 text-red-600" />
              <span>৩. ৪ মাস (১২০ দিন) বিরতি বাধ্যতামূলক</span>
            </div>
            <p className="text-xs text-neutral-600">
              একবার রক্তদানের পর মানবদেহের লোহিত রক্তকণিকা সম্পূর্ণ পুনর্গঠিত হতে ১২০ দিন সময় নেয়। তাই পরবর্তী রক্তদানের জন্য কমপক্ষে ৪ মাস অপেক্ষা করতে হবে। আমাদের অ্যাপ স্বয়ংক্রিয়ভাবে ৪ মাসের হিসাব বজায় রাখে।
            </p>
          </div>

          {/* Rule 4: Privacy & Contact Security */}
          <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2">
            <div className="flex items-center gap-2 text-neutral-900 font-bold text-sm">
              <Lock className="w-4 h-4 text-blue-600" />
              <span>৪. তথ্যের সুরক্ষা ও প্রাইভেসি পলিসি</span>
            </div>
            <p className="text-xs text-neutral-600">
              আপনার মোবাইল নম্বর, রক্তের গ্রুপ এবং ইউনিয়ন/গ্রামের তথ্য কেবলমাত্র মুমূর্ষু রোগীর প্রয়োজনে যোগাযোগ করার জন্যই প্রদর্শিত হয়। আমরা কোনো বাণিজ্যিক বিজ্ঞাপনদাতা বা ৩য় পক্ষের কাছে আপনার কোনো তথ্য বিক্রয় বা হস্তান্তর করি না।
            </p>
          </div>

          {/* Rule 5: Zero Tolerance for Commercialization */}
          <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2">
            <div className="flex items-center gap-2 text-neutral-900 font-bold text-sm">
              <Scale className="w-4 h-4 text-amber-600" />
              <span>৫. সম্পূর্ণ বিনামূল্যে ও মানবিক সেবা (অর্থ দাবি নিষিদ্ধ)</span>
            </div>
            <p className="text-xs text-neutral-600">
              রক্তদান একটি নিঃস্বার্থ মানবিক সেবা। রক্তের বিনিময়ে অর্থ দাবি করা বা ব্লাড ব্যাংকের পরিচয় ব্যবহার করে অনৈতিক সুবিধা নেওয়া আইনত দণ্ডনীয় অপরাধ। অভিযোগ পাওয়া গেলে তাৎক্ষণিক আইডি ব্লক ও আইনি ব্যবস্থা নেওয়া হবে।
            </p>
          </div>

        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-neutral-100 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-medium">
            <CheckCircle2 className="w-4 h-4" />
            <span>নিরাপদ রক্তদান · মানবকল্যাণে নিবেদিত</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-xs"
          >
            আমি শর্তাবলী মেনে চলব
          </button>
        </div>

      </div>
    </div>
  );
};
