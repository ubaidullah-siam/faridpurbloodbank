import React, { useState } from 'react';
import { Complaint } from '../types';
import { X, ShieldAlert, Send, CheckCircle2 } from 'lucide-react';

interface ComplaintBoxModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitComplaint: (complaint: Omit<Complaint, 'id' | 'status' | 'createdAt'>) => void;
  defaultSenderName?: string;
  defaultSenderPhone?: string;
}

export const ComplaintBoxModal: React.FC<ComplaintBoxModalProps> = ({
  isOpen,
  onClose,
  onSubmitComplaint,
  defaultSenderName = '',
  defaultSenderPhone = '',
}) => {
  const [senderName, setSenderName] = useState(defaultSenderName);
  const [senderPhone, setSenderPhone] = useState(defaultSenderPhone);
  const [senderType, setSenderType] = useState<'দাতা' | 'গ্রহীতা' | 'সাধারণ ব্যবহারকারী'>('গ্রহীতা');
  const [category, setCategory] = useState<'ভুয়া তথ্য বা নম্বর' | 'রক্তদাতা রক্ত দেয়নি' | 'অযৌক্তিক অর্থ দাবি' | 'বুকিং সমস্যা' | 'পরামর্শ'>('ভুয়া তথ্য বা নম্বর');
  const [targetEntityName, setTargetEntityName] = useState('');
  const [details, setDetails] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!senderName.trim() || !senderPhone.trim() || !details.trim()) return;

    onSubmitComplaint({
      senderName: senderName.trim(),
      senderPhone: senderPhone.trim(),
      senderType,
      category,
      targetEntityName: targetEntityName.trim() || 'সাধারণ অভিযোগ',
      details: details.trim(),
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-neutral-200 my-8">
        
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-neutral-100">
          <div className="flex items-center gap-2.5">
            <span className="w-9 h-9 rounded-xl bg-red-100 text-red-700 flex items-center justify-center shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-neutral-900">অ্যাপের মালিকের কাছে সরাসরি অভিযোগ</h2>
              <p className="text-xs text-neutral-500">
                ভুয়া নম্বর, অনুপস্থিত ডোনার বা যেকোনো বিষয়ে গোপনীয় অভিযোগ জানান
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notice */}
        <div className="my-3 p-3 bg-red-50/60 rounded-xl border border-red-200 text-xs text-red-900 leading-relaxed">
          🔒 আপনার অভিযোগটি সরাসরি অ্যাপের মালিক ও প্রশাসনিক প্যানেলে পৌঁছাবে। সত্যতা যাচাই করে দ্রুত আইডি ব্লক বা প্রয়োজনীয় আইনি পদক্ষেপ নেওয়া হবে।
        </div>

        {/* Complaint Form */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-1 text-xs">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                আপনার নাম *
              </label>
              <input
                type="text"
                required
                placeholder="যেমন: মোঃ কামরুল হাসান"
                value={senderName}
                onChange={(e) => setSenderName(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                আপনার মোবাইল নম্বর *
              </label>
              <input
                type="tel"
                required
                placeholder="01XXXXXXXXX"
                value={senderPhone}
                onChange={(e) => setSenderPhone(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                আপনার পরিচয় *
              </label>
              <select
                value={senderType}
                onChange={(e) => setSenderType(e.target.value as 'দাতা' | 'গ্রহীতা' | 'সাধারণ ব্যবহারকারী')}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none bg-white font-medium"
              >
                <option value="গ্রহীতা">রক্ত গ্রহীতা / রোগীর স্বজন</option>
                <option value="দাতা">রক্তদাতা (ডোনার)</option>
                <option value="সাধারণ ব্যবহারকারী">সাধারণ নাগরিক</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                অভিযোগের ধরণ *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as 'ভুয়া তথ্য বা নম্বর' | 'রক্তদাতা রক্ত দেয়নি' | 'অযৌক্তিক অর্থ দাবি' | 'বুকিং সমস্যা' | 'পরামর্শ')}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none bg-white font-medium"
              >
                <option value="ভুয়া তথ্য বা নম্বর">ভুয়া তথ্য বা নম্বর</option>
                <option value="রক্তদাতা রক্ত দেয়নি">কথা দিয়ে রক্ত দেয়নি / আসেনি</option>
                <option value="অযৌক্তিক অর্থ দাবি">অযৌক্তিক অর্থ দাবি করেছে</option>
                <option value="বুকিং সমস্যা">বুকিং বা শিডিউল সমস্যা</option>
                <option value="পরামর্শ">উন্নয়নমূলক পরামর্শ</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              অভিযোগের লক্ষ্য / কার বিরুদ্ধে বা কোন নম্বরের বিরুদ্ধে
            </label>
            <input
              type="text"
              placeholder="যেমন: ০১৭... নম্বরের রক্তদাতা বা রোগীর নাম"
              value={targetEntityName}
              onChange={(e) => setTargetEntityName(e.target.value)}
              className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              বিস্তারিত অভিযোগ বা বর্ণনা *
            </label>
            <textarea
              rows={3}
              required
              placeholder="ঘটনাটি বিস্তারিত লিখুন (কবে ঘটেছে, কী সমস্যা হয়েছে)..."
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none resize-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 font-semibold text-neutral-600 hover:bg-neutral-100 rounded-lg cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2.5 font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>মালিকের কাছে অভিযোগ পাঠান</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
