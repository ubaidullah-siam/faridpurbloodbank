import React from 'react';
import { NavTab } from './Navbar';
import { Home, Users, AlertTriangle, Clock, Camera, Wifi, Battery, Signal, Globe, User } from 'lucide-react';

interface MobileAppShellProps {
  children: React.ReactNode;
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  onSwitchToWeb: () => void;
}

export const MobileAppShell: React.FC<MobileAppShellProps> = ({
  children,
  activeTab,
  setActiveTab,
  onSwitchToWeb,
}) => {
  return (
    <div className="min-h-screen bg-neutral-900 py-6 sm:py-10 px-2 flex flex-col items-center justify-center font-['Hind_Siliguri',sans-serif]">
      
      {/* Top Banner indicating App Preview Mode */}
      <div className="mb-4 flex items-center justify-between max-w-[430px] w-full px-3 text-xs text-white">
        <span className="flex items-center gap-1.5 font-semibold text-neutral-300">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>স্মার্টফোন অ্যাপ সংস্করণ (Mobile App View)</span>
        </span>
        <button
          type="button"
          onClick={onSwitchToWeb}
          className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors flex items-center gap-1 font-semibold cursor-pointer border border-white/20"
        >
          <Globe className="w-3.5 h-3.5" />
          <span>ওয়েব সংস্করণে ফিরুন</span>
        </button>
      </div>

      {/* Smartphone Device Frame */}
      <div className="relative w-full max-w-[430px] h-[890px] max-h-[92vh] bg-black rounded-[50px] p-3.5 shadow-2xl border-[4px] border-neutral-700 flex flex-col overflow-hidden">
        
        {/* Phone Notch / Dynamic Island */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-6 bg-black rounded-full z-50 flex items-center justify-center">
          <div className="w-3 h-3 rounded-full bg-neutral-800 mr-2" />
          <div className="w-2.5 h-2.5 rounded-full bg-blue-900/60" />
        </div>

        {/* Mobile Device Status Bar */}
        <div className="h-6 w-full px-7 flex items-center justify-between text-[11px] text-white font-mono shrink-0 z-40 bg-black pt-1">
          <span>০৯:৪১</span>
          <div className="flex items-center gap-1.5">
            <Signal className="w-3 h-3" />
            <Wifi className="w-3 h-3" />
            <Battery className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Mobile Screen Body */}
        <div className="flex-1 w-full bg-[#faf9f6] rounded-[36px] overflow-y-auto overflow-x-hidden flex flex-col relative no-scrollbar">
          {children}
        </div>

        {/* Mobile Bottom Navigation Bar */}
        <div className="h-14 bg-white/95 backdrop-blur-md border-t border-neutral-200 rounded-b-[36px] flex items-center justify-around px-2 shrink-0 z-40 text-[10px]">
          <button
            onClick={() => setActiveTab('home')}
            className={`flex flex-col items-center gap-0.5 cursor-pointer ${
              activeTab === 'home' ? 'text-red-600 font-bold' : 'text-neutral-500'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>হোম</span>
          </button>

          <button
            onClick={() => setActiveTab('directory')}
            className={`flex flex-col items-center gap-0.5 cursor-pointer ${
              activeTab === 'directory' ? 'text-red-600 font-bold' : 'text-neutral-500'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>ডোনার</span>
          </button>

          <button
            onClick={() => setActiveTab('requests')}
            className={`flex flex-col items-center gap-0.5 cursor-pointer ${
              activeTab === 'requests' ? 'text-red-600 font-bold' : 'text-neutral-500'
            }`}
          >
            <AlertTriangle className="w-4 h-4" />
            <span>আবেদন</span>
          </button>

          <button
            onClick={() => setActiveTab('tracker')}
            className={`flex flex-col items-center gap-0.5 cursor-pointer ${
              activeTab === 'tracker' ? 'text-red-600 font-bold' : 'text-neutral-500'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>ট্র্যাকার</span>
          </button>

          <button
            onClick={() => setActiveTab('stories')}
            className={`flex flex-col items-center gap-0.5 cursor-pointer ${
              activeTab === 'stories' ? 'text-red-600 font-bold' : 'text-neutral-500'
            }`}
          >
            <Camera className="w-4 h-4" />
            <span>ছবি</span>
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`flex flex-col items-center gap-0.5 cursor-pointer ${
              activeTab === 'profile' ? 'text-red-600 font-bold' : 'text-neutral-500'
            }`}
          >
            <User className="w-4 h-4" />
            <span>প্রোফাইল</span>
          </button>
        </div>

        {/* Home Indicator Bar */}
        <div className="w-32 h-1 bg-neutral-600 rounded-full mx-auto my-1.5 shrink-0" />

      </div>

    </div>
  );
};
