import React, { useState } from 'react';
import { BloodRequest, BloodGroup } from '../types';
import { BLOOD_GROUPS, ALLOWED_DISTRICTS } from '../data/bangladeshDistricts';
import {
  toBengaliNumber,
  buildWhatsAppLink,
  formatBloodRequestShareText,
  buildWhatsAppBroadcastLink,
  buildSmsShareLink,
} from '../utils/bloodLogic';
import {
  AlertCircle,
  Phone,
  Share2,
  MapPin,
  Calendar,
  CheckCircle2,
  PlusCircle,
  MessageSquare,
  Copy,
  Check,
  Send,
  X,
} from 'lucide-react';

interface BloodRequestListProps {
  requests: BloodRequest[];
  onOpenAddRequest: () => void;
  onUpdateStatus: (requestId: string, status: 'active' | 'fulfilled' | 'closed') => void;
  onShowToast: (message: string) => void;
}

export const BloodRequestList: React.FC<BloodRequestListProps> = ({
  requests,
  onOpenAddRequest,
  onUpdateStatus,
  onShowToast,
}) => {
  const [filterGroup, setFilterGroup] = useState<BloodGroup | 'ALL'>('ALL');
  const [filterDistrict, setFilterDistrict] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'fulfilled'>('active');
  const [activeShareRequest, setActiveShareRequest] = useState<BloodRequest | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredRequests = requests.filter((req) => {
    if (filterGroup !== 'ALL' && req.bloodGroup !== filterGroup) return false;
    if (filterDistrict !== 'ALL' && req.district !== filterDistrict) return false;
    if (filterStatus === 'active' && req.status !== 'active') return false;
    if (filterStatus === 'fulfilled' && req.status !== 'fulfilled') return false;
    return true;
  });

  const handleCopyFormattedText = (req: BloodRequest) => {
    const formatted = formatBloodRequestShareText(req);
    navigator.clipboard.writeText(formatted);
    setCopiedId(req.id);
    onShowToast('📋 রক্তের আবেদনের ফরম্যাটেড টেক্সট কপি করা হয়েছে! হোয়াটসঅ্যাপ বা মেসেজে পেস্ট করুন।');
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleNativeShare = (req: BloodRequest) => {
    const shareText = formatBloodRequestShareText(req);
    if (navigator.share) {
      navigator
        .share({
          title: `জরুরি রক্ত প্রয়োজন (${req.bloodGroup}) - ফরিদপুর ব্লাড ব্যাংক`,
          text: shareText,
        })
        .catch(() => {});
    } else {
      handleCopyFormattedText(req);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header card with action */}
      <div className="bg-white border border-neutral-200 rounded-2xl p-5 sm:p-6 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-pulse" />
            <h2 className="text-xl font-bold text-neutral-900 tracking-tight">
              জরুরি রক্তের আবেদনসমূহ (Live Requests)
            </h2>
          </div>
          <p className="text-xs text-neutral-500 mt-1">
            ফরিদপুর, মাদারীপুর, গোপালগঞ্জ, রাজবাড়ী ও মাগুরা জেলার হাসপাতালগুলোতে রক্তের লাইভ আবেদন
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenAddRequest}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs transition-colors cursor-pointer shrink-0"
        >
          <PlusCircle className="w-4 h-4" />
          <span>নতুন রক্তের আবেদন পোস্ট করুন</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3 rounded-xl border border-neutral-200">
        
        {/* Status filter & District filter */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 bg-neutral-100 p-1 rounded-lg">
            <button
              type="button"
              onClick={() => setFilterStatus('active')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                filterStatus === 'active'
                  ? 'bg-white text-neutral-900 shadow-xs font-semibold'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              সক্রিয় ({toBengaliNumber(requests.filter((r) => r.status === 'active').length)})
            </button>
            <button
              type="button"
              onClick={() => setFilterStatus('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                filterStatus === 'all'
                  ? 'bg-white text-neutral-900 shadow-xs font-semibold'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              সকল ({toBengaliNumber(requests.length)})
            </button>
          </div>

          <select
            value={filterDistrict}
            onChange={(e) => setFilterDistrict(e.target.value)}
            className="p-1.5 text-xs bg-neutral-50 border border-neutral-200 rounded-lg focus:outline-none"
          >
            <option value="ALL">সকল ৫ জেলা</option>
            {ALLOWED_DISTRICTS.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>

        {/* Blood group selector */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          <button
            type="button"
            onClick={() => setFilterGroup('ALL')}
            className={`px-2.5 py-1 text-xs rounded-md font-medium cursor-pointer ${
              filterGroup === 'ALL'
                ? 'bg-red-600 text-white'
                : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
            }`}
          >
            সকল গ্রুপ
          </button>
          {BLOOD_GROUPS.map((grp) => (
            <button
              key={grp}
              type="button"
              onClick={() => setFilterGroup(grp)}
              className={`px-2.5 py-1 text-xs rounded-md font-mono font-medium cursor-pointer ${
                filterGroup === grp
                  ? 'bg-red-600 text-white'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              {grp}
            </button>
          ))}
        </div>

      </div>

      {/* Requests Grid */}
      {filteredRequests.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredRequests.map((req) => {
            const isFulfilled = req.status === 'fulfilled';
            const whatsappMsg = `আসসালামু আলাইকুম, ফরিদপুর ব্লাড ব্যাংক অ্যাপে আপনার রক্তের আবেদন দেখেছি (${req.bloodGroup}, রোগী: ${req.patientName})। রক্তদাতা সংক্রান্ত বিষয়ে কথা বলতে চাই।`;
            const waLink = buildWhatsAppLink(req.contactPhone, whatsappMsg);

            return (
              <div
                key={req.id}
                className={`bg-white rounded-2xl border transition-all p-5 sm:p-6 shadow-xs flex flex-col justify-between ${
                  isFulfilled
                    ? 'border-neutral-200 opacity-75 bg-neutral-50/50'
                    : 'border-red-200 hover:border-red-300'
                }`}
              >
                <div>
                  {/* Top line: Blood group badge & urgency indicator */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      <span className="w-13 h-13 rounded-xl bg-red-600 text-white font-extrabold text-xl flex items-center justify-center font-mono shadow-xs shrink-0">
                        {req.bloodGroup}
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold text-neutral-900 text-base">
                            {req.patientName}
                          </h3>
                          {req.patientAge && (
                            <span className="text-xs text-neutral-500">
                              ({toBengaliNumber(req.patientAge)} বছর)
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-neutral-600 font-medium mt-0.5">
                          {req.patientCondition}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      {isFulfilled ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          রক্তদাতা নিশ্চিত
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-red-800 bg-red-50 px-2 py-0.5 rounded border border-red-200">
                          <AlertCircle className="w-3 h-3 text-red-600" />
                          {req.urgency}
                        </span>
                      )}
                      <p className="text-[11px] font-mono tabular-nums text-red-600 font-bold mt-1">
                        প্রয়োজন: {toBengaliNumber(req.bagsNeeded)} ব্যাগ
                      </p>
                    </div>
                  </div>

                  {/* Hospital and location details */}
                  <div className="space-y-1.5 py-3 border-y border-neutral-100 text-xs text-neutral-600">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                      <span className="font-medium text-neutral-900">{req.hospitalName}</span>
                    </div>
                    <div className="flex items-center gap-2 text-neutral-500 pl-5.5">
                      <span>{req.upazila}, {req.district} ({req.area})</span>
                    </div>
                    <div className="flex items-center gap-2 text-neutral-500">
                      <Calendar className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                      <span>রক্তের প্রয়োজনীয় তারিখ: <strong className="text-neutral-800">{req.neededDate}</strong></span>
                    </div>
                  </div>

                  {/* Notes if any */}
                  {req.additionalNotes && (
                    <p className="text-xs text-neutral-600 bg-neutral-50 p-2.5 rounded-lg my-3 leading-relaxed">
                      "{req.additionalNotes}"
                    </p>
                  )}

                  {/* Contact person */}
                  <div className="flex items-center justify-between text-xs text-neutral-500 pt-2">
                    <span>যোগাযোগ: <strong className="text-neutral-800">{req.contactPerson}</strong></span>
                    <span className="font-mono tabular-nums font-semibold text-neutral-800">{req.contactPhone}</span>
                  </div>
                </div>

                {/* Bottom Actions */}
                <div className="pt-4 mt-2 flex flex-wrap items-center gap-2">
                  <a
                    href={`tel:${req.contactPhone}`}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>কল করুন</span>
                  </a>

                  <a
                    href={waLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors cursor-pointer"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                    <span>WhatsApp</span>
                  </a>

                  {/* Quick Share to Volunteer Networks / WhatsApp / SMS */}
                  <button
                    type="button"
                    onClick={() => setActiveShareRequest(req)}
                    className="inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-300 rounded-lg transition-colors cursor-pointer shadow-2xs"
                    title="স্বেচ্ছাসেবী গ্রুপ ও বন্ধুদের শেয়ার করতে ফরম্যাটেড মেসেজ"
                  >
                    <Send className="w-3.5 h-3.5 text-amber-700" />
                    <span>শেয়ার বার্তা</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleCopyFormattedText(req)}
                    className="p-2 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg transition-colors cursor-pointer border border-neutral-200"
                    title="মেসেজ কপি করুন"
                  >
                    {copiedId === req.id ? (
                      <Check className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>

                  {!isFulfilled ? (
                    <button
                      type="button"
                      onClick={() => onUpdateStatus(req.id, 'fulfilled')}
                      className="px-2.5 py-2 text-[11px] font-medium text-neutral-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                      title="রক্ত পাওয়া গেছে হিসেবে চিহ্নিত করুন"
                    >
                      রক্তদাতা সম্পন্ন?
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => onUpdateStatus(req.id, 'active')}
                      className="px-2.5 py-2 text-[11px] font-medium text-neutral-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                    >
                      পুনরায় সক্রিয়
                    </button>
                  )}
                </div>

              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white border border-neutral-200 rounded-2xl p-12 text-center space-y-3">
          <p className="text-base font-bold text-neutral-800">
            বর্তমানে এই এলাকায় কোনো জরুরি রক্তের আবেদন নেই
          </p>
          <p className="text-xs text-neutral-500 max-w-sm mx-auto">
            আপনার বা আপনার পরিচিত কারও রক্তের প্রয়োজন হলে এখনই বিনামূল্যে আবেদন পোস্ট করুন।
          </p>
          <button
            type="button"
            onClick={onOpenAddRequest}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>আবেদন পোস্ট করুন</span>
          </button>
        </div>
      )}

      {/* QUICK SHARE MODAL FOR VOLUNTEER NETWORKS */}
      {activeShareRequest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-neutral-200 my-8 space-y-5 animate-in fade-in zoom-in-95 duration-150">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
              <div className="flex items-center gap-2.5">
                <span className="w-10 h-10 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center">
                  <Send className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="font-bold text-base text-neutral-900">
                    স্বেচ্ছাসেবী গ্রুপে দ্রুত শেয়ার করুন
                  </h3>
                  <p className="text-xs text-neutral-500">
                    রোগী: {activeShareRequest.patientName} ({activeShareRequest.bloodGroup})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveShareRequest(null)}
                className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Formatted Text Preview Box */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-neutral-600">
                <span className="font-bold">প্রস্তুতকৃত শেয়ার বার্তা (Formatted Message):</span>
                <span className="text-[11px] text-neutral-400 font-mono">WhatsApp/SMS প্রস্তুত</span>
              </div>
              <div className="p-3.5 bg-neutral-900 text-neutral-100 rounded-2xl text-xs font-mono leading-relaxed whitespace-pre-wrap max-h-56 overflow-y-auto select-all border border-neutral-800 shadow-inner">
                {formatBloodRequestShareText(activeShareRequest)}
              </div>
            </div>

            {/* Action Buttons: WhatsApp Broadcast, Copy, SMS, Native Share */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
              <a
                href={buildWhatsAppBroadcastLink(formatBloodRequestShareText(activeShareRequest))}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-xs"
              >
                <MessageSquare className="w-4 h-4" />
                <span>WhatsApp-এ শেয়ার করুন</span>
              </a>

              <a
                href={buildSmsShareLink(formatBloodRequestShareText(activeShareRequest))}
                className="py-2.5 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-xs"
              >
                <Send className="w-4 h-4" />
                <span>মেসেজ (SMS) পাঠান</span>
              </a>

              <button
                type="button"
                onClick={() => handleCopyFormattedText(activeShareRequest)}
                className="py-2.5 px-3 bg-neutral-100 hover:bg-neutral-200 text-neutral-900 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-2 border border-neutral-200"
              >
                {copiedId === activeShareRequest.id ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>মেসেজ কপি হয়েছে!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-neutral-700" />
                    <span>টেক্সট কপি করুন</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => handleNativeShare(activeShareRequest)}
                className="py-2.5 px-3 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <Share2 className="w-4 h-4 text-red-600" />
                <span>অন্যান্য অ্যাপে শেয়ার</span>
              </button>
            </div>

            <p className="text-[11px] text-neutral-500 text-center pt-1">
              💡 এই টেক্সটটি ফরিদপুরের রক্তদাতা ও ভলান্টিয়ার গ্রুপে পোস্ট করলে দ্রুততম সময়ে রক্তদাতা পাওয়া সম্ভব হয়।
            </p>

          </div>
        </div>
      )}

    </div>
  );
};
