import React, { useState } from 'react';
import { BloodGroup } from '../types';
import { BLOOD_GROUPS } from '../data/bangladeshDistricts';
import { BLOOD_COMPATIBILITY } from '../utils/bloodLogic';
import { Heart, Clock, ShieldCheck, CheckCircle2, AlertCircle } from 'lucide-react';

export const BloodGuidelines: React.FC = () => {
  const [selectedGroup, setSelectedGroup] = useState<BloodGroup>('O+');
  const compatibility = BLOOD_COMPATIBILITY[selectedGroup];

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      
      {/* 4-Month Scientific Explanation */}
      <div className="bg-white border border-neutral-200 rounded-2xl p-6 sm:p-8 shadow-xs">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-red-100 text-red-600 flex items-center justify-center shrink-0">
            <Clock className="w-6 h-6" />
          </div>
          <div className="space-y-3">
            <h2 className="text-xl sm:text-2xl font-bold text-neutral-900">
              কেন প্রতি ৪ মাস (১২০ দিন) পর পর রক্তদান করা উচিত?
            </h2>
            <p className="text-sm text-neutral-600 leading-relaxed">
              চিকিৎসা বিজ্ঞান অনুযায়ী মানুষের লোহিত রক্তকণিকার (Red Blood Cells) গড় আয়ু <strong>১২০ দিন বা ৪ মাস</strong>।
              একবার রক্ত দিলে রক্তরস (Plasma) ২৪ থেকে ৪৮ ঘণ্টার মধ্যেই পুনরায় তৈরি হয়ে যায়, কিন্তু রক্তের হিমোগ্লোবিন এবং লোহিত কণিকা সম্পূর্ণ নতুন ও তাজা হতে প্রায় ৩ থেকে ৪ মাস সময়ের প্রয়োজন হয়।
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              <div className="p-4 bg-neutral-50 rounded-xl border border-neutral-100">
                <h4 className="font-bold text-xs text-neutral-900 mb-1">১. রক্তকণিকার পুনর্জন্ম</h4>
                <p className="text-xs text-neutral-500">
                  ১২০ দিনে পুরাতন লোহিত রক্তকণিকা ভেঙে গিয়ে বোন ম্যারো থেকে সম্পূর্ণ নতুন ও কর্মক্ষম কোষ তৈরি হয়।
                </p>
              </div>

              <div className="p-4 bg-neutral-50 rounded-xl border border-neutral-100">
                <h4 className="font-bold text-xs text-neutral-900 mb-1">২. হৃদরোগের ঝুঁকি হ্রাস</h4>
                <p className="text-xs text-neutral-500">
                  নিয়মিত ৪ মাস পর রক্তদানে শরীরে অতিরিক্ত আয়রন জমতে পারে না, যা হার্ট অ্যাটাক ও স্ট্রোকের ঝুঁকি কমায়।
                </p>
              </div>

              <div className="p-4 bg-neutral-50 rounded-xl border border-neutral-100">
                <h4 className="font-bold text-xs text-neutral-900 mb-1">৩. স্বয়ংক্রিয় নোটিফিকেশন</h4>
                <p className="text-xs text-neutral-500">
                  আমাদের অ্যাপে আপনার শেষ রক্তদানের তারিখ দিলেই ১২০ দিন পূর্ণ হওয়ার দিন সরাসরি এলার্ট পৌঁছে যাবে।
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Compatibility Matrix */}
      <div className="bg-white border border-neutral-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6">
        <div>
          <h3 className="text-lg font-bold text-neutral-900">
            ব্লাড গ্রুপ সামঞ্জস্যতা ক্যালকুলেটর (রক্তদাতা ও গ্রহীতা ম্যাচিং)
          </h3>
          <p className="text-xs text-neutral-500 mt-1">
            আপনার রক্তের গ্রুপ নির্বাচন করে দেখুন আপনি কাকে কাকে রক্ত দিতে পারবেন এবং কার কার রক্ত গ্রহণ করতে পারবেন:
          </p>
        </div>

        {/* Group Selector buttons */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2">
          {BLOOD_GROUPS.map((grp) => (
            <button
              key={grp}
              onClick={() => setSelectedGroup(grp)}
              className={`h-11 px-4 rounded-xl font-mono font-bold text-sm cursor-pointer transition-all border ${
                selectedGroup === grp
                  ? 'bg-red-600 text-white border-red-600 shadow-xs'
                  : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
              }`}
            >
              {grp}
            </button>
          ))}
        </div>

        {/* Results for selected group */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
          
          {/* Can Donate To */}
          <div className="p-5 bg-emerald-50/60 rounded-xl border border-emerald-200 space-y-3">
            <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{selectedGroup} গ্রুপ যাদের রক্ত দান করতে পারবে:</span>
            </div>
            
            <div className="flex flex-wrap gap-2 pt-1">
              {compatibility.canDonateTo.map((grp) => (
                <span
                  key={grp}
                  className="px-3 py-1.5 bg-white text-emerald-900 font-mono font-bold text-xs rounded-lg border border-emerald-300 shadow-xs"
                >
                  {grp}
                </span>
              ))}
            </div>
            {selectedGroup === 'O-' && (
              <p className="text-[11px] text-emerald-800 font-medium">
                🌟 ও-নেগেটিভ (O-) হলো সার্বজনীন রক্তদাতা (Universal Donor)।
              </p>
            )}
          </div>

          {/* Can Receive From */}
          <div className="p-5 bg-blue-50/60 rounded-xl border border-blue-200 space-y-3">
            <div className="flex items-center gap-2 text-blue-800 font-bold text-sm">
              <Heart className="w-4 h-4 text-blue-600" />
              <span>{selectedGroup} গ্রুপ যাদের থেকে রক্ত গ্রহণ করতে পারবে:</span>
            </div>
            
            <div className="flex flex-wrap gap-2 pt-1">
              {compatibility.canReceiveFrom.map((grp) => (
                <span
                  key={grp}
                  className="px-3 py-1.5 bg-white text-blue-900 font-mono font-bold text-xs rounded-lg border border-blue-300 shadow-xs"
                >
                  {grp}
                </span>
              ))}
            </div>
            {selectedGroup === 'AB+' && (
              <p className="text-[11px] text-blue-800 font-medium">
                🌟 এবি-পজিটিভ (AB+) হলো সার্বজনীন গ্রহীতা (Universal Recipient)।
              </p>
            )}
          </div>

        </div>
      </div>

      {/* Rules and Eligibility Criteria */}
      <div className="bg-white border border-neutral-200 rounded-2xl p-6 sm:p-8 shadow-xs">
        <h3 className="text-lg font-bold text-neutral-900 mb-4 flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-emerald-600" />
          <span>রক্তদানের প্রাথমিক শর্তাবলী ও স্বাস্থ্যবিধি</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-neutral-600">
          <div className="flex items-start gap-2.5 p-3 rounded-lg bg-neutral-50 border border-neutral-100">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-neutral-900 block mb-0.5">বয়স ও ওজন</strong>
              <span>বয়স ১৮ থেকে ৬০ বছরের মধ্যে এবং ওজন কমপক্ষে ৫০ কেজি (মহিলাদের ক্ষেত্রে কমপক্ষে ৪৫ কেজি)।</span>
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-3 rounded-lg bg-neutral-50 border border-neutral-100">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-neutral-900 block mb-0.5">হিমোগ্লোবিন স্তর</strong>
              <span>হিমোগ্লোবিনের মাত্রা পুরুষদের ক্ষেত্রে ন্যূনতম ১২.৫ গ্রাম/ডিএল এবং মহিলাদের ক্ষেত্রে ১২.০ গ্রাম/ডিএল।</span>
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-3 rounded-lg bg-neutral-50 border border-neutral-100">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-neutral-900 block mb-0.5">রক্তচাপ ও নাড়ির স্পন্দন</strong>
              <span>স্বাভাবিক রক্তচাপ (সিস্টোলিক ১০০-১৪০ এবং ডায়াস্টোলিক ৬০-৯০ মিমি পারদ)।</span>
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-3 rounded-lg bg-neutral-50 border border-neutral-100">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-neutral-900 block mb-0.5">রক্তদান থেকে বিরত থাকবেন কখন?</strong>
              <span>জ্বর বা অ্যান্টিবায়োটিক সেবনরত অবস্থায়, গর্ভবতী বা স্তন্যদানকারী মা, অথবা হেপাটাইটিস/জন্ডিসের ইতিহাস থাকলে।</span>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};
