import React, { useState } from 'react';
import { BloodGroup, Donor } from '../types';
import { ALLOWED_DISTRICTS, getUpazilasForDistrict, BLOOD_GROUPS } from '../data/bangladeshDistricts';
import { X, HeartHandshake, Camera, Upload, Mail, User } from 'lucide-react';

interface AddDonorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddDonor: (donor: Omit<Donor, 'id' | 'createdAt' | 'history'>) => void;
}

export const AddDonorModal: React.FC<AddDonorModalProps> = ({
  isOpen,
  onClose,
  onAddDonor,
}) => {
  const [name, setName] = useState('');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('A+');
  const [phone, setPhone] = useState('');
  const [altPhone, setAltPhone] = useState('');
  const [email, setEmail] = useState('');
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [district, setDistrict] = useState('ফরিদপুর');
  const [upazila, setUpazila] = useState('ফরিদপুর সদর');
  const [area, setArea] = useState('');
  const [age, setAge] = useState(24);
  const [gender, setGender] = useState<'পুরুষ' | 'মহিলা' | 'অন্যান্য'>('পুরুষ');
  const [neverDonated, setNeverDonated] = useState(false);
  const [lastDonationDate, setLastDonationDate] = useState('');
  const [totalDonations, setTotalDonations] = useState(1);

  if (!isOpen) return null;

  const handleProfileImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setProfilePicture(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const currentUpazilas = getUpazilasForDistrict(district);

  const handleDistrictChange = (newDistrict: string) => {
    setDistrict(newDistrict);
    const upazilas = getUpazilasForDistrict(newDistrict);
    if (upazilas.length > 0) {
      setUpazila(upazilas[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !area.trim()) return;

    onAddDonor({
      name: name.trim(),
      bloodGroup,
      phone: phone.trim(),
      altPhone: altPhone.trim() || undefined,
      email: email.trim() || undefined,
      profilePicture: profilePicture || undefined,
      district,
      upazila,
      area: area.trim(),
      age: Number(age) || 24,
      gender,
      lastDonationDate: neverDonated ? null : (lastDonationDate || null),
      totalDonations: neverDonated ? 0 : (Number(totalDonations) || 1),
      isAvailable: true,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-neutral-200 my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-red-100 text-red-600 flex items-center justify-center">
              <HeartHandshake className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-neutral-900">রক্তদাতা হিসেবে নিবন্ধন করুন</h2>
              <p className="text-xs text-neutral-500">
                ফরিদপুর, মাদারীপুর, গোপালগঞ্জ, রাজবাড়ী ও মাগুরা জেলার নেটওয়ার্কে যুক্ত হোন
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-4 text-xs">
          
          {/* Profile Picture Upload & Preview */}
          <div className="flex items-center gap-4 p-3 bg-neutral-50 rounded-xl border border-neutral-200">
            <div className="relative shrink-0">
              {profilePicture ? (
                <img
                  src={profilePicture}
                  alt="Profile"
                  className="w-16 h-16 rounded-2xl object-cover border-2 border-red-500 shadow-xs"
                />
              ) : (
                <div className="w-16 h-16 rounded-2xl bg-neutral-200 text-neutral-500 flex flex-col items-center justify-center border border-dashed border-neutral-300">
                  <User className="w-6 h-6 text-neutral-400" />
                  <span className="text-[9px] mt-0.5">ছবি নেই</span>
                </div>
              )}
            </div>

            <div className="space-y-1 flex-1">
              <label className="block font-semibold text-neutral-800">
                প্রোফাইল ছবি (ঐচ্ছিক)
              </label>
              <div className="flex items-center gap-2">
                <label className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-lg text-xs font-semibold text-neutral-700 cursor-pointer shadow-2xs">
                  <Camera className="w-3.5 h-3.5 text-red-600" />
                  <span>ছবি নির্বাচন করুন</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleProfileImageChange}
                    className="sr-only"
                  />
                </label>
                {profilePicture && (
                  <button
                    type="button"
                    onClick={() => setProfilePicture(null)}
                    className="text-xs text-red-600 hover:underline cursor-pointer"
                  >
                    মুছে ফেলুন
                  </button>
                )}
              </div>
              <p className="text-[10px] text-neutral-400">গ্যালারি বা ক্যামেরা থেকে নিজের স্পষ্ট ছবি যোগ করুন</p>
            </div>
          </div>

          {/* Name & Blood Group */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block font-semibold text-neutral-700 mb-1">
                আপনার পুরো নাম *
              </label>
              <input
                type="text"
                required
                placeholder="যেমন: মোঃ সাব্বির আহমেদ"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                রক্তের গ্রুপ *
              </label>
              <select
                value={bloodGroup}
                onChange={(e) => setBloodGroup(e.target.value as BloodGroup)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none font-mono font-bold text-red-600 bg-white"
              >
                {BLOOD_GROUPS.map((grp) => (
                  <option key={grp} value={grp}>
                    {grp}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Phone Numbers & Email */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                মোবাইল নম্বর *
              </label>
              <input
                type="tel"
                required
                placeholder="017XXXXXXXX"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                বিকল্প নম্বর (ঐচ্ছিক)
              </label>
              <input
                type="tel"
                placeholder="018XXXXXXXX"
                value={altPhone}
                onChange={(e) => setAltPhone(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                ইমেইল এড্রেস (ঐচ্ছিক)
              </label>
              <input
                type="email"
                placeholder="name@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>
          </div>

          {/* District & Upazila (Only 5 districts & their upazilas) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                জেলা *
              </label>
              <select
                value={district}
                onChange={(e) => handleDistrictChange(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none bg-white font-medium"
              >
                {ALLOWED_DISTRICTS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                উপজেলা *
              </label>
              <select
                value={upazila}
                onChange={(e) => setUpazila(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none bg-white font-medium"
              >
                {currentUpazilas.map((u) => (
                  <option key={u} value={u}>
                    {u}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Specific Area / Address */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              বর্তমান এলাকা / গ্রাম / বাজার *
            </label>
            <input
              type="text"
              required
              placeholder="যেমন: ভাঙ্গা বাজার, মধুখালী রোড, ঝিলটুলী..."
              value={area}
              onChange={(e) => setArea(e.target.value)}
              className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
            />
          </div>

          {/* Age & Gender */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                বয়স (১৮-৬০ বছর) *
              </label>
              <input
                type="number"
                min="18"
                max="65"
                required
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                লিঙ্গ
              </label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as 'পুরুষ' | 'মহিলা' | 'অন্যান্য')}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none bg-white"
              >
                <option value="পুরুষ">পুরুষ</option>
                <option value="মহিলা">মহিলা</option>
                <option value="অন্যান্য">অন্যান্য</option>
              </select>
            </div>
          </div>

          {/* Donation History Details */}
          <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 space-y-2.5">
            <div className="flex items-center gap-2">
              <input
                id="neverDonatedCheckbox"
                type="checkbox"
                checked={neverDonated}
                onChange={(e) => setNeverDonated(e.target.checked)}
                className="w-4 h-4 text-red-600 rounded focus:ring-red-500"
              />
              <label htmlFor="neverDonatedCheckbox" className="font-semibold text-neutral-800 cursor-pointer">
                আমি এখনও রক্ত দিইনি (প্রথমবার রক্তদান করব)
              </label>
            </div>

            {!neverDonated && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">
                    শেষ রক্তদানের তারিখ *
                  </label>
                  <input
                    type="date"
                    required={!neverDonated}
                    value={lastDonationDate}
                    onChange={(e) => setLastDonationDate(e.target.value)}
                    className="w-full text-xs border border-neutral-300 rounded-lg p-2 focus:border-red-500 focus:outline-none bg-white"
                  />
                  <span className="text-[10px] text-neutral-400 mt-0.5 block">
                    এটি অনুযায়ী ৪-মাসের নোটিফিকেশন ট্র্যাক হবে
                  </span>
                </div>

                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">
                    মোট রক্তদানের সংখ্যা
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={totalDonations}
                    onChange={(e) => setTotalDonations(Number(e.target.value))}
                    className="w-full text-xs border border-neutral-300 rounded-lg p-2 focus:border-red-500 focus:outline-none bg-white font-mono"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 font-semibold text-neutral-600 hover:bg-neutral-100 rounded-lg cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              নিবন্ধন সম্পন্ন করুন
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
