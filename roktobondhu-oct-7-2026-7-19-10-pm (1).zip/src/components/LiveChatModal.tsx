import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage } from '../types';
import { X, Send, MessageSquare, Phone, User, CheckCheck } from 'lucide-react';
import { playNotificationChime } from '../utils/bloodLogic';

interface LiveChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUserId: string;
  currentUserName: string;
  targetUser: {
    id: string;
    name: string;
    phone: string;
    bloodGroup?: string;
    subtitle?: string;
  } | null;
  messages: ChatMessage[];
  onSendMessage: (receiverId: string, receiverName: string, text: string) => void;
}

export const LiveChatModal: React.FC<LiveChatModalProps> = ({
  isOpen,
  onClose,
  currentUserId,
  currentUserName,
  targetUser,
  messages,
  onSendMessage,
}) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Filter messages for this conversation
  const threadMessages = React.useMemo(() => {
    if (!targetUser) return [];
    return messages.filter(
      (m) =>
        (m.senderId === currentUserId && m.receiverId === targetUser.id) ||
        (m.senderId === targetUser.id && m.receiverId === currentUserId)
    );
  }, [messages, currentUserId, targetUser]);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isOpen, threadMessages.length]);

  if (!isOpen || !targetUser) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    onSendMessage(targetUser.id, targetUser.name, inputText.trim());
    setInputText('');
    playNotificationChime();
  };

  const handleQuickReply = (text: string) => {
    onSendMessage(targetUser.id, targetUser.name, text);
    playNotificationChime();
  };

  const quickReplies = [
    'আসসালামু আলাইকুম, আমি রক্ত দিতে প্রস্তুত।',
    'হাসপাতাল কোথায় এবং কয়টায় উপস্থিত হতে হবে?',
    'রোগীর রক্তের ক্রস-ম্যাচিং কি করা হয়েছে?',
    'ইনশাআল্লাহ আমি সময়মতো পৌঁছাবো।',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full h-[620px] max-h-[90vh] shadow-2xl border border-neutral-200 flex flex-col justify-between overflow-hidden">
        
        {/* Chat Header */}
        <div className="p-4 bg-white border-b border-neutral-200 flex items-center justify-between shadow-2xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-red-600 text-white font-bold font-mono text-sm flex items-center justify-center shadow-xs shrink-0">
              {targetUser.bloodGroup || 'ব্লাড'}
            </div>
            <div>
              <h3 className="font-bold text-sm text-neutral-900 leading-tight">
                {targetUser.name}
              </h3>
              <p className="text-[11px] text-neutral-500 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                <span>সরাসরি চ্যাট সক্রিয় · {targetUser.phone}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <a
              href={`tel:${targetUser.phone}`}
              className="p-2 text-neutral-600 hover:text-red-600 hover:bg-neutral-100 rounded-lg cursor-pointer transition-colors"
              title="কল করুন"
            >
              <Phone className="w-4 h-4" />
            </a>
            <button
              onClick={onClose}
              className="p-2 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 rounded-lg cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Message Thread Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-neutral-50/60 text-xs">
          {threadMessages.length > 0 ? (
            threadMessages.map((msg) => {
              const isMe = msg.senderId === currentUserId;
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[78%] p-3 rounded-2xl text-xs leading-relaxed shadow-2xs ${
                      isMe
                        ? 'bg-red-600 text-white rounded-br-xs'
                        : 'bg-white text-neutral-800 border border-neutral-200 rounded-bl-xs'
                    }`}
                  >
                    {msg.text}
                  </div>
                  <span className="text-[10px] text-neutral-400 mt-1 px-1 flex items-center gap-1">
                    <span>{msg.timestamp}</span>
                    {isMe && <CheckCheck className="w-3 h-3 text-red-500" />}
                  </span>
                </div>
              );
            })
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center text-neutral-400 p-6 space-y-2">
              <MessageSquare className="w-10 h-10 opacity-30" />
              <p className="font-semibold text-neutral-700">সরাসরি বার্তা শুরু করুন</p>
              <p className="text-[11px] max-w-xs">
                রক্তদানের সময়সূচি ও হাসপাতালের তথ্য নিশ্চিত করতে নিচের দ্রুত মেসেজগুলো ব্যবহার করতে পারেন।
              </p>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Message Chips */}
        <div className="px-3 py-2 bg-white border-t border-neutral-100 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {quickReplies.map((reply, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleQuickReply(reply)}
              className="px-2.5 py-1 text-[11px] bg-neutral-100 hover:bg-red-50 hover:text-red-700 rounded-lg whitespace-nowrap text-neutral-700 transition-colors cursor-pointer border border-neutral-200"
            >
              {reply}
            </button>
          ))}
        </div>

        {/* Input Form */}
        <form onSubmit={handleSend} className="p-3 bg-white border-t border-neutral-200 flex items-center gap-2">
          <input
            type="text"
            placeholder="একটি মেসেজ লিখুন..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className="flex-1 text-xs border border-neutral-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-red-500 bg-neutral-50"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="p-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-40 text-white rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};
