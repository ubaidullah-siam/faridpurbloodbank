import React, { useState } from 'react';
import { BloodGroup } from '../types';
import { ALLOWED_DISTRICTS, getUpazilasForDistrict, BLOOD_GROUPS } from '../data/bangladeshDistricts';
import { Search, X, MapPin, Users, ArrowRight } from 'lucide-react';

interface QuickSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPerformSearch: (group: BloodGroup | 'ALL', district: string, upazila: string, query: string) => void;
}

export const QuickSearchModal: React.FC<QuickSearchModalProps> = ({
  isOpen,
  onClose,
  onPerformSearch,
}) => {
  const [group, setGroup] = useState<BloodGroup | 'ALL'>('ALL');
  const [district, setDistrict] = useState<string>('ALL');
  const [upazila, setUpazila] = useState<string>('ALL');
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const upazilas = district !== 'ALL' ? getUpazilasForDistrict(district) : [];

  const handleDistrictChange = (d: string) => {
    setDistrict(d);
    setUpazila('ALL');
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onPerformSearch(group, district, upazila, query);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-neutral-200 my-8 space-y-5 animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
          <div className="flex items-center gap-2.5">
            <span className="w-10 h-10 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center">
              <Search className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-bold text-lg text-neutral-900">দ্রুত রক্তদাতা সার্চ করুন</h3>
              <p className="text-xs text-neutral-500">গ্রুপ, জেলা বা উপজেলা অনুযায়ী খুঁজুন</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSearch} className="space-y-4 text-xs">
          
          {/* Blood group pills */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1.5">
              কাঙ্ক্ষিত রক্তের গ্রুপ নির্বাচন করুন:
            </label>
            <div className="grid grid-cols-5 gap-1.5">
              <button
                type="button"
                onClick={() => setGroup('ALL')}
                className={`py-2 rounded-xl font-bold transition-colors cursor-pointer text-xs ${
                  group === 'ALL'
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                সকল
              </button>
              {BLOOD_GROUPS.map((grp) => (
                <button
                  key={grp}
                  type="button"
                  onClick={() => setGroup(grp)}
                  className={`py-2 rounded-xl font-mono font-bold transition-colors cursor-pointer text-xs ${
                    group === grp
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                  }`}
                >
                  {grp}
                </button>
              ))}
            </div>
          </div>

          {/* District & Upazila */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                জেলা নির্বাচন:
              </label>
              <select
                value={district}
                onChange={(e) => handleDistrictChange(e.target.value)}
                className="w-full text-xs border border-neutral-300 rounded-xl p-2.5 focus:border-red-500 focus:outline-none bg-white font-medium"
              >
                <option value="ALL">সকল ৫ জেলা</option>
                {ALLOWED_DISTRICTS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                উপজেলা:
              </label>
              <select
                value={upazila}
                disabled={district === 'ALL'}
                onChange={(e) => setUpazila(e.target.value)}
                className="w-full text-xs border border-neutral-300 rounded-xl p-2.5 focus:border-red-500 focus:outline-none bg-white font-medium disabled:bg-neutral-100 disabled:opacity-70"
              >
                <option value="ALL">সকল উপজেলা</option>
                {upazilas.map((u) => (
                  <option key={u} value={u}>
                    {u}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Keyword Search */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              রক্তদাতার নাম, এলাকা বা ফোন নম্বর:
            </label>
            <input
              type="text"
              placeholder="যেমন: ভাঙ্গা বাজার, সাকিব, 017..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full text-xs border border-neutral-300 rounded-xl p-2.5 focus:border-red-500 focus:outline-none"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-neutral-600 hover:bg-neutral-100 rounded-xl cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <Search className="w-4 h-4" />
              <span>রক্তদাতা খুঁজুন</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
