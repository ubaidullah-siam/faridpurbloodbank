import React, { useState } from 'react';
import { DonationStory } from '../types';
import { ALLOWED_DISTRICTS } from '../data/bangladeshDistricts';
import { toBengaliNumber } from '../utils/bloodLogic';
import { Heart, MessageSquare, Camera, MapPin, Calendar, Send, User } from 'lucide-react';

interface CommunityStoriesProps {
  stories: DonationStory[];
  onOpenUploadModal: () => void;
  onLikeStory: (storyId: string) => void;
  onAddComment: (storyId: string, authorName: string, commentText: string) => void;
  onShowToast: (msg: string) => void;
}

export const CommunityStories: React.FC<CommunityStoriesProps> = ({
  stories,
  onOpenUploadModal,
  onLikeStory,
  onAddComment,
  onShowToast,
}) => {
  const [selectedDistrict, setSelectedDistrict] = useState<string>('ALL');
  const [activeCommentBox, setActiveCommentBox] = useState<string | null>(null);
  const [commentAuthor, setCommentAuthor] = useState('');
  const [commentText, setCommentText] = useState('');

  const filteredStories = stories.filter((story) => {
    if (selectedDistrict !== 'ALL' && story.district !== selectedDistrict) return false;
    return true;
  });

  const handleCommentSubmit = (storyId: string, e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    onAddComment(
      storyId,
      commentAuthor.trim() || 'শুভাকাঙ্ক্ষী',
      commentText.trim()
    );

    setCommentText('');
    onShowToast('💬 আপনার মন্তব্য সফলভাবে যুক্ত হয়েছে!');
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white border border-neutral-200 rounded-2xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-red-100 text-red-600 flex items-center justify-center">
              <Camera className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-neutral-900 tracking-tight">
              রক্তদাতাদের ছবি ও মন্তব্য গ্যালারি (Wall of Heroes)
            </h2>
          </div>
          <p className="text-xs text-neutral-500 mt-1">
            ফরিদপুর, মাদারীপুর, গোপালগঞ্জ, রাজবাড়ী ও মাগুরা জেলার বীর রক্তদাতাদের রক্তদানের মুহূর্ত ও অভিজ্ঞতা
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenUploadModal}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs transition-colors cursor-pointer shrink-0"
        >
          <Camera className="w-4 h-4" />
          <span>আমার রক্তদানের ছবি ও মন্তব্য যোগ করুন</span>
        </button>
      </div>

      {/* District Filter tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 bg-white p-2.5 rounded-xl border border-neutral-200">
        <button
          type="button"
          onClick={() => setSelectedDistrict('ALL')}
          className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer shrink-0 ${
            selectedDistrict === 'ALL'
              ? 'bg-neutral-900 text-white'
              : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
          }`}
        >
          সকল জেলা ({toBengaliNumber(stories.length)})
        </button>

        {ALLOWED_DISTRICTS.map((dist) => {
          const count = stories.filter((s) => s.district === dist).length;
          const isSelected = selectedDistrict === dist;
          return (
            <button
              key={dist}
              type="button"
              onClick={() => setSelectedDistrict(dist)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer shrink-0 ${
                isSelected
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'bg-neutral-100 text-neutral-700 hover:bg-red-50 hover:text-red-700'
              }`}
            >
              {dist} ({toBengaliNumber(count)})
            </button>
          );
        })}
      </div>

      {/* Story Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredStories.map((story) => (
          <div
            key={story.id}
            className="bg-white rounded-2xl border border-neutral-200 overflow-hidden shadow-xs hover:border-neutral-300 transition-all flex flex-col justify-between"
          >
            <div>
              {/* Story Photo */}
              <div className="relative aspect-[16/10] bg-neutral-100 overflow-hidden">
                <img
                  src={story.photoUrl}
                  alt={story.donorName}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover hover:scale-103 transition-transform duration-500"
                />
                <span className="absolute top-3 left-3 px-2.5 py-1 bg-red-600 text-white font-mono font-bold text-xs rounded-md shadow-xs">
                  {story.bloodGroup}
                </span>
                <span className="absolute bottom-3 right-3 px-2.5 py-1 bg-black/70 backdrop-blur-xs text-white text-[11px] rounded-md font-medium">
                  {story.upazila}, {story.district}
                </span>
              </div>

              {/* Story Details */}
              <div className="p-5 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-bold text-base text-neutral-900">
                      {story.donorName}
                    </h3>
                    <p className="text-xs text-neutral-500 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-neutral-400" />
                      <span>{story.hospitalName}</span>
                    </p>
                  </div>
                  <div className="text-[11px] text-neutral-400 font-mono flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    <span>{story.donationDate}</span>
                  </div>
                </div>

                {/* Donor Quote / Comment */}
                <p className="text-xs text-neutral-700 bg-neutral-50 p-3 rounded-xl border border-neutral-100 leading-relaxed italic">
                  "{story.userFeedback}"
                </p>

                {/* Likes & Comments stats bar */}
                <div className="flex items-center justify-between text-xs text-neutral-500 pt-1 border-t border-neutral-100">
                  <button
                    type="button"
                    onClick={() => onLikeStory(story.id)}
                    className="flex items-center gap-1.5 text-neutral-600 hover:text-red-600 transition-colors cursor-pointer group py-1"
                  >
                    <Heart className="w-4 h-4 text-red-500 group-hover:scale-125 transition-transform" />
                    <span>{toBengaliNumber(story.likesCount)} লাইক</span>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      setActiveCommentBox(activeCommentBox === story.id ? null : story.id)
                    }
                    className="flex items-center gap-1.5 text-neutral-600 hover:text-neutral-900 transition-colors cursor-pointer py-1"
                  >
                    <MessageSquare className="w-4 h-4 text-neutral-400" />
                    <span>{toBengaliNumber(story.comments.length)} মন্তব্য</span>
                  </button>
                </div>

                {/* Comment thread */}
                {story.comments.length > 0 && (
                  <div className="space-y-1.5 pt-1">
                    <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
                      মন্তব্যসমূহ:
                    </div>
                    <div className="space-y-1 max-h-32 overflow-y-auto pr-1">
                      {story.comments.map((c) => (
                        <div key={c.id} className="text-xs bg-neutral-50 p-2 rounded-lg">
                          <strong className="text-neutral-800 font-semibold">{c.authorName}:</strong>{' '}
                          <span className="text-neutral-600">{c.commentText}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Comment input form */}
            <div className="p-4 bg-neutral-50/70 border-t border-neutral-100">
              <form
                onSubmit={(e) => handleCommentSubmit(story.id, e)}
                className="space-y-2 text-xs"
              >
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="আপনার নাম"
                    value={activeCommentBox === story.id ? commentAuthor : ''}
                    onChange={(e) => {
                      setActiveCommentBox(story.id);
                      setCommentAuthor(e.target.value);
                    }}
                    className="w-1/3 p-1.5 text-xs bg-white border border-neutral-200 rounded-md focus:outline-none focus:border-red-400"
                  />
                  <input
                    type="text"
                    required
                    placeholder="রক্তদাতাকে শুভকামনা বা মন্তব্য জানান..."
                    value={activeCommentBox === story.id ? commentText : ''}
                    onChange={(e) => {
                      setActiveCommentBox(story.id);
                      setCommentText(e.target.value);
                    }}
                    className="flex-1 p-1.5 text-xs bg-white border border-neutral-200 rounded-md focus:outline-none focus:border-red-400"
                  />
                  <button
                    type="submit"
                    className="p-1.5 bg-red-600 hover:bg-red-700 text-white rounded-md transition-colors cursor-pointer"
                    title="মন্তব্য পাঠান"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </form>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
