import React, { useState } from 'react';
import { Donor, BloodBooking, BloodRequest } from '../types';
import { toBengaliNumber } from '../utils/bloodLogic';
import {
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Award,
  Edit3,
  Camera,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  ShieldCheck,
  CalendarCheck,
  Send,
  Eye,
  EyeOff,
  KeyRound,
  Power,
  ToggleLeft,
  ToggleRight,
  LogOut,
  Building,
  Home as HomeIcon,
} from 'lucide-react';

interface MyProfilePageProps {
  currentUser: Donor;
  bookings: BloodBooking[];
  requests: BloodRequest[];
  onUpdateDonor: (updated: Donor) => void;
  onConsentBooking: (bookingId: string, consent: boolean) => void;
  onOpenEditModal: () => void;
  onOpenCongratulationCard: () => void;
  onLogout?: () => void;
  onShowToast: (msg: string) => void;
}

export const MyProfilePage: React.FC<MyProfilePageProps> = ({
  currentUser,
  bookings,
  requests,
  onUpdateDonor,
  onConsentBooking,
  onOpenEditModal,
  onOpenCongratulationCard,
  onLogout,
  onShowToast,
}) => {
  // Password change state
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [showPassText, setShowPassText] = useState(false);
  const [passError, setPassError] = useState('');

  // Active bookings related to this donor
  const myBookings = bookings.filter((b) => b.donorId === currentUser.id);

  // Urgent requests sorted by priority
  const sortedRequests = [...requests].sort((a, b) => {
    const isCriticalA = a.urgency.includes('সংকটাপন্ন') || a.urgency.includes('Critical');
    const isCriticalB = b.urgency.includes('সংকটাপন্ন') || b.urgency.includes('Critical');
    if (isCriticalA && !isCriticalB) return -1;
    if (!isCriticalA && isCriticalB) return 1;
    return 0;
  });

  // Single Clean Availability Toggle (User requirement: অন থাকবে রক্ত দিতে আগ্রহী, অফ হলে রক্ত দিতে উপলব্ধ নয়)
  const handleToggleAvailability = () => {
    const nextStatus = !currentUser.isAvailable;
    const updated: Donor = {
      ...currentUser,
      isAvailable: nextStatus,
      unavailability: nextStatus
        ? null
        : {
            type: 'other',
            label: 'রক্ত দিতে উপলব্ধ নয় (নিষ্ক্রিয়)',
          },
    };
    onUpdateDonor(updated);
    if (nextStatus) {
      onShowToast('✅ আপনার প্রোফাইল সক্রিয় করা হয়েছে: আপনি এখন রক্তদানে আগ্রহী ও প্রস্তুত!');
    } else {
      onShowToast('🔒 আপনার প্রোফাইল নিষ্ক্রিয় করা হয়েছে: তালিকায় আপনি "উপলব্ধ নয়" হিসেবে প্রদর্শিত হবেন এবং কল বন্ধ থাকবে।');
    }
  };

  // Password change handler
  const handleSavePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPassError('');

    if (currentUser.password && currentPass !== currentUser.password) {
      setPassError('বর্তমান পাসওয়ার্ডটি সঠিক নয়!');
      return;
    }

    if (newPass.length < 4) {
      setPassError('নতুন পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে!');
      return;
    }

    if (newPass !== confirmPass) {
      setPassError('নতুন পাসওয়ার্ড দুটি মিলছে না!');
      return;
    }

    const updated: Donor = {
      ...currentUser,
      password: newPass,
    };
    onUpdateDonor(updated);
    setShowPasswordChange(false);
    setCurrentPass('');
    setNewPass('');
    setConfirmPass('');
    onShowToast('🔑 পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে!');
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-20">
      
      {/* 1. Profile Banner Header */}
      <div className="bg-white border border-neutral-200 rounded-3xl p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          
          <div className="flex items-center gap-4 sm:gap-5">
            {/* Profile Picture */}
            <div className="relative">
              {currentUser.profilePicture ? (
                <img
                  src={currentUser.profilePicture}
                  alt={currentUser.name}
                  className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-2 border-red-500 shadow-sm"
                />
              ) : (
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-gradient-to-br from-red-600 to-rose-700 text-white flex items-center justify-center font-bold text-3xl font-mono shadow-sm">
                  {currentUser.bloodGroup}
                </div>
              )}
              <span className="absolute -bottom-1 -right-1 px-2 py-0.5 bg-red-600 text-white font-mono font-bold text-xs rounded-md shadow-xs">
                {currentUser.bloodGroup}
              </span>
            </div>

            {/* Profile Credentials */}
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold text-neutral-900">{currentUser.name}</h1>
                {currentUser.isAvailable ? (
                  <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-[11px] font-bold rounded-full border border-emerald-300 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
                    <span>সক্রিয় (রক্তদানে প্রস্তুত)</span>
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 bg-neutral-200 text-neutral-800 text-[11px] font-bold rounded-full border border-neutral-300 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-neutral-500" />
                    <span>উপলব্ধ নয় (কল বন্ধ)</span>
                  </span>
                )}
              </div>

              {/* Village, Union, Upazila & District */}
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-neutral-600">
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-neutral-400" />
                  <span className="font-mono font-medium">{currentUser.phone}</span>
                </span>
                {currentUser.altPhone && (
                  <>
                    <span aria-hidden="true" className="text-neutral-300">·</span>
                    <span className="text-neutral-500 font-mono">বিকল্প: {currentUser.altPhone}</span>
                  </>
                )}
                {currentUser.email && (
                  <>
                    <span aria-hidden="true" className="text-neutral-300">·</span>
                    <span className="flex items-center gap-1 text-neutral-600">
                      <Mail className="w-3.5 h-3.5 text-neutral-400" />
                      <span>{currentUser.email}</span>
                    </span>
                  </>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-x-2 text-xs text-neutral-600 pt-0.5">
                <span className="flex items-center gap-1 text-neutral-800 font-medium">
                  <MapPin className="w-3.5 h-3.5 text-red-500" />
                  <span>
                    {currentUser.village ? `${currentUser.village}, ` : ''}
                    {currentUser.union ? `${currentUser.union}, ` : ''}
                    {currentUser.upazila}, {currentUser.district}
                  </span>
                </span>
                <span aria-hidden="true" className="text-neutral-300">·</span>
                <span className="text-neutral-500 font-mono">
                  মোট {toBengaliNumber(currentUser.totalDonations)} বার রক্তদান
                </span>
              </div>
            </div>
          </div>

          {/* Quick Profile Actions */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onOpenCongratulationCard}
              className="px-3.5 py-2 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shadow-2xs"
            >
              <Award className="w-4 h-4 text-amber-600" />
              <span>ডিজিটাল অভিনন্দন সনদ</span>
            </button>

            <button
              type="button"
              onClick={onOpenEditModal}
              className="px-3.5 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-xl text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>তথ্য এডিট</span>
            </button>

            {onLogout && (
              <button
                type="button"
                onClick={onLogout}
                className="px-3 py-2 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-xl text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1"
                title="লগআউট করুন"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>লগআউট</span>
              </button>
            )}
          </div>

        </div>
      </div>

      {/* 2. INSTANT AVAILABILITY TOGGLE (User prompt: সুইচ অন থাকলে রক্ত দিতে আগ্রহী, অফ হলে রক্ত দিতে উপলব্ধ নয়) */}
      <div className={`rounded-3xl p-6 sm:p-7 border-2 transition-all shadow-xs ${
        currentUser.isAvailable
          ? 'bg-gradient-to-r from-emerald-50 via-white to-emerald-50/40 border-emerald-400'
          : 'bg-gradient-to-r from-neutral-100 via-white to-neutral-100/50 border-neutral-300'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className={`w-3 h-3 rounded-full ${currentUser.isAvailable ? 'bg-emerald-500 animate-pulse' : 'bg-neutral-400'}`} />
              <h2 className="text-base sm:text-lg font-bold text-neutral-900">
                রক্তদানের আগ্রহ ও প্রাপ্যতা সুইচ (Availability Status)
              </h2>
            </div>
            <p className="text-xs text-neutral-600 max-w-xl">
              {currentUser.isAvailable ? (
                <span>
                  🟢 <strong>সুইচ অন রয়েছে:</strong> আপনি বর্তমানে রক্ত দিতে আগ্রহী। রক্তদাতা তালিকায় আপনার প্রোফাইল প্রস্তুত দেখাবে এবং গ্রহীতারা সরাসরি কল করতে পারবে।
                </span>
              ) : (
                <span>
                  🔴 <strong>সুইচ অফ রয়েছে:</strong> আপনি বর্তমানে রক্ত দিতে উপলব্ধ নন। রক্তদাতা তালিকায় আপনার প্রোফাইল "উপলব্ধ নয়" দেখাবে এবং কল অপশন স্বয়ংক্রিয়ভাবে বন্ধ থাকবে।
                </span>
              )}
            </p>
          </div>

          {/* Large Interactive Switch */}
          <button
            type="button"
            onClick={handleToggleAvailability}
            className={`px-5 py-3 rounded-2xl font-bold text-xs flex items-center gap-2.5 transition-all cursor-pointer shadow-xs shrink-0 ${
              currentUser.isAvailable
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-500/20'
                : 'bg-neutral-800 hover:bg-neutral-900 text-white'
            }`}
          >
            <Power className="w-4 h-4" />
            <span>
              {currentUser.isAvailable ? 'রক্তদানে প্রস্তুত (সক্রিয়)' : 'উপলব্ধ নয় (নিষ্ক্রিয়)'}
            </span>
          </button>
        </div>
      </div>

      {/* 3. PASSWORD MANAGEMENT BOX (User prompt: প্রোফাইলের ভেতরে পাসওয়ার্ড চেঞ্জ করার অপশন থাকবে) */}
      <div className="bg-white border border-neutral-200 rounded-3xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
          <div className="flex items-center gap-2.5">
            <span className="w-9 h-9 rounded-xl bg-neutral-100 text-neutral-700 flex items-center justify-center">
              <KeyRound className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-bold text-base text-neutral-900">পাসওয়ার্ড পরিবর্তন ও নিরাপত্তা</h3>
              <p className="text-xs text-neutral-500">পরবর্তী লগইনের জন্য আপনার পাসওয়ার্ড পরিবর্তন করুন</p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setShowPasswordChange(!showPasswordChange)}
            className="px-3.5 py-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
          >
            {showPasswordChange ? 'বাতিল' : 'পাসওয়ার্ড পরিবর্তন'}
          </button>
        </div>

        {showPasswordChange && (
          <form onSubmit={handleSavePassword} className="space-y-3.5 max-w-md pt-2 text-xs">
            {passError && (
              <p className="text-xs text-red-600 font-semibold p-2 bg-red-50 rounded-lg">{passError}</p>
            )}

            {currentUser.password && (
              <div>
                <label className="block font-semibold text-neutral-700 mb-1">
                  বর্তমান পাসওয়ার্ড *
                </label>
                <input
                  type={showPassText ? 'text' : 'password'}
                  required
                  placeholder="বর্তমান পাসওয়ার্ড দিন"
                  value={currentPass}
                  onChange={(e) => setCurrentPass(e.target.value)}
                  className="w-full text-xs border border-neutral-300 rounded-xl p-2.5 focus:border-red-500 focus:outline-none font-mono"
                />
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-neutral-700 mb-1">
                  নতুন পাসওয়ার্ড *
                </label>
                <input
                  type={showPassText ? 'text' : 'password'}
                  required
                  placeholder="কমপক্ষে ৪ সংখ্যা"
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  className="w-full text-xs border border-neutral-300 rounded-xl p-2.5 focus:border-red-500 focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-700 mb-1">
                  পাসওয়ার্ড নিশ্চিত করুন *
                </label>
                <input
                  type={showPassText ? 'text' : 'password'}
                  required
                  placeholder="পুনরায় পাসওয়ার্ড দিন"
                  value={confirmPass}
                  onChange={(e) => setConfirmPass(e.target.value)}
                  className="w-full text-xs border border-neutral-300 rounded-xl p-2.5 focus:border-red-500 focus:outline-none font-mono"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-1.5 cursor-pointer text-neutral-600">
                <input
                  type="checkbox"
                  checked={showPassText}
                  onChange={(e) => setShowPassText(e.target.checked)}
                  className="rounded text-red-600"
                />
                <span>পাসওয়ার্ড দেখুন</span>
              </label>

              <button
                type="submit"
                className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-xs"
              >
                সংরক্ষণ করুন
              </button>
            </div>
          </form>
        )}
      </div>

      {/* 4. BOOKING CONSENT & REQUESTS MANAGEMENT */}
      <div className="bg-white border border-neutral-200 rounded-3xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
          <div>
            <h2 className="text-base font-bold text-neutral-900">
              আমার জন্য আসা রক্তদান বুকিংয়ের অনুরোধ
            </h2>
            <p className="text-xs text-neutral-500">
              রক্তদাতা সম্মতি দিলে তবেই বুকিং চূড়ান্ত হবে এবং কার্ডে "🔒 বুকড" দেখাবে
            </p>
          </div>
          <span className="text-xs font-mono font-semibold bg-neutral-100 px-2.5 py-0.5 rounded-lg">
            {toBengaliNumber(myBookings.length)} টি বুকিং
          </span>
        </div>

        {myBookings.length > 0 ? (
          <div className="space-y-3">
            {myBookings.map((book) => (
              <div
                key={book.id}
                className="p-4 rounded-2xl border border-neutral-200 bg-neutral-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-neutral-900">{book.patientName}</span>
                    {book.status === 'booked' && (
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded">
                        🔒 সম্মতি নিশ্চিত (বুকড)
                      </span>
                    )}
                    {book.status === 'pending_consent' && (
                      <span className="px-2 py-0.5 bg-amber-100 text-amber-900 text-[10px] font-bold rounded animate-pulse">
                        সম্মতির অপেক্ষায়
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-neutral-600">
                    রক্তদানের তারিখ: <strong>{book.scheduledDate}</strong> · হাসপাতাল: <strong>{book.hospitalName}</strong>
                  </p>
                  <p className="text-[11px] text-neutral-500">
                    যোগাযোগ: {book.recipientName} ({book.recipientPhone}) · নোট: "{book.notes || 'জরুরি বুকিং'}"
                  </p>
                </div>

                {book.status === 'pending_consent' && (
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => onConsentBooking(book.id, true)}
                      className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-xs"
                    >
                      সম্মতি দিন (বুক করুন)
                    </button>
                    <button
                      type="button"
                      onClick={() => onConsentBooking(book.id, false)}
                      className="px-3 py-2 bg-neutral-200 hover:bg-neutral-300 text-neutral-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                    >
                      বাতিল
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6 text-neutral-400 text-xs border border-dashed border-neutral-200 rounded-2xl">
            বর্তমানে কোনো রক্তদান বুকিংয়ের অনুরোধ অপেক্ষমান নেই।
          </div>
        )}
      </div>

    </div>
  );
};
