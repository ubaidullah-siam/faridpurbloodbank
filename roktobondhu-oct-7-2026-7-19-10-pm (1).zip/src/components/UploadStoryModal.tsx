import React, { useState } from 'react';
import { BloodGroup, DonationStory } from '../types';
import { ALLOWED_DISTRICTS, getUpazilasForDistrict, BLOOD_GROUPS } from '../data/bangladeshDistricts';
import { X, Upload, Camera, Image as ImageIcon, Heart } from 'lucide-react';

interface UploadStoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (storyData: Omit<DonationStory, 'id' | 'likesCount' | 'comments' | 'createdAt'>) => void;
  defaultDonorName?: string;
  defaultBloodGroup?: BloodGroup;
  defaultDistrict?: string;
  defaultUpazila?: string;
}

export const UploadStoryModal: React.FC<UploadStoryModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  defaultDonorName = '',
  defaultBloodGroup = 'O+',
  defaultDistrict = 'ফরিদপুর',
  defaultUpazila = 'ফরিদপুর সদর',
}) => {
  const [donorName, setDonorName] = useState(defaultDonorName);
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>(defaultBloodGroup);
  const [district, setDistrict] = useState(defaultDistrict);
  const [upazila, setUpazila] = useState(defaultUpazila);
  const [hospitalName, setHospitalName] = useState('ফরিদপুর মেডিকেল কলেজ হাসপাতাল');
  const [donationDate, setDonationDate] = useState(new Date().toISOString().split('T')[0]);
  const [userFeedback, setUserFeedback] = useState('');
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [imageError, setImageError] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentUpazilas = getUpazilasForDistrict(district);

  const handleDistrictChange = (newDistrict: string) => {
    setDistrict(newDistrict);
    const upazilas = getUpazilasForDistrict(newDistrict);
    if (upazilas.length > 0) {
      setUpazila(upazilas[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setImageError(null);
    if (!file) return;

    if (file.size > 8 * 1024 * 1024) {
      setImageError('ছবির আকার সর্বোচ্চ ৮ মেগাবাইট হতে পারবে।');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setPreviewImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!donorName.trim() || !userFeedback.trim()) return;

    const finalPhoto = previewImage || '/src/assets/images/faridpur_donor_one_1791368372885.jpg';

    onSubmit({
      donorName: donorName.trim(),
      bloodGroup,
      district,
      upazila,
      hospitalName: hospitalName.trim(),
      donationDate,
      photoUrl: finalPhoto,
      userFeedback: userFeedback.trim(),
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-neutral-200 my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100">
          <div className="flex items-center gap-2">
            <span className="w-9 h-9 rounded-xl bg-red-100 text-red-600 flex items-center justify-center">
              <Camera className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-neutral-900">রক্তদানের ছবি ও মন্তব্য যোগ করুন</h2>
              <p className="text-xs text-neutral-500">
                আপনার রক্তদানের ছবি আপলোড করুন, এটি হোমপেজের টপ স্লাইডারে প্রদর্শিত হবে
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-4 text-xs">
          
          {/* Photo Upload Zone */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              রক্তদানের ছবি আপলোড করুন *
            </label>
            <div className="mt-1 flex justify-center px-4 pt-4 pb-4 border-2 border-dashed border-neutral-300 hover:border-red-400 rounded-xl bg-neutral-50/70 transition-colors">
              {previewImage ? (
                <div className="relative w-full max-h-52 rounded-lg overflow-hidden group">
                  <img
                    src={previewImage}
                    alt="Preview"
                    className="w-full h-48 object-cover rounded-lg"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <label className="px-3 py-1.5 bg-white text-neutral-900 rounded-lg text-xs font-semibold cursor-pointer shadow-md">
                      ছবি পরিবর্তন করুন
                      <input
                        type="file"
                        accept="image/*"
                        className="sr-only"
                        onChange={handleFileChange}
                      />
                    </label>
                  </div>
                </div>
              ) : (
                <div className="space-y-2 text-center py-3">
                  <div className="mx-auto w-12 h-12 rounded-full bg-red-50 text-red-600 flex items-center justify-center">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div className="text-xs text-neutral-600">
                    <label className="relative cursor-pointer bg-white rounded-md font-semibold text-red-600 hover:text-red-700 focus-within:outline-none">
                      <span>ক্যামেরা দিয়ে তুলুন অথবা গ্যালারি থেকে সিলেক্ট করুন</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="sr-only"
                        onChange={handleFileChange}
                      />
                    </label>
                  </div>
                  <p className="text-[11px] text-neutral-400">
                    PNG, JPG, JPEG (সর্বোচ্চ ৮ মেগাবাইট)
                  </p>
                </div>
              )}
            </div>
            {imageError && (
              <p className="text-[11px] text-red-600 mt-1">{imageError}</p>
            )}
          </div>

          {/* Name & Blood Group */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block font-semibold text-neutral-700 mb-1">
                রক্তদাতার নাম *
              </label>
              <input
                type="text"
                required
                placeholder="যেমন: সিয়াম উবাইদুল্লাহ"
                value={donorName}
                onChange={(e) => setDonorName(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                রক্তের গ্রুপ *
              </label>
              <select
                value={bloodGroup}
                onChange={(e) => setBloodGroup(e.target.value as BloodGroup)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none font-mono font-bold text-red-600 bg-white"
              >
                {BLOOD_GROUPS.map((grp) => (
                  <option key={grp} value={grp}>
                    {grp}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* District & Upazila */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                জেলা *
              </label>
              <select
                value={district}
                onChange={(e) => handleDistrictChange(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none bg-white font-medium"
              >
                {ALLOWED_DISTRICTS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                উপজেলা *
              </label>
              <select
                value={upazila}
                onChange={(e) => setUpazila(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none bg-white font-medium"
              >
                {currentUpazilas.map((u) => (
                  <option key={u} value={u}>
                    {u}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Hospital & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                হাসপাতাল বা রক্তদান কেন্দ্র *
              </label>
              <input
                type="text"
                required
                placeholder="যেমন: ফরিদপুর মেডিকেল কলেজ হাসপাতাল"
                value={hospitalName}
                onChange={(e) => setHospitalName(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                রক্তদানের তারিখ *
              </label>
              <input
                type="date"
                required
                value={donationDate}
                onChange={(e) => setDonationDate(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Donor Feedback & Comment */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              আপনার অনুভূতি ও মন্তব্য (Feedback & Quote) *
            </label>
            <textarea
              rows={3}
              required
              placeholder="রক্ত দেওয়ার পর আপনার কেমন লাগলো? অন্য রক্তদাতাদের উদ্দেশ্যে আপনার বার্তা কি?"
              value={userFeedback}
              onChange={(e) => setUserFeedback(e.target.value)}
              className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none resize-none"
            />
          </div>

          {/* Buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 font-semibold text-neutral-600 hover:bg-neutral-100 rounded-lg cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2.5 font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Camera className="w-4 h-4" />
              <span>ছবি ও মন্তব্য পোস্ট করুন</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
