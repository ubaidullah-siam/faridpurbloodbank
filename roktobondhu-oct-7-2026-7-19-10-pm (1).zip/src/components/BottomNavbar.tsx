import React, { useState, useRef, useEffect } from 'react';
import { NavTab } from './Navbar';
import {
  Home,
  Users,
  Search,
  User,
  MoreHorizontal,
  X,
  AlertTriangle,
  Clock,
  Camera,
  BookOpen,
  ShieldAlert,
  ShieldCheck,
  Lock,
  PlusCircle,
  UserPlus,
} from 'lucide-react';

interface BottomNavbarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  onOpenSearch: () => void;
  onOpenPrivacyPolicy: () => void;
  onOpenComplaintBox: () => void;
  onOpenAddRequest: () => void;
  onOpenUploadStory: () => void;
  onOpenRegisterDonor: () => void;
}

export const BottomNavbar: React.FC<BottomNavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenSearch,
  onOpenPrivacyPolicy,
  onOpenComplaintBox,
  onOpenAddRequest,
  onOpenUploadStory,
  onOpenRegisterDonor,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menu on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    if (isMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMenuOpen]);

  const handleNavigate = (tab: NavTab) => {
    setActiveTab(tab);
    setIsMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      {/* Three-dots popup menu (opens upwards above the bottom bar) */}
      {isMenuOpen && (
        <div
          ref={menuRef}
          className="fixed bottom-18 right-2 sm:right-6 w-76 max-w-[calc(100vw-1rem)] bg-white rounded-3xl shadow-2xl border border-neutral-200 p-2.5 z-50 animate-in fade-in slide-in-from-bottom-3 duration-200"
        >
          <div className="p-2 border-b border-neutral-100 flex items-center justify-between">
            <span className="text-xs font-bold text-neutral-500 uppercase tracking-wider">
              অন্যান্য পেজ ও নিয়ন্ত্রণ
            </span>
            <button
              onClick={() => setIsMenuOpen(false)}
              className="p-1 text-neutral-400 hover:text-neutral-700 rounded-md cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-1 pt-1.5 max-h-[60vh] overflow-y-auto">
            {/* Blood Requests */}
            <button
              onClick={() => handleNavigate('requests')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-xl transition-colors cursor-pointer text-left ${
                activeTab === 'requests' ? 'bg-red-50 text-red-700' : 'text-neutral-700 hover:bg-neutral-50'
              }`}
            >
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <div>
                <p className="font-semibold">জরুরি রক্তের আবেদন</p>
                <p className="text-[10px] text-neutral-400 font-normal">লাইভ রক্তের প্রয়োজন ও সংকট</p>
              </div>
            </button>

            {/* 4-Month Cycle Tracker */}
            <button
              onClick={() => handleNavigate('tracker')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-xl transition-colors cursor-pointer text-left ${
                activeTab === 'tracker' ? 'bg-red-50 text-red-700' : 'text-neutral-700 hover:bg-neutral-50'
              }`}
            >
              <Clock className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <p className="font-semibold">৪-মাস চক্র ও ক্যালেন্ডার</p>
                <p className="text-[10px] text-neutral-400 font-normal">রক্তদান সাইকেল ও সম্ভাব্য তারিখ</p>
              </div>
            </button>

            {/* Community Stories */}
            <button
              onClick={() => handleNavigate('stories')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-xl transition-colors cursor-pointer text-left ${
                activeTab === 'stories' ? 'bg-red-50 text-red-700' : 'text-neutral-700 hover:bg-neutral-50'
              }`}
            >
              <Camera className="w-4 h-4 text-purple-600 shrink-0" />
              <div>
                <p className="font-semibold">রক্তদানের ছবি ও মন্তব্য ওয়াল</p>
                <p className="text-[10px] text-neutral-400 font-normal">ডোনারদের গ্যালারি ও কমেন্ট</p>
              </div>
            </button>

            {/* Privacy Policy (User requirement) */}
            <button
              onClick={() => {
                setIsMenuOpen(false);
                onOpenPrivacyPolicy();
              }}
              className="w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-xl transition-colors cursor-pointer text-left text-neutral-800 hover:bg-neutral-50"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <p className="font-semibold">রক্তদান নীতিমালা ও শর্তাবলী</p>
                <p className="text-[10px] text-neutral-400 font-normal">১৮ বছরের নিচে রক্তদান নিষেধ ও স্বাস্থ্যবিধি</p>
              </div>
            </button>

            {/* Blood Guidelines */}
            <button
              onClick={() => handleNavigate('guidelines')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-xl transition-colors cursor-pointer text-left ${
                activeTab === 'guidelines' ? 'bg-red-50 text-red-700' : 'text-neutral-700 hover:bg-neutral-50'
              }`}
            >
              <BookOpen className="w-4 h-4 text-blue-600 shrink-0" />
              <div>
                <p className="font-semibold">রক্তদানের নির্দেশিকা ও চার্ট</p>
                <p className="text-[10px] text-neutral-400 font-normal">রক্তের গ্রুপ ম্যাচিং সারণী</p>
              </div>
            </button>

            {/* Direct Complaint to App Owner */}
            <button
              onClick={() => {
                setIsMenuOpen(false);
                onOpenComplaintBox();
              }}
              className="w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-xl transition-colors cursor-pointer text-left text-red-700 hover:bg-red-50 bg-red-50/50"
            >
              <ShieldAlert className="w-4 h-4 text-red-600 shrink-0" />
              <div>
                <p className="font-bold">মালিকের কাছে সরাসরি অভিযোগ</p>
                <p className="text-[10px] text-red-500 font-normal">ভুয়া নম্বর বা অনুপস্থিতির রিপোর্ট</p>
              </div>
            </button>

            {/* Admin Panel */}
            <button
              onClick={() => handleNavigate('admin')}
              className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-xl transition-colors cursor-pointer text-left ${
                activeTab === 'admin' ? 'bg-neutral-900 text-white' : 'text-neutral-800 hover:bg-neutral-100'
              }`}
            >
              <Lock className="w-4 h-4 text-amber-500 shrink-0" />
              <div>
                <p className="font-bold">অ্যাডমিন কন্ট্রোল প্যানেল</p>
                <p className="text-[10px] opacity-70 font-normal">আইডি নিয়ন্ত্রণ ও অভিযোগ সেল</p>
              </div>
            </button>
          </div>
        </div>
      )}

      {/* FIXED BOTTOM NAVIGATION BAR */}
      <nav
        aria-label="Bottom Navigation"
        className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-neutral-200 shadow-lg px-2 sm:px-6 h-16 flex items-center justify-around"
      >
        {/* 1. HOME BUTTON */}
        <button
          type="button"
          onClick={() => handleNavigate('home')}
          className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-colors ${
            activeTab === 'home'
              ? 'text-red-600 font-bold'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[11px] mt-0.5">হোম</span>
        </button>

        {/* 2. ALL LISTS / DIRECTORY BUTTON */}
        <button
          type="button"
          onClick={() => handleNavigate('directory')}
          className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-colors ${
            activeTab === 'directory'
              ? 'text-red-600 font-bold'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          <Users className="w-5 h-5" />
          <span className="text-[11px] mt-0.5">সকল তালিকা</span>
        </button>

        {/* 3. CENTER SEARCH BUTTON (উজ্জ্বল লাল / বিশেষ অ্যাকশন) */}
        <div className="flex-1 flex justify-center -mt-5">
          <button
            type="button"
            onClick={onOpenSearch}
            className="w-13 h-13 rounded-full bg-gradient-to-tr from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white flex flex-col items-center justify-center shadow-lg hover:shadow-red-500/30 transition-all cursor-pointer transform hover:scale-105 active:scale-95 border-2 border-white"
            title="দ্রুত রক্তদাতা সার্চ করুন"
          >
            <Search className="w-5 h-5" />
            <span className="text-[9px] font-bold mt-0.5">সার্চ</span>
          </button>
        </div>

        {/* 4. PROFILE BUTTON */}
        <button
          type="button"
          onClick={() => handleNavigate('profile')}
          className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-colors ${
            activeTab === 'profile'
              ? 'text-red-600 font-bold'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[11px] mt-0.5">প্রোফাইল</span>
        </button>

        {/* 5. THREE-DOTS (•••) MORE MENU BUTTON */}
        <button
          type="button"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-colors ${
            isMenuOpen || ['requests', 'tracker', 'stories', 'guidelines', 'admin'].includes(activeTab)
              ? 'text-red-600 font-bold'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          <MoreHorizontal className="w-5 h-5" />
          <span className="text-[11px] mt-0.5">মেনু</span>
        </button>
      </nav>
    </>
  );
};
