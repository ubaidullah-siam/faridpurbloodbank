import React from 'react';
import { Donor, BloodBooking } from '../types';
import { calculateEligibility, toBengaliNumber } from '../utils/bloodLogic';
import {
  Phone,
  MessageSquare,
  MapPin,
  Calendar,
  CheckCircle2,
  Clock,
  CalendarCheck,
  Lock,
  PhoneOff,
  AlertCircle,
  MessageCircle,
} from 'lucide-react';

interface DonorCardProps {
  donor: Donor;
  booking?: BloodBooking | null;
  onSelectDonor?: (donor: Donor) => void;
  onBookDonor?: (donor: Donor) => void;
  onStartChat?: (donor: Donor) => void;
}

export const DonorCard: React.FC<DonorCardProps> = ({
  donor,
  booking,
  onSelectDonor,
  onBookDonor,
  onStartChat,
}) => {
  const eligibility = calculateEligibility(donor.lastDonationDate);
  const isBooked = !!booking && booking.status === 'booked';
  
  // Call disable condition as requested by user:
  // "তাহলে তাকে কল করার অপশন বন্ধ হয়ে যাবে আর কেউ যদি বুক হয়ে যায় সেটাও তার কল করার অপশনও বন্ধ হয়ে যাবে"
  const isCallDisabled = isBooked || !donor.isAvailable;

  // Unavailability reason text
  const unavailText = !donor.isAvailable
    ? donor.unavailability?.label || 'অসুস্থ / জেলার বাইরে'
    : isBooked
    ? 'রক্তদান বুকড'
    : '';

  // Days difference for booking
  const daysDiff = booking
    ? Math.ceil((new Date(booking.scheduledDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
    : 0;

  return (
    <div className={`bg-white rounded-2xl border transition-all p-5 shadow-xs flex flex-col justify-between ${
      isBooked
        ? 'border-amber-300 bg-amber-50/20'
        : !donor.isAvailable
        ? 'border-neutral-200 bg-neutral-50/60'
        : 'border-neutral-200 hover:border-neutral-300'
    }`}>
      <div>
        {/* Top bar: Blood group and Status */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-3">
            {donor.profilePicture ? (
              <img
                src={donor.profilePicture}
                alt={donor.name}
                className="w-13 h-13 rounded-xl object-cover border border-neutral-200 shadow-xs shrink-0"
              />
            ) : (
              <span className="w-13 h-13 rounded-xl bg-red-600 text-white font-extrabold text-lg flex items-center justify-center font-mono shrink-0 shadow-xs">
                {donor.bloodGroup}
              </span>
            )}
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-bold text-neutral-900 text-base leading-snug">
                  {donor.name}
                </h3>
                <span className="font-mono font-bold text-xs text-red-600 bg-red-50 px-1.5 py-0.5 rounded border border-red-200">
                  {donor.bloodGroup}
                </span>
              </div>
              <p className="text-xs text-neutral-500 flex items-center gap-1 mt-0.5">
                <MapPin className="w-3 h-3 text-red-500 shrink-0" />
                <span className="font-medium text-neutral-700">{donor.upazila}, {donor.district}</span>
              </p>
            </div>
          </div>

          {/* Status Badge */}
          <div className="text-right shrink-0">
            {isBooked ? (
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-900 bg-amber-100 px-2 py-0.5 rounded border border-amber-300">
                <Lock className="w-3 h-3 text-amber-700" />
                বুকড
              </span>
            ) : !donor.isAvailable ? (
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-neutral-700 bg-neutral-200 px-2 py-0.5 rounded border border-neutral-300">
                <PhoneOff className="w-3 h-3 text-neutral-500" />
                কল বন্ধ
              </span>
            ) : eligibility.isEligible ? (
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                প্রস্তুত
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-neutral-700 bg-neutral-100 px-2 py-0.5 rounded">
                <Clock className="w-3 h-3 text-neutral-500" />
                {toBengaliNumber(eligibility.daysRemaining)} দিন বাকি
              </span>
            )}
          </div>
        </div>

        {/* PROMINENT BOOKING RIBBON */}
        {isBooked && (
          <div className="mb-3 p-2.5 bg-amber-100/90 rounded-lg border border-amber-300 text-xs text-amber-950 flex items-start gap-2 shadow-2xs">
            <CalendarCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">
                🔒 {booking.patientName}-এর জন্য আগামী {daysDiff <= 0 ? 'আজ' : daysDiff === 1 ? 'কালকে' : `${toBengaliNumber(daysDiff)} দিন পর`} ({booking.scheduledDate}) বুক হয়ে আছে!
              </p>
              <p className="text-[11px] text-amber-800 mt-0.5">
                হাসপাতাল: {booking.hospitalName} · কল অপশন বন্ধ রাখা হয়েছে
              </p>
            </div>
          </div>
        )}

        {/* UNAVAILABILITY RIBBON (User prompt requirement: অসুস্থ/জেলার বাইরে কল বন্ধ) */}
        {!donor.isAvailable && !isBooked && (
          <div className="mb-3 p-2.5 bg-neutral-100 rounded-lg border border-neutral-300 text-xs text-neutral-800 flex items-start gap-2 shadow-2xs">
            <PhoneOff className="w-4 h-4 text-neutral-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-neutral-900">
                🚫 বর্তমানে কল গ্রহণ বন্ধ ({unavailText})
              </p>
              {donor.unavailability?.customDetails && (
                <p className="text-[11px] text-neutral-600 mt-0.5">
                  "{donor.unavailability.customDetails}"
                </p>
              )}
            </div>
          </div>
        )}

        {/* Area */}
        <div className="text-xs text-neutral-600 pb-1">
          <span>এলাকা: <strong>{donor.area}</strong></span>
        </div>

        {/* Metadata */}
        <div className="flex items-center flex-wrap gap-x-2 text-xs text-neutral-500 py-2 border-y border-neutral-100 my-2">
          <span>{donor.gender}</span>
          <span aria-hidden="true">·</span>
          <span>বয়স: {toBengaliNumber(donor.age)} বছর</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono tabular-nums">{toBengaliNumber(donor.totalDonations)} বার রক্তদান</span>
        </div>

        {/* Last donation info */}
        <div className="text-xs text-neutral-600 flex items-center gap-1.5 py-1">
          <Calendar className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
          <span>
            শেষ রক্তদান: {donor.lastDonationDate ? (
              <strong className="text-neutral-800 font-medium">{donor.lastDonationDate}</strong>
            ) : (
              <span className="text-emerald-700 font-medium">কখনও রক্ত দেননি (প্রথমবার)</span>
            )}
          </span>
        </div>
      </div>

      {/* Action Buttons: Direct Call (Conditioned), Chat & Booking */}
      <div className="pt-4 mt-2 space-y-2">
        <div className="flex items-center gap-2">
          
          {/* CALL BUTTON - STRICTLY DISABLED IF BOOKED OR UNAVAILABLE */}
          {isCallDisabled ? (
            <div
              className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-neutral-400 bg-neutral-100 rounded-lg border border-neutral-200 cursor-not-allowed select-none"
              title="এই রক্তদাতা বর্তমানে কল গ্রহণ করতে পারছেন না"
            >
              <PhoneOff className="w-3.5 h-3.5 text-neutral-400" />
              <span>কল বন্ধ</span>
            </div>
          ) : (
            <a
              href={`tel:${donor.phone}`}
              className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-neutral-800 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors cursor-pointer"
            >
              <Phone className="w-3.5 h-3.5 text-neutral-600" />
              <span>কল করুন</span>
            </a>
          )}

          {/* IN-APP LIVE CHAT BUTTON */}
          {onStartChat && (
            <button
              type="button"
              onClick={() => onStartChat(donor)}
              className="inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 rounded-lg transition-colors cursor-pointer"
              title="অ্যাপের ভেতর সরাসরি চ্যাট করুন"
            >
              <MessageSquare className="w-3.5 h-3.5 text-red-600" />
              <span>চ্যাট</span>
            </button>
          )}

          {onSelectDonor && (
            <button
              type="button"
              onClick={() => onSelectDonor(donor)}
              className="py-2 px-2.5 text-xs font-medium text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg transition-colors cursor-pointer"
              title="বিস্তারিত দেখুন"
            >
              বিস্তারিত
            </button>
          )}
        </div>

        {/* Booking Button for recipients */}
        {!isBooked && donor.isAvailable && onBookDonor && eligibility.isEligible && (
          <button
            type="button"
            onClick={() => onBookDonor(donor)}
            className="w-full py-2 px-3 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
          >
            <CalendarCheck className="w-3.5 h-3.5" />
            <span>অগ্রিম রক্তদান বুক করুন (৭ দিন বা কালকের জন্য)</span>
          </button>
        )}
      </div>
    </div>
  );
};
