import React, { useState } from 'react';
import { Donor, BloodBooking } from '../types';
import { X, Calendar, Clock, User, Phone, MapPin, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface BookDonorModalProps {
  isOpen: boolean;
  onClose: () => void;
  donor: Donor | null;
  onConfirmBooking: (bookingData: Omit<BloodBooking, 'id' | 'createdAt' | 'daysRemainingForDonation' | 'status'>) => void;
}

export const BookDonorModal: React.FC<BookDonorModalProps> = ({
  isOpen,
  onClose,
  donor,
  onConfirmBooking,
}) => {
  // Default to 7 days from now as requested in user prompt ("সাতদিন পরে রক্ত লাগবে তখন ধরে যে বুক করে রাখল")
  const defaultSevenDays = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  const [recipientName, setRecipientName] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [patientName, setPatientName] = useState('');
  const [hospitalName, setHospitalName] = useState(donor ? `${donor.upazila} উপজেলা স্বাস্থ্য কমপ্লেক্স` : 'ফরিদপুর মেডিকেল কলেজ হাসপাতাল');
  const [scheduledDate, setScheduledDate] = useState(defaultSevenDays);
  const [notes, setNotes] = useState('');

  if (!isOpen || !donor) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipientName.trim() || !recipientPhone.trim() || !patientName.trim()) return;

    onConfirmBooking({
      donorId: donor.id,
      donorName: donor.name,
      donorPhone: donor.phone,
      bloodGroup: donor.bloodGroup,
      recipientId: `rec-${Date.now()}`,
      recipientName: recipientName.trim(),
      recipientPhone: recipientPhone.trim(),
      patientName: patientName.trim(),
      hospitalName: hospitalName.trim(),
      district: donor.district,
      upazila: donor.upazila,
      scheduledDate,
      consentGivenByDonor: true,
      notes: notes.trim(),
    });

    onClose();
  };

  // Calculate day difference for friendly label
  const diffDays = Math.ceil(
    (new Date(scheduledDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-neutral-200 my-8">
        
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-neutral-100">
          <div className="flex items-center gap-3">
            <span className="w-12 h-12 rounded-xl bg-red-600 text-white font-extrabold text-xl flex items-center justify-center font-mono shadow-xs shrink-0">
              {donor.bloodGroup}
            </span>
            <div>
              <h2 className="text-lg font-bold text-neutral-900">রক্তদাতা অগ্রিম বুকিং করুন</h2>
              <p className="text-xs text-neutral-500">
                ডোনারের সাথে কথা বলে রক্তদানের তারিখ নির্ধারণ ও নিশ্চিত করুন
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Selected Donor Info Bar */}
        <div className="my-3 p-3 bg-neutral-50 rounded-xl border border-neutral-200 flex items-center justify-between text-xs">
          <div>
            <span className="font-bold text-neutral-900 text-sm">{donor.name}</span>
            <p className="text-neutral-500 flex items-center gap-1 mt-0.5">
              <MapPin className="w-3.5 h-3.5 text-red-500" />
              <span>{donor.upazila}, {donor.district}</span>
            </p>
          </div>
          <div className="text-right">
            <span className="font-mono font-bold text-neutral-800">{donor.phone}</span>
            <span className="block text-[11px] text-emerald-700 font-semibold">রক্তদানে প্রস্তুত</span>
          </div>
        </div>

        {/* Booking Form */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-1 text-xs">
          
          {/* Scheduled Date */}
          <div className="p-3 bg-red-50/50 rounded-xl border border-red-200 space-y-1">
            <label className="block font-bold text-red-900 mb-1">
              রক্তদানের নির্দিষ্ট তারিখ (Scheduled Date) *
            </label>
            <div className="flex items-center gap-2">
              <input
                type="date"
                required
                min={new Date().toISOString().split('T')[0]}
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none bg-white font-medium"
              />
              <div className="px-3 py-2 bg-white rounded-lg border border-neutral-200 shrink-0 font-semibold text-neutral-700 text-xs">
                {diffDays <= 0 ? 'আজ' : diffDays === 1 ? 'কালকে' : `${diffDays} দিন পর`}
              </div>
            </div>
            <p className="text-[11px] text-neutral-500 mt-1">
              বুক করার পর ডোনারের আইডিতে লেখা থাকবে: "অমুকের জন্য আগামী {diffDays} দিন পর বুক হয়ে আছে"।
            </p>
          </div>

          {/* Recipient Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                আপনার নাম (গ্রহীতা/স্বজন) *
              </label>
              <input
                type="text"
                required
                placeholder="যেমন: ফারুক আহমেদ"
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                আপনার মোবাইল নম্বর *
              </label>
              <input
                type="tel"
                required
                placeholder="01XXXXXXXXX"
                value={recipientPhone}
                onChange={(e) => setRecipientPhone(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none font-mono"
              />
            </div>
          </div>

          {/* Patient Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                রোগীর নাম *
              </label>
              <input
                type="text"
                required
                placeholder="যেমন: সুমাইয়া আক্তার"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                হাসপাতালের নাম *
              </label>
              <input
                type="text"
                required
                placeholder="যেমন: ভাঙ্গা উপজেলা স্বাস্থ্য কমপ্লেক্স"
                value={hospitalName}
                onChange={(e) => setHospitalName(e.target.value)}
                className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Special Notes */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              জরুরি নির্দেশনা বা নোট (ঐচ্ছিক)
            </label>
            <textarea
              rows={2}
              placeholder="যেমন: ডোনারের সাথে ফোনে কথা বলে সময় চূড়ান্ত করা হয়েছে, সিজার অপারেশনের রোগী..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full text-sm border border-neutral-300 rounded-lg p-2.5 focus:border-red-500 focus:outline-none resize-none"
            />
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 font-semibold text-neutral-600 hover:bg-neutral-100 rounded-lg cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2.5 font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>বুকিং নিশ্চিত করুন</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
