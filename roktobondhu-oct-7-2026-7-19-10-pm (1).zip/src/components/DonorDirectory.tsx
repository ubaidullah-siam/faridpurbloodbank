import React, { useState, useMemo } from 'react';
import { Donor, BloodGroup, BloodBooking } from '../types';
import { BLOOD_GROUPS, ALLOWED_DISTRICTS, getUpazilasForDistrict } from '../data/bangladeshDistricts';
import { calculateEligibility, toBengaliNumber } from '../utils/bloodLogic';
import { DonorCard } from './DonorCard';
import { Search, Filter, UserPlus, CheckCircle2, Lock } from 'lucide-react';

interface DonorDirectoryProps {
  donors: Donor[];
  bookings: BloodBooking[];
  selectedGroup: BloodGroup | 'ALL';
  setSelectedGroup: (group: BloodGroup | 'ALL') => void;
  selectedDistrict: string;
  setSelectedDistrict: (district: string) => void;
  selectedUpazila: string;
  setSelectedUpazila: (upazila: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onOpenRegisterModal: () => void;
  onSelectDonorDetail: (donor: Donor) => void;
  onBookDonor: (donor: Donor) => void;
}

export const DonorDirectory: React.FC<DonorDirectoryProps> = ({
  donors,
  bookings,
  selectedGroup,
  setSelectedGroup,
  selectedDistrict,
  setSelectedDistrict,
  selectedUpazila,
  setSelectedUpazila,
  searchQuery,
  setSearchQuery,
  onOpenRegisterModal,
  onSelectDonorDetail,
  onBookDonor,
}) => {
  const [onlyReady, setOnlyReady] = useState<boolean>(false);
  const [onlyAvailableUnbooked, setOnlyAvailableUnbooked] = useState<boolean>(false);

  const currentUpazilas = selectedDistrict === 'ALL' ? [] : getUpazilasForDistrict(selectedDistrict);

  // Filtered donor list
  const filteredDonors = useMemo(() => {
    return donors.filter((donor) => {
      if (donor.isBlocked) return false;

      // Blood Group filter
      if (selectedGroup !== 'ALL' && donor.bloodGroup !== selectedGroup) {
        return false;
      }

      // District filter
      if (selectedDistrict !== 'ALL' && donor.district !== selectedDistrict) {
        return false;
      }

      // Upazila filter
      if (selectedUpazila !== 'ALL' && donor.upazila !== selectedUpazila) {
        return false;
      }

      // Ready filter
      if (onlyReady) {
        const elig = calculateEligibility(donor.lastDonationDate);
        if (!elig.isEligible || !donor.isAvailable) return false;
      }

      // Unbooked only filter
      if (onlyAvailableUnbooked) {
        const hasBooking = bookings.some((b) => b.donorId === donor.id && b.status === 'booked');
        if (hasBooking) return false;
      }

      // Search query filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchesName = donor.name.toLowerCase().includes(query);
        const matchesArea = donor.area.toLowerCase().includes(query);
        const matchesUpazila = donor.upazila.toLowerCase().includes(query);
        const matchesDistrict = donor.district.toLowerCase().includes(query);
        const matchesPhone = donor.phone.includes(query);
        const matchesGroup = donor.bloodGroup.toLowerCase() === query;
        if (!matchesName && !matchesArea && !matchesUpazila && !matchesDistrict && !matchesPhone && !matchesGroup) {
          return false;
        }
      }

      return true;
    });
  }, [donors, bookings, selectedGroup, selectedDistrict, selectedUpazila, onlyReady, onlyAvailableUnbooked, searchQuery]);

  return (
    <div className="space-y-6">
      
      {/* Top Controls & Segmented Filters */}
      <div className="bg-white border border-neutral-200 rounded-2xl p-5 shadow-xs space-y-4">
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-neutral-900 tracking-tight">
              রক্তদাতা তালিকা ও বুকিং ডিরেক্টরি
            </h2>
            <p className="text-xs text-neutral-500 mt-0.5">
              ফরিদপুর, মাদারীপুর, গোপালগঞ্জ, রাজবাড়ী ও মাগুরা জেলার মোট {toBengaliNumber(filteredDonors.length)} জন রক্তদাতা
            </p>
          </div>

          <button
            type="button"
            onClick={onOpenRegisterModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs transition-colors cursor-pointer shrink-0"
          >
            <UserPlus className="w-4 h-4" />
            <span>নতুন রক্তদাতা হিসেবে যোগ দিন</span>
          </button>
        </div>

        {/* Blood Group Segmented Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-1 no-scrollbar">
          <button
            type="button"
            onClick={() => setSelectedGroup('ALL')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer shrink-0 ${
              selectedGroup === 'ALL'
                ? 'bg-neutral-900 text-white'
                : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200 hover:text-neutral-900'
            }`}
          >
            সকল গ্রুপ ({toBengaliNumber(donors.length)})
          </button>

          {BLOOD_GROUPS.map((group) => {
            const count = donors.filter((d) => d.bloodGroup === group).length;
            const isSelected = selectedGroup === group;
            return (
              <button
                key={group}
                type="button"
                onClick={() => setSelectedGroup(group)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer shrink-0 font-mono ${
                  isSelected
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-red-50 hover:text-red-700'
                }`}
              >
                {group} <span className="text-[10px] font-normal opacity-80">({toBengaliNumber(count)})</span>
              </button>
            );
          })}
        </div>

        {/* Secondary Filter Line: District, Upazila & Booked Status Toggle */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-2 border-t border-neutral-100 items-center">
          
          <div className="sm:col-span-4 flex items-center gap-2">
            <select
              value={selectedDistrict}
              onChange={(e) => {
                setSelectedDistrict(e.target.value);
                setSelectedUpazila('ALL');
              }}
              className="w-1/2 p-2 text-xs bg-neutral-50 border border-neutral-200 rounded-lg focus:outline-none focus:border-red-500 font-medium"
            >
              <option value="ALL">সকল জেলা (৫ জেলা)</option>
              {ALLOWED_DISTRICTS.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>

            <select
              disabled={selectedDistrict === 'ALL'}
              value={selectedUpazila}
              onChange={(e) => setSelectedUpazila(e.target.value)}
              className="w-1/2 p-2 text-xs bg-neutral-50 border border-neutral-200 rounded-lg focus:outline-none focus:border-red-500 disabled:opacity-50"
            >
              <option value="ALL">সকল উপজেলা</option>
              {currentUpazilas.map((u) => (
                <option key={u} value={u}>
                  {u}
                </option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-5 flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setOnlyReady(!onlyReady)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                onlyReady
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300 font-semibold'
                  : 'bg-white text-neutral-600 border-neutral-200 hover:border-neutral-300'
              }`}
            >
              <CheckCircle2 className={`w-3.5 h-3.5 ${onlyReady ? 'text-emerald-600' : 'text-neutral-400'}`} />
              <span>শুধু প্রস্তুত ডোনার</span>
            </button>

            <button
              type="button"
              onClick={() => setOnlyAvailableUnbooked(!onlyAvailableUnbooked)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                onlyAvailableUnbooked
                  ? 'bg-amber-50 text-amber-900 border-amber-300 font-semibold'
                  : 'bg-white text-neutral-600 border-neutral-200 hover:border-neutral-300'
              }`}
            >
              <Lock className={`w-3.5 h-3.5 ${onlyAvailableUnbooked ? 'text-amber-700' : 'text-neutral-400'}`} />
              <span>বুকিং ছাড়া ফাঁকা</span>
            </button>

            {(selectedGroup !== 'ALL' || selectedDistrict !== 'ALL' || selectedUpazila !== 'ALL' || onlyReady || onlyAvailableUnbooked || searchQuery) && (
              <button
                type="button"
                onClick={() => {
                  setSelectedGroup('ALL');
                  setSelectedDistrict('ALL');
                  setSelectedUpazila('ALL');
                  setOnlyReady(false);
                  setOnlyAvailableUnbooked(false);
                  setSearchQuery('');
                }}
                className="text-xs text-neutral-500 hover:text-red-600 underline cursor-pointer px-1 shrink-0"
              >
                রিসেট
              </button>
            )}
          </div>

          {/* Quick search input */}
          <div className="sm:col-span-3 relative">
            <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="নাম বা ফোন দিয়ে ফিল্টার..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-neutral-50 border border-neutral-200 rounded-lg focus:outline-none focus:border-red-500"
            />
          </div>

        </div>

      </div>

      {/* Donors Grid */}
      {filteredDonors.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredDonors.map((donor) => {
            const booking = bookings.find((b) => b.donorId === donor.id && b.status === 'booked');

            return (
              <DonorCard
                key={donor.id}
                donor={donor}
                booking={booking}
                onSelectDonor={onSelectDonorDetail}
                onBookDonor={onBookDonor}
              />
            );
          })}
        </div>
      ) : (
        <div className="bg-white border border-neutral-200 rounded-2xl p-12 text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-red-50 text-red-600 flex items-center justify-center mx-auto">
            <Filter className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-neutral-900">
            এই ফিল্টারে কোনো রক্তদাতা পাওয়া যায়নি
          </h3>
          <p className="text-xs text-neutral-500 max-w-sm mx-auto">
            জেলা বা উপজেলার ফিল্টার পরিবর্তন করুন, অথবা এই এলাকায় রক্তদাতা হিসেবে আপনি নিজে নাম লেখান।
          </p>
          <button
            type="button"
            onClick={onOpenRegisterModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>নতুন রক্তদাতা যুক্ত করুন</span>
          </button>
        </div>
      )}

    </div>
  );
};
