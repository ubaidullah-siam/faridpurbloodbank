import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  BloodGroup,
  BloodRequest,
  Donor,
  AppNotification,
  DonationStory,
  BloodBooking,
  RecipientProfile,
  Complaint,
} from './types';
import {
  loadDonors,
  saveDonors,
  loadRequests,
  saveRequests,
  loadNotifications,
  saveNotifications,
  loadStories,
  saveStories,
  loadBookings,
  saveBookings,
  loadRecipients,
  saveRecipients,
  loadComplaints,
  saveComplaints,
  checkEligibilityNotification,
  createBloodRequestNotification,
} from './utils/storage';
import { playNotificationChime } from './utils/bloodLogic';

import { Navbar, NavTab } from './components/Navbar';
import { HomePage } from './components/HomePage';
import { StatsBar } from './components/StatsBar';
import { DonorDirectory } from './components/DonorDirectory';
import { EligibilityTracker } from './components/EligibilityTracker';
import { BloodRequestList } from './components/BloodRequestList';
import { CommunityStories } from './components/CommunityStories';
import { BloodGuidelines } from './components/BloodGuidelines';
import { AdminPanel } from './components/AdminPanel';
import { MobileAppShell } from './components/MobileAppShell';
import { MyProfilePage } from './components/MyProfilePage';

import { AddRequestModal } from './components/AddRequestModal';
import { AddDonorModal } from './components/AddDonorModal';
import { UpdateProfileModal } from './components/UpdateProfileModal';
import { UploadStoryModal } from './components/UploadStoryModal';
import { DonorDetailModal } from './components/DonorDetailModal';
import { BookDonorModal } from './components/BookDonorModal';
import { ComplaintBoxModal } from './components/ComplaintBoxModal';
import { CongratulationCardModal } from './components/CongratulationCardModal';
import { NotificationDrawer } from './components/NotificationDrawer';
import { Toast } from './components/Toast';

import { Heart, Phone, ShieldCheck, Droplets, ArrowLeft, ShieldAlert } from 'lucide-react';

export default function App() {
  // Navigation & View Mode State
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [viewMode, setViewMode] = useState<'web' | 'mobile_app'>('web');

  // Core Data States
  const [donors, setDonors] = useState<Donor[]>([]);
  const [requests, setRequests] = useState<BloodRequest[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [stories, setStories] = useState<DonationStory[]>([]);
  const [bookings, setBookings] = useState<BloodBooking[]>([]);
  const [recipients, setRecipients] = useState<RecipientProfile[]>([]);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  
  // Search and Filter State
  const [selectedGroup, setSelectedGroup] = useState<BloodGroup | 'ALL'>('ALL');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('ALL');
  const [selectedUpazila, setSelectedUpazila] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals State
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isAddRequestOpen, setIsAddRequestOpen] = useState(false);
  const [isAddDonorOpen, setIsAddDonorOpen] = useState(false);
  const [isUpdateProfileOpen, setIsUpdateProfileOpen] = useState(false);
  const [isUploadStoryOpen, setIsUploadStoryOpen] = useState(false);
  const [isComplaintBoxOpen, setIsComplaintBoxOpen] = useState(false);
  const [isCongratulationCardOpen, setIsCongratulationCardOpen] = useState(false);
  const [congratulationDonor, setCongratulationDonor] = useState<Donor | null>(null);
  const [congratulationDate, setCongratulationDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [congratulationHospital, setCongratulationHospital] = useState<string>('ফরিদপুর মেডিকেল কলেজ হাসপাতাল');
  const [donorToBook, setDonorToBook] = useState<Donor | null>(null);
  const [selectedDonorDetail, setSelectedDonorDetail] = useState<Donor | null>(null);
  
  // Toast state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Load Initial Data on Mount
  useEffect(() => {
    const loadedDonors = loadDonors();
    const loadedRequests = loadRequests();
    const loadedNotifs = loadNotifications();
    const loadedStories = loadStories();
    const loadedBookings = loadBookings();
    const loadedRecipients = loadRecipients();
    const loadedComplaints = loadComplaints();

    setDonors(loadedDonors);
    setRequests(loadedRequests);
    setNotifications(loadedNotifs);
    setStories(loadedStories);
    setBookings(loadedBookings);
    setRecipients(loadedRecipients);
    setComplaints(loadedComplaints);

    // Check currentUser eligibility on boot
    const currentUser = loadedDonors.find((d) => d.isCurrentUser) || loadedDonors[0];
    if (currentUser) {
      const { updatedNotifications, newlyTriggered } = checkEligibilityNotification(
        currentUser,
        loadedNotifs
      );
      if (newlyTriggered) {
        setNotifications(updatedNotifications);
        setToastMessage('🎉 আপনার শেষ রক্তদানের ৪ মাস পূর্ণ হয়েছে! ফরিদপুর ব্লাড ব্যাংকে আপনি প্রস্তুত।');
      }
    }
  }, []);

  // Current logged in user
  const currentUser = useMemo(() => {
    return donors.find((d) => d.isCurrentUser) || donors[0] || null;
  }, [donors]);

  // Active booking for current user if any
  const currentUserBooking = useMemo(() => {
    if (!currentUser) return null;
    return bookings.find((b) => b.donorId === currentUser.id && b.status === 'booked') || null;
  }, [bookings, currentUser]);

  // Unread notifications count
  const unreadCount = useMemo(() => {
    return notifications.filter((n) => !n.read).length;
  }, [notifications]);

  // Toast feedback helper
  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
  }, []);

  // Update donor profile
  const handleUpdateDonor = useCallback((updatedDonor: Donor) => {
    setDonors((prev) => {
      const next = prev.map((d) => (d.id === updatedDonor.id ? updatedDonor : d));
      saveDonors(next);
      return next;
    });

    if (updatedDonor.isCurrentUser) {
      setNotifications((prevNotifs) => {
        const { updatedNotifications } = checkEligibilityNotification(updatedDonor, prevNotifs);
        return updatedNotifications;
      });
    }

    showToast('✅ আপনার তথ্য ও রক্তদানের তারিখ সফলভাবে আপডেট করা হয়েছে!');
  }, [showToast]);

  // Add new donor registration
  const handleAddDonor = useCallback((newDonorData: Omit<Donor, 'id' | 'createdAt' | 'history'>) => {
    const newDonor: Donor = {
      ...newDonorData,
      id: `donor-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
      history: newDonorData.lastDonationDate
        ? [
            {
              id: `hist-${Date.now()}`,
              date: newDonorData.lastDonationDate,
              hospitalOrPlace: `${newDonorData.upazila} স্বাস্থ্য কমপ্লেক্স`,
              bagsCount: 1,
            },
          ]
        : [],
    };

    setDonors((prev) => {
      const next = [newDonor, ...prev];
      saveDonors(next);
      return next;
    });

    showToast(`🎉 রক্তদাতা হিসেবে নিবন্ধিত হয়েছেন: ${newDonor.name} (${newDonor.bloodGroup}, ${newDonor.upazila})`);
  }, [showToast]);

  // Create new emergency blood request & broadcast notification
  const handleAddRequest = useCallback((reqData: Omit<BloodRequest, 'id' | 'createdAt' | 'status'>) => {
    const newReq: BloodRequest = {
      ...reqData,
      id: `req-${Date.now()}`,
      status: 'active',
      createdAt: new Date().toISOString(),
    };

    setRequests((prev) => {
      const next = [newReq, ...prev];
      saveRequests(next);
      return next;
    });

    if (currentUser) {
      const updatedNotifs = createBloodRequestNotification(newReq, currentUser, notifications);
      setNotifications(updatedNotifs);
    }

    showToast(`🚨 জরুরি রক্তের আবেদন সফলভাবে পোস্ট করা হয়েছে (${newReq.bloodGroup})!`);
  }, [currentUser, notifications, showToast]);

  // Update request status
  const handleUpdateRequestStatus = useCallback((requestId: string, status: 'active' | 'fulfilled' | 'closed') => {
    setRequests((prev) => {
      const next = prev.map((r) => (r.id === requestId ? { ...r, status } : r));
      saveRequests(next);
      return next;
    });
    showToast(status === 'fulfilled' ? ' রক্তদাতা নিশ্চিত হয়েছে হিসেবে চিহ্নিত করা হলো।' : 'আবেদনের স্ট্যাটাস পরিবর্তিত হয়েছে।');
  }, [showToast]);

  // BOOKING SYSTEM HANDLERS
  const handleConfirmBooking = useCallback((bookingData: Omit<BloodBooking, 'id' | 'createdAt' | 'daysRemainingForDonation' | 'status'>) => {
    const diffDays = Math.ceil(
      (new Date(bookingData.scheduledDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
    );

    const newBooking: BloodBooking = {
      ...bookingData,
      id: `book-${Date.now()}`,
      daysRemainingForDonation: Math.max(0, diffDays),
      status: 'booked',
      createdAt: new Date().toISOString(),
    };

    // Update bookings
    setBookings((prev) => {
      const next = [newBooking, ...prev];
      saveBookings(next);
      return next;
    });

    // Mark donor with activeBookingId
    setDonors((prev) => {
      const next = prev.map((d) => (d.id === bookingData.donorId ? { ...d, activeBookingId: newBooking.id } : d));
      saveDonors(next);
      return next;
    });

    // Alert notification for donor
    const bookingNotif: AppNotification = {
      id: `notif-book-${Date.now()}`,
      type: 'booking_reminder',
      title: `🔒 নতুন রক্তদান বুকিং: ${bookingData.patientName}`,
      message: `${bookingData.recipientName} আপনার সাথে কথা বলে আগামী ${bookingData.scheduledDate} তারিখে ${bookingData.hospitalName}-এ রক্তদানের জন্য বুক করেছেন।`,
      timestamp: 'এইমাত্র',
      read: false,
      relatedBookingId: newBooking.id,
    };

    playNotificationChime();
    setNotifications((prev) => {
      const next = [bookingNotif, ...prev];
      saveNotifications(next);
      return next;
    });

    showToast(`🔒 রক্তদাতা ${bookingData.donorName}-কে ${bookingData.scheduledDate}-এর জন্য বুক করা হয়েছে!`);
  }, [showToast]);

  // DONOR CONSENT TO BOOKING HANDLER (User requirement: বুক করার ক্ষেত্রে দাতা যদি সম্মতি দেয় তাহলে সেটা দেখাবে বুক)
  const handleConsentBooking = useCallback((bookingId: string, consent: boolean) => {
    const booking = bookings.find((b) => b.id === bookingId);
    if (!booking) return;

    if (consent) {
      const updatedBookings = bookings.map((b) =>
        b.id === bookingId
          ? { ...b, status: 'booked' as const, consentGivenByDonor: true }
          : b
      );
      setBookings(updatedBookings);
      saveBookings(updatedBookings);

      // Mark donor as booked and disable call
      setDonors((prev) => {
        const next = prev.map((d) => (d.id === booking.donorId ? { ...d, activeBookingId: bookingId } : d));
        saveDonors(next);
        return next;
      });

      const consentNotif: AppNotification = {
        id: `notif-consent-${Date.now()}`,
        type: 'booking_confirm',
        title: '🔒 রক্তদান বুকিং সম্মতি নিশ্চিত হয়েছে',
        message: `আপনি ${booking.scheduledDate} তারিখে ${booking.patientName}-এর জন্য রক্তদানের বুকিংয়ে সম্মতি দিয়েছেন। আপনার আইডিতে এখন '🔒 বুকড' প্রদর্শিত হচ্ছে এবং কল অপশন বন্ধ রয়েছে।`,
        timestamp: 'এইমাত্র',
        read: false,
      };
      playNotificationChime();
      setNotifications((prev) => [consentNotif, ...prev]);
      showToast('🎉 রক্তদানে সম্মতি দেওয়া হয়েছে! আইডিতে "🔒 বুকড" দেখাবে এবং কল অপশন স্থগিত থাকবে।');
    } else {
      const updatedBookings = bookings.map((b) =>
        b.id === bookingId
          ? { ...b, status: 'cancelled' as const, consentGivenByDonor: false }
          : b
      );
      setBookings(updatedBookings);
      saveBookings(updatedBookings);

      setDonors((prev) => {
        const next = prev.map((d) => (d.activeBookingId === bookingId ? { ...d, activeBookingId: null } : d));
        saveDonors(next);
        return next;
      });
      showToast('রক্তদান বুকিং বাতিল করা হয়েছে।');
    }
  }, [bookings, showToast]);

  // CONFIRM BLOOD DONATION DONE HANDLER
  const handleConfirmDonationDone = useCallback((bookingId: string) => {
    const booking = bookings.find((b) => b.id === bookingId);
    if (!booking) return;

    const todayStr = new Date().toISOString().split('T')[0];

    // Mark booking completed
    const updatedBookings = bookings.map((b) => (b.id === bookingId ? { ...b, status: 'completed' as const, completedAt: todayStr } : b));
    setBookings(updatedBookings);
    saveBookings(updatedBookings);

    // Update donor profile: set lastDonationDate to today, totalDonations + 1, clear activeBookingId
    let updatedDonorObj: Donor | null = null;
    setDonors((prev) => {
      const next = prev.map((d) => {
        if (d.id === booking.donorId) {
          const newRecord = {
            id: `hist-${Date.now()}`,
            date: todayStr,
            hospitalOrPlace: booking.hospitalName,
            patientNote: `${booking.patientName}-এর জন্য বুকিং রক্তদান সম্পন্ন`,
            bagsCount: 1,
          };
          const updated = {
            ...d,
            lastDonationDate: todayStr,
            totalDonations: d.totalDonations + 1,
            activeBookingId: null,
            history: [newRecord, ...(d.history || [])],
          };
          updatedDonorObj = updated;
          return updated;
        }
        return d;
      });
      saveDonors(next);
      return next;
    });

    // Celebratory notification + start 120-day rest timer
    const confirmNotif: AppNotification = {
      id: `notif-conf-${Date.now()}`,
      type: 'booking_confirm',
      title: '🩸 রক্তদান সম্পন্ন কনফার্ম হয়েছে!',
      message: `অভিনন্দন! আপনার রক্তদান সফলভাবে রেকর্ড করা হয়েছে। আপনার শরীর সুস্থ হতে ১২০ দিন (৪ মাস) সময় প্রয়োজন। ৪ মাস পূর্ণ হলেই পুনরায় প্রস্তুত নোটিফিকেশন পাবেন।`,
      timestamp: 'এইমাত্র',
      read: false,
    };

    playNotificationChime();
    setNotifications((prev) => {
      const next = [confirmNotif, ...prev];
      saveNotifications(next);
      return next;
    });

    // Open digital congratulations card for the donor (User requirement: অভিনন্দন কার্ড বানায় দিতে হবে)
    if (updatedDonorObj || currentUser) {
      setCongratulationDonor(updatedDonorObj || currentUser);
      setCongratulationDate(todayStr);
      setCongratulationHospital(booking.hospitalName);
      setIsCongratulationCardOpen(true);
    }

    showToast('🩸 রক্তদান সফল হয়েছে! ১২০ দিনের বিশ্রাম চক্র শুরু হয়েছে। অভিনন্দন কার্ড প্রস্তুত!');
  }, [bookings, currentUser, showToast]);

  // COMPLAINT BOX SUBMIT HANDLER
  const handleSubmitComplaint = useCallback((complaintData: Omit<Complaint, 'id' | 'status' | 'createdAt'>) => {
    const newComp: Complaint = {
      ...complaintData,
      id: `comp-${Date.now()}`,
      status: 'pending',
      createdAt: new Date().toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' }),
    };

    setComplaints((prev) => {
      const next = [newComp, ...prev];
      saveComplaints(next);
      return next;
    });

    // Notify admin
    const adminNotif: AppNotification = {
      id: `notif-comp-${Date.now()}`,
      type: 'system',
      title: '🚨 নতুন অভিযোগ জমা পড়েছে (মালিকের সেল)',
      message: `${complaintData.senderName} (${complaintData.category}) সংক্রান্ত অভিযোগ পাঠিয়েছেন। অ্যাডমিন প্যানেল দেখুন।`,
      timestamp: 'এইমাত্র',
      read: false,
    };

    playNotificationChime();
    setNotifications((prev) => [adminNotif, ...prev]);
    showToast('🛡️ আপনার অভিযোগটি সরাসরি অ্যাপের মালিকের কাছে জমা হয়েছে। ধন্যবাদ!');
  }, [showToast]);

  const handleResolveComplaint = useCallback((complaintId: string, adminNotes: string) => {
    setComplaints((prev) => {
      const next = prev.map((c) => (c.id === complaintId ? { ...c, status: 'resolved' as const, adminNotes } : c));
      saveComplaints(next);
      return next;
    });
    showToast('✅ অভিযোগটি নিষ্পত্তি করা হয়েছে।');
  }, [showToast]);

  // ADMIN DISCIPLINARY ACTIONS WITH REASONS
  const handleDeleteDonor = useCallback((donorId: string, reason: string) => {
    setDonors((prev) => {
      const next = prev.filter((d) => d.id !== donorId);
      saveDonors(next);
      return next;
    });
    showToast(`🗑️ ডোনার আইডি ডিলিট করা হয়েছে (কারণ: ${reason})`);
  }, [showToast]);

  const handleBlockDonor = useCallback((donorId: string, reason: string) => {
    setDonors((prev) => {
      const next = prev.map((d) => (d.id === donorId ? { ...d, isBlocked: true, blockReason: reason, isAvailable: false } : d));
      saveDonors(next);
      return next;
    });
    showToast(`🚫 ডোনার আইডি ব্লক করা হয়েছে (কারণ: ${reason})`);
  }, [showToast]);

  const handleDeleteRecipient = useCallback((recipientId: string, reason: string) => {
    setRecipients((prev) => {
      const next = prev.filter((r) => r.id !== recipientId);
      saveRecipients(next);
      return next;
    });
    showToast(`🗑️ গ্রহীতা আইডি ডিলিট করা হয়েছে (কারণ: ${reason})`);
  }, [showToast]);

  // Add a new photo donation story / feedback
  const handleAddStory = useCallback((storyData: Omit<DonationStory, 'id' | 'likesCount' | 'comments' | 'createdAt'>) => {
    const newStory: DonationStory = {
      ...storyData,
      id: `story-${Date.now()}`,
      likesCount: 1,
      comments: [],
      createdAt: new Date().toISOString(),
    };

    setStories((prev) => {
      const next = [newStory, ...prev];
      saveStories(next);
      return next;
    });

    // Create / open digital congratulation card for Facebook sharing
    if (currentUser) {
      setCongratulationDonor(currentUser);
      setCongratulationDate(storyData.donationDate || new Date().toISOString().split('T')[0]);
      setCongratulationHospital(storyData.hospitalName || 'ফরিদপুর মেডিকেল কলেজ হাসপাতাল');
      setIsCongratulationCardOpen(true);
    }

    playNotificationChime();
    showToast('📸 রক্তদানের ছবি যুক্ত হয়েছে! আপনার ডিজিটাল অভিনন্দন ও শুভেচ্ছা কার্ড প্রস্তুত।');
  }, [currentUser, showToast]);

  // Like a story
  const handleLikeStory = useCallback((storyId: string) => {
    setStories((prev) => {
      const next = prev.map((s) => (s.id === storyId ? { ...s, likesCount: s.likesCount + 1 } : s));
      saveStories(next);
      return next;
    });
  }, []);

  // Add comment to a story
  const handleAddStoryComment = useCallback((storyId: string, authorName: string, commentText: string) => {
    const newComment = {
      id: `c-${Date.now()}`,
      authorName,
      commentText,
      date: 'আজ',
    };

    setStories((prev) => {
      const next = prev.map((s) => {
        if (s.id === storyId) {
          return {
            ...s,
            comments: [...s.comments, newComment],
          };
        }
        return s;
      });
      saveStories(next);
      return next;
    });
  }, []);

  // Notification actions
  const handleMarkAllNotifsRead = useCallback(() => {
    setNotifications((prev) => {
      const next = prev.map((n) => ({ ...n, read: true }));
      saveNotifications(next);
      return next;
    });
    showToast('সব নোটিফিকেশন পঠিত হিসেবে চিহ্নিত করা হয়েছে।');
  }, [showToast]);

  const handleClearAllNotifs = useCallback(() => {
    setNotifications([]);
    saveNotifications([]);
    showToast('সব নোটিফিকেশন মুছে ফেলা হয়েছে।');
  }, [showToast]);

  const handleNotificationClick = useCallback((notif: AppNotification) => {
    setNotifications((prev) => {
      const next = prev.map((n) => (n.id === notif.id ? { ...n, read: true } : n));
      saveNotifications(next);
      return next;
    });

    if (notif.type === 'eligibility_ready' || notif.type === 'booking_reminder' || notif.type === 'booking_confirm') {
      setActiveTab('tracker');
      setIsNotificationsOpen(false);
    } else if (notif.type === 'blood_request') {
      setActiveTab('requests');
      setIsNotificationsOpen(false);
    }
  }, []);

  const handleTriggerTestNotif = useCallback(() => {
    const testNotif: AppNotification = {
      id: `test-notif-${Date.now()}`,
      type: 'booking_reminder',
      title: '📅 আগামীকালের রক্তদান রিমাইন্ডার (টেস্ট)',
      message: 'আগামীকাল সকাল ১০টায় ভাঙ্গা উপজেলা স্বাস্থ্য কমপ্লেক্সে রক্তদানের কথা রয়েছে। সুস্থ থাকুন ও পর্যাপ্ত পানি পান করুন।',
      timestamp: 'এইমাত্র',
      read: false,
    };

    playNotificationChime();
    setNotifications((prev) => [testNotif, ...prev]);
    showToast('🔔 আগামীকালের রক্তদান রিমাইন্ডার নোটিফিকেশন পাঠানো হয়েছে!');
  }, [showToast]);

  // Main App Content Renderer (Shared across Web View & Mobile App Shell)
  const renderAppContent = () => (
    <>
      {/* 3-Zone Header Navbar with 'হোম' & '••• থ্রি-ডট' dropdown */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        unreadCount={unreadCount}
        viewMode={viewMode}
        setViewMode={setViewMode}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onOpenAddRequest={() => setIsAddRequestOpen(true)}
        onOpenRegisterDonor={() => setIsAddDonorOpen(true)}
        onOpenUploadStory={() => setIsUploadStoryOpen(true)}
        onOpenComplaintBox={() => setIsComplaintBoxOpen(true)}
      />

      {/* Real-time High-Density Stats Bar */}
      <StatsBar
        donors={donors}
        requests={requests}
        onSelectReadyFilter={() => {
          setActiveTab('directory');
          setSelectedGroup('ALL');
        }}
        onSelectUrgentFilter={() => {
          setActiveTab('requests');
        }}
      />

      {/* Main Content Area - Full Page Transformation */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        
        {/* Back to Home Breadcrumb button on non-home pages */}
        {activeTab !== 'home' && (
          <div className="mb-5 flex items-center justify-between pb-3 border-b border-neutral-200/80">
            <button
              onClick={() => {
                setActiveTab('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-600 hover:text-red-700 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>হোমপেজে ফিরে যান</span>
            </button>

            <span className="text-xs font-medium text-neutral-400">
              {activeTab === 'directory' && 'রক্তদাতা তালিকা ও বুকিং'}
              {activeTab === 'requests' && 'জরুরি রক্তের আবেদন'}
              {activeTab === 'tracker' && '৪-মাস চক্র ও বুকিং ট্র্যাকার'}
              {activeTab === 'stories' && 'রক্তদানের ছবি ও মন্তব্য ওয়াল'}
              {activeTab === 'guidelines' && 'রক্তদানের নির্দেশিকা'}
              {activeTab === 'admin' && 'অ্যাডমিন কন্ট্রোল প্যানেল'}
            </span>
          </div>
        )}

        {/* PAGE 1: HOME (Clean smooth photo slider, NO comments in slide, 5 districts hub) */}
        {activeTab === 'home' && (
          <HomePage
            stories={stories}
            donors={donors}
            requests={requests}
            onSelectGroupAndGo={(group) => {
              setSelectedGroup(group);
              setActiveTab('directory');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onSelectDistrictAndGo={(district) => {
              setSelectedDistrict(district);
              setSelectedUpazila('ALL');
              setActiveTab('directory');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onNavigate={(tab) => {
              setActiveTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenUploadStory={() => setIsUploadStoryOpen(true)}
            onOpenAddRequest={() => setIsAddRequestOpen(true)}
            onOpenRegisterDonor={() => setIsAddDonorOpen(true)}
          />
        )}

        {/* PAGE 2: DONOR DIRECTORY WITH BOOKING (Complete Page Transformation) */}
        {activeTab === 'directory' && (
          <DonorDirectory
            donors={donors}
            bookings={bookings}
            selectedGroup={selectedGroup}
            setSelectedGroup={setSelectedGroup}
            selectedDistrict={selectedDistrict}
            setSelectedDistrict={setSelectedDistrict}
            selectedUpazila={selectedUpazila}
            setSelectedUpazila={setSelectedUpazila}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            onOpenRegisterModal={() => setIsAddDonorOpen(true)}
            onSelectDonorDetail={(donor) => setSelectedDonorDetail(donor)}
            onBookDonor={(donor) => setDonorToBook(donor)}
          />
        )}

        {/* PAGE 3: EMERGENCY BLOOD REQUESTS */}
        {activeTab === 'requests' && (
          <BloodRequestList
            requests={requests}
            onOpenAddRequest={() => setIsAddRequestOpen(true)}
            onUpdateStatus={handleUpdateRequestStatus}
            onShowToast={showToast}
          />
        )}

        {/* PAGE 4: 4-MONTH ELIGIBILITY TRACKER & BOOKING TIMELINE */}
        {activeTab === 'tracker' && currentUser && (
          <EligibilityTracker
            currentUser={currentUser}
            activeBooking={currentUserBooking}
            onUpdateDonor={handleUpdateDonor}
            onTriggerNotification={(title, message) => {
              const notif: AppNotification = {
                id: `notif-track-${Date.now()}`,
                type: 'eligibility_ready',
                title,
                message,
                timestamp: 'এখনই',
                read: false,
                relatedBloodGroup: currentUser.bloodGroup,
              };
              playNotificationChime();
              setNotifications((prev) => [notif, ...prev]);
              showToast(title);
            }}
            onOpenEditProfile={() => setIsUpdateProfileOpen(true)}
            onOpenUploadStory={() => setIsUploadStoryOpen(true)}
            onOpenCongratulationCard={() => {
              setCongratulationDonor(currentUser);
              setCongratulationDate(currentUser.lastDonationDate || new Date().toISOString().split('T')[0]);
              setIsCongratulationCardOpen(true);
            }}
            onConfirmDonationCompleted={handleConfirmDonationDone}
          />
        )}

        {/* PAGE 5: COMMUNITY STORIES & COMMENTS */}
        {activeTab === 'stories' && (
          <CommunityStories
            stories={stories}
            onOpenUploadModal={() => setIsUploadStoryOpen(true)}
            onLikeStory={handleLikeStory}
            onAddComment={handleAddStoryComment}
            onShowToast={showToast}
          />
        )}

        {/* PAGE 6: GUIDELINES & COMPATIBILITY */}
        {activeTab === 'guidelines' && <BloodGuidelines />}

        {/* PAGE 7: ADMIN CONTROL PANEL (ID add/delete control with reasons & complaints) */}
        {activeTab === 'admin' && (
          <AdminPanel
            donors={donors}
            recipients={recipients}
            bookings={bookings}
            complaints={complaints}
            onDeleteDonor={handleDeleteDonor}
            onBlockDonor={handleBlockDonor}
            onDeleteRecipient={handleDeleteRecipient}
            onConfirmDonationDone={handleConfirmDonationDone}
            onResolveComplaint={handleResolveComplaint}
            onOpenAddDonor={() => setIsAddDonorOpen(true)}
            onOpenAddRequest={() => setIsAddRequestOpen(true)}
          />
        )}

        {/* PAGE 8: MY PROFILE & AVAILABILITY SETTINGS (User requirement: দাতার আইডিতে অসুস্থ/জেলার বাইরে/অন্যান্য ও বুকিং সম্মতি) */}
        {activeTab === 'profile' && currentUser && (
          <MyProfilePage
            currentUser={currentUser}
            bookings={bookings}
            requests={requests}
            onUpdateDonor={handleUpdateDonor}
            onConsentBooking={handleConsentBooking}
            onOpenEditModal={() => setIsUpdateProfileOpen(true)}
            onOpenCongratulationCard={() => {
              setCongratulationDonor(currentUser);
              setCongratulationDate(currentUser.lastDonationDate || new Date().toISOString().split('T')[0]);
              setIsCongratulationCardOpen(true);
            }}
            onShowToast={showToast}
          />
        )}

      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-neutral-200 mt-12 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-8 border-b border-neutral-100">
            
            <div className="md:col-span-2 space-y-3">
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-lg bg-red-600 text-white flex items-center justify-center">
                  <Droplets className="w-4 h-4 fill-white" />
                </span>
                <span className="text-lg font-bold text-neutral-900">
                  ফরিদপুর ব্লাড ব্যাংক
                </span>
              </div>
              <p className="text-xs text-neutral-600 max-w-md leading-relaxed">
                ফরিদপুর, মাদারীপুর, গোপালগঞ্জ, রাজবাড়ী ও মাগুরা জেলার একটি সমন্বিত স্বেচ্ছাসেবী রক্তদান উদ্যোগ। রক্তদাতাদের অগ্রিম বুকিং, অভিযোগ নিষ্পত্তি ও ৪ মাসের রক্তদান ট্র্যাকিং।
              </p>
              <div className="flex items-center gap-2 text-xs text-neutral-500">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>মালিকের সরাসরি নিয়ন্ত্রণে পরিচালিত সেবামূলক প্ল্যাটফর্ম</span>
              </div>
            </div>

            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-900 mb-3">
                আঞ্চলিক জরুরি নম্বর
              </h4>
              <ul className="space-y-2 text-xs text-neutral-600">
                <li className="flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-red-600" />
                  <span>ফরিদপুর মেডিকেল: <strong>০৬৩১-৬২২৭২</strong></span>
                </li>
                <li>মাদারীপুর সদর হাসপাতাল: <strong>০৬৬১-৬১৬২৪</strong></li>
                <li>গোপালগঞ্জ ২৫০ শয্যা হাসপাতাল: <strong>০২-৬৬৮৫২২২</strong></li>
                <li>রাজবাড়ী সদর হাসপাতাল: <strong>০৬৪১-৬৫২৪২</strong></li>
                <li>মাগুরা সদর হাসপাতাল: <strong>০৪৮১-৬২৩৪১</strong></li>
              </ul>
            </div>

            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-900 mb-3">
                দ্রুত লিংক ও নিয়ন্ত্রণ
              </h4>
              <ul className="space-y-1.5 text-xs text-neutral-600">
                <li>
                  <button onClick={() => setActiveTab('home')} className="hover:text-red-600 cursor-pointer">
                    হোমপেজ
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveTab('directory')} className="hover:text-red-600 cursor-pointer">
                    রক্তদাতা তালিকা ও বুকিং
                  </button>
                </li>
                <li>
                  <button onClick={() => setIsComplaintBoxOpen(true)} className="text-red-600 hover:underline font-semibold cursor-pointer">
                    মালিকের কাছে অভিযোগ বক্স
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveTab('admin')} className="text-neutral-900 font-semibold hover:text-red-600 cursor-pointer">
                    অ্যাডমিন প্যানেল
                  </button>
                </li>
              </ul>
            </div>

          </div>

          <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-400 gap-2">
            <p>© {new Date().getFullYear()} ফরিদপুর ব্লাড ব্যাংক (Faridpur Blood Bank). ফরিদপুর, মাদারীপুর, গোপালগঞ্জ, রাজবাড়ী ও মাগুরা।</p>
            <p className="flex items-center gap-1">
              <span>মানবতার সেবায় রক্তদান</span>
              <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500 inline" />
            </p>
          </div>
        </div>
      </footer>
    </>
  );

  return (
    <div className="font-['Hind_Siliguri',sans-serif] antialiased selection:bg-red-500 selection:text-white">
      
      {/* Either render as standard Web View or Authentic Mobile App Shell based on viewMode */}
      {viewMode === 'mobile_app' ? (
        <MobileAppShell
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onSwitchToWeb={() => setViewMode('web')}
        >
          {renderAppContent()}
        </MobileAppShell>
      ) : (
        <div className="min-h-screen bg-[#faf9f6] text-neutral-800 flex flex-col">
          {renderAppContent()}
        </div>
      )}

      {/* MODALS AND DRAWERS */}
      <NotificationDrawer
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        onMarkAllAsRead={handleMarkAllNotifsRead}
        onClearAll={handleClearAllNotifs}
        onNotificationClick={handleNotificationClick}
        onTriggerTestNotif={handleTriggerTestNotif}
      />

      <BookDonorModal
        isOpen={!!donorToBook}
        donor={donorToBook}
        onClose={() => setDonorToBook(null)}
        onConfirmBooking={handleConfirmBooking}
      />

      <ComplaintBoxModal
        isOpen={isComplaintBoxOpen}
        onClose={() => setIsComplaintBoxOpen(false)}
        onSubmitComplaint={handleSubmitComplaint}
        defaultSenderName={currentUser?.name || ''}
        defaultSenderPhone={currentUser?.phone || ''}
      />

      <AddRequestModal
        isOpen={isAddRequestOpen}
        onClose={() => setIsAddRequestOpen(false)}
        onSubmit={handleAddRequest}
      />

      <AddDonorModal
        isOpen={isAddDonorOpen}
        onClose={() => setIsAddDonorOpen(false)}
        onAddDonor={handleAddDonor}
      />

      {currentUser && (
        <UpdateProfileModal
          isOpen={isUpdateProfileOpen}
          onClose={() => setIsUpdateProfileOpen(false)}
          currentUser={currentUser}
          onSave={handleUpdateDonor}
        />
      )}

      <UploadStoryModal
        isOpen={isUploadStoryOpen}
        onClose={() => setIsUploadStoryOpen(false)}
        onSubmit={handleAddStory}
        defaultDonorName={currentUser?.name || ''}
        defaultBloodGroup={currentUser?.bloodGroup || 'O+'}
        defaultDistrict={currentUser?.district || 'ফরিদপুর'}
        defaultUpazila={currentUser?.upazila || 'ফরিদপুর সদর'}
      />

      <DonorDetailModal
        donor={selectedDonorDetail}
        onClose={() => setSelectedDonorDetail(null)}
        onShowToast={showToast}
      />

      {/* Digital Congratulations and Recognition Card for Donors */}
      {congratulationDonor && (
        <CongratulationCardModal
          isOpen={isCongratulationCardOpen}
          onClose={() => setIsCongratulationCardOpen(false)}
          donor={congratulationDonor}
          donationDate={congratulationDate}
          hospitalName={congratulationHospital}
          onShowToast={showToast}
        />
      )}

      {/* Floating Toast Feedback */}
      <Toast message={toastMessage} onClose={() => setToastMessage(null)} />

    </div>
  );
}
