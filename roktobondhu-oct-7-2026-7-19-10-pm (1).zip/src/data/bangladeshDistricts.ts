export interface DistrictWithUpazilas {
  district: string;
  upazilas: string[];
}

export const REGIONAL_DISTRICTS_DATA: DistrictWithUpazilas[] = [
  {
    district: 'ফরিদপুর',
    upazilas: [
      'ফরিদপুর সদর',
      'ভাঙ্গা',
      'বোয়ালমারী',
      'মধুখালী',
      'সদরপুর',
      'নগরকান্দা',
      'চরভদ্রাসন',
      'সালথা',
      'আলফাডাঙ্গা',
    ],
  },
  {
    district: 'মাদারীপুর',
    upazilas: [
      'মাদারীপুর সদর',
      'শিবচর',
      'কালকিনি',
      'রাজৈর',
      'ডাসার',
    ],
  },
  {
    district: 'গোপালগঞ্জ',
    upazilas: [
      'গোপালগঞ্জ সদর',
      'কাশিয়ানী',
      'কোটালীপাড়া',
      'মুকসুদপুর',
      'টুঙ্গিপাড়া',
    ],
  },
  {
    district: 'রাজবাড়ী',
    upazilas: [
      'রাজবাড়ী সদর',
      'গোয়ালন্দ',
      'পাংশা',
      'বালিয়াকান্দি',
      'কালুখালী',
    ],
  },
  {
    district: 'মাগুরা',
    upazilas: [
      'মাগুরা সদর',
      'শ্রীপুর',
      'শালিখা',
      'মহম্মদপুর',
    ],
  },
];

export const ALLOWED_DISTRICTS: string[] = REGIONAL_DISTRICTS_DATA.map((d) => d.district);

export function getUpazilasForDistrict(districtName: string): string[] {
  const found = REGIONAL_DISTRICTS_DATA.find((d) => d.district === districtName);
  return found ? found.upazilas : [];
}

export const BLOOD_GROUPS: Array<'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-'> = [
  'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'
];
