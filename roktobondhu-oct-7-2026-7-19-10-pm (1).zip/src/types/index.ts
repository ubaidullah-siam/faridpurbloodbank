export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export interface DonationRecord {
  id: string;
  date: string; // YYYY-MM-DD
  hospitalOrPlace: string;
  patientNote?: string;
  bagsCount: number;
}

export type BookingStatus = 'pending_consent' | 'booked' | 'completed' | 'cancelled';

export interface BloodBooking {
  id: string;
  donorId: string;
  donorName: string;
  donorPhone: string;
  bloodGroup: BloodGroup;
  recipientId: string;
  recipientName: string;
  recipientPhone: string;
  patientName: string;
  hospitalName: string;
  district: string;
  upazila: string;
  scheduledDate: string; // YYYY-MM-DD
  daysRemainingForDonation: number;
  status: BookingStatus;
  consentGivenByDonor: boolean;
  notes?: string;
  createdAt: string;
  completedAt?: string;
}

export interface UnavailabilityInfo {
  type: 'illness' | 'out_of_district' | 'other';
  label: string;
  customDetails?: string;
}

export interface Donor {
  id: string;
  name: string;
  bloodGroup: BloodGroup;
  phone: string;
  altPhone?: string;
  email?: string;
  profilePicture?: string;
  district: string; // ফরিদপুর, মাদারীপুর, গোপালগঞ্জ, রাজবাড়ী, মাগুরা
  upazila: string;
  union?: string; // ইউনিয়নের নাম
  village?: string; // গ্রামের নাম
  area: string;
  password?: string;
  age: number;
  gender: 'পুরুষ' | 'মহিলা' | 'অন্যান্য';
  lastDonationDate: string | null; // YYYY-MM-DD or null
  totalDonations: number;
  isAvailable: boolean;
  unavailability?: UnavailabilityInfo | null;
  history: DonationRecord[];
  isCurrentUser?: boolean;
  photoUrl?: string;
  isBlocked?: boolean;
  blockReason?: string;
  activeBookingId?: string | null;
  createdAt: string;
}

export interface RecipientProfile {
  id: string;
  name: string;
  phone: string;
  email?: string;
  profilePicture?: string;
  district: string;
  upazila: string;
  area: string;
  patientName: string;
  patientCondition: string;
  bloodGroupNeeded: BloodGroup;
  bagsNeeded: number;
  hospitalName: string;
  neededDate: string;
  isBlocked?: boolean;
  blockReason?: string;
  createdAt: string;
}

export type UrgencyLevel =
  | 'সংকটাপন্ন (Critical / এখনই)'
  | 'জরুরি (২৪ ঘণ্টার মধ্যে)'
  | 'পরিকল্পিত (২-৩ দিন)'
  | 'জরুরি (এখনই)';

export interface BloodRequest {
  id: string;
  patientName: string;
  patientAge?: number;
  patientCondition: string;
  bloodGroup: BloodGroup;
  bagsNeeded: number;
  hospitalName: string;
  district: string;
  upazila: string;
  area: string;
  contactPerson: string;
  contactPhone: string;
  altPhone?: string;
  urgency: UrgencyLevel;
  neededDate: string; // YYYY-MM-DD
  status: 'active' | 'fulfilled' | 'closed';
  createdAt: string;
  additionalNotes?: string;
}

export type NotificationType =
  | 'eligibility_ready'
  | 'blood_request'
  | 'booking_consent_request'
  | 'booking_reminder'
  | 'booking_confirm'
  | 'chat_message'
  | 'system';

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  relatedBloodGroup?: BloodGroup;
  relatedRequestId?: string;
  relatedBookingId?: string;
  actionUrl?: string;
}

export interface StoryComment {
  id: string;
  authorName: string;
  commentText: string;
  date: string;
}

export interface DonationStory {
  id: string;
  donorName: string;
  bloodGroup: BloodGroup;
  district: string;
  upazila: string;
  hospitalName: string;
  donationDate: string;
  photoUrl: string;
  userFeedback: string;
  likesCount: number;
  comments: StoryComment[];
  createdAt: string;
}

export interface Complaint {
  id: string;
  senderName: string;
  senderPhone: string;
  senderType: 'দাতা' | 'গ্রহীতা' | 'সাধারণ ব্যবহারকারী';
  category: 'ভুয়া তথ্য বা নম্বর' | 'রক্তদাতা রক্ত দেয়নি' | 'অযৌক্তিক অর্থ দাবি' | 'বুকিং সমস্যা' | 'পরামর্শ';
  targetEntityName: string;
  details: string;
  status: 'pending' | 'resolved' | 'investigating';
  adminNotes?: string;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  text: string;
  timestamp: string;
  isRead: boolean;
}
